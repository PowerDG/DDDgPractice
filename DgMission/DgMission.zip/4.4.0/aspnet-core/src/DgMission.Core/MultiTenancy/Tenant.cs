﻿using Abp.MultiTenancy;
using DgMission.Authorization.Users;

namespace DgMission.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}

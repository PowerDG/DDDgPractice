﻿namespace DgMission
{
    public class DgMissionConsts
    {
        public const string LocalizationSourceName = "DgMission";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}

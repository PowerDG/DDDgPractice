﻿using Abp.Application.Services.Dto;

namespace DgMission.Roles.Dto
{
    public class PagedRoleResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}


﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Hangfire.MySql.Tests")]
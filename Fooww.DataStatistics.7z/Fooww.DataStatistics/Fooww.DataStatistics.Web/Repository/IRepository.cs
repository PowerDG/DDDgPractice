﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public interface IRepository<T> where T : class
    {
        Task<int> AddAsync(T entity);

        Task<IEnumerable<T>> GetAllAsync();

        Task<T> GetByIDAsync(int id);

        Task<IEnumerable<T>> GetByPageAsync(int limit, int page, string filter);

        Task<int> GetTotalCount(string filter);

        Task<bool> DeleteAsync(int id);

        Task<bool> UpdateAsync(T entity);

        Task<bool> IsExist(T entity);

        Task<IEnumerable<T>> GetLatestTwo();
    }
}
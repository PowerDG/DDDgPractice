﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class NewestHouseStatisticsRepository
    {
        private readonly DapperDBContext m_context;
        private readonly Dictionary<string, string> m_orderMapping;

        public NewestHouseStatisticsRepository(DapperDBContext context)
        {
            m_context = context;
            m_orderMapping = new Dictionary<string, string>();
            m_orderMapping.Add("statisticsTime", "statistics_time");
            m_orderMapping.Add("houseTotalCount", "house_total_count");
            m_orderMapping.Add("houseAvailableCount", "house_available_count");
            m_orderMapping.Add("houseIncreasedCount", "house_increased_count");
            m_orderMapping.Add("secondHouseTotalCount", "second_total_count");
            m_orderMapping.Add("secondHouseIncreasedCount", "second_increased_count");
            m_orderMapping.Add("rentHouseTotalCount", "rent_total_count");
            m_orderMapping.Add("rentHouseIncreasedCount", "rent_increased_count");
        }

        public async Task<IEnumerable<HouseStatistics>> GetByPageAsync(PageRequest request)
        {
            string where = string.IsNullOrWhiteSpace(request.Filter) ? "" : $@"WHERE city_code in ({request.Filter})";
            string sql = $@"SELECT id AS Id
                            , house_total_count AS HouseTotalCount
                            , house_available_count AS HouseAvailableCount
                            , house_increased_count AS HouseIncreasedCount
                            , second_total_count AS SecondHouseTotalCount
                            , second_increased_count AS SecondHouseIncreasedCount
                            , rent_total_count AS RentHouseTotalCount
                            , rent_increased_count AS RentHouseIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , last_second_id AS LastSecondId
                            , last_rent_id AS LastRentId
                            FROM statistics_house_newest {where}
                            ORDER BY {m_orderMapping[request.Field]} {request.Order}
                            LIMIT {request.Limit * (request.Page - 1)},{request.Limit}";
            return await m_context.QueryAsync<HouseStatistics>(sql);
        }

        public async Task<int> GetCountAsync(string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code in ({filter})";
            string sql = $@"SELECT COUNT(*) FROM statistics_house_newest {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> AddAsync(HouseStatistics houseStatistics)
        {
            string sqlSelect = $@"SELECT COUNT(*)
                                  FROM statistics_house_newest
                                  WHERE city_code='{houseStatistics.CityCode}'
                                  AND statistics_time='{houseStatistics.StatisticsTime}'";
            int existsCount = await m_context.ExecuteScalarAsync(sqlSelect);
            if (existsCount > 0)
            {
                return 0;
            }
            string sql = $@"INSERT INTO statistics_house_newest (house_total_count
                            , house_available_count
                            , house_increased_count
                            , second_total_count
                            , second_increased_count
                            , rent_total_count
                            , rent_increased_count
                            , city_code
                            , statistics_time
                            , latest_statistics_id
                            , last_second_id
                            , last_rent_id)
                            SELECT @HouseTotalCount,@HouseAvailableCount,
                            @HouseIncreasedCount,
                            @SecondHouseTotalCount,@SecondHouseIncreasedCount,
                            @RentHouseTotalCount,@RentHouseIncreasedCount,
                            @CityCode,@StatisticsTime,@LatestStatisticsId,@LastSecondId,@LastRentId";
            return await m_context.ExecuteAsync(sql, houseStatistics);
        }
        public async Task<int> UpdateAsync(HouseStatistics houseStatistics)
        {
            string sql = @"UPDATE statistics_house_newest SET
                              house_total_count=@HouseTotalCount
                            , house_available_count=@HouseAvailableCount
                            , house_increased_count=@HouseIncreasedCount
                            , second_total_count=@SecondHouseTotalCount
                            , second_increased_count=@SecondHouseIncreasedCount
                            , rent_total_count=@RentHouseTotalCount
                            , rent_increased_count=@RentHouseIncreasedCount
                            , city_code=@CityCode
                            , statistics_time=@StatisticsTime
                            , latest_statistics_id=@LatestStatisticsId
                            , last_second_id=@LastSecondId
                            , last_rent_id=@LastRentId
                           WHERE id = @Id";
            return await m_context.ExecuteAsync(sql, houseStatistics);
        }

        public async Task<dynamic> CalculateSumOfLatestAllCityLatest()
        {
            string sql = @"SELECT SUM(b.house_total_count) HouseCount,COUNT(b.id) CityCount
                            FROM
	                            (
		                            SELECT
			                            city_code,
			                            MAX(id) id
		                            FROM
			                            statistics_house_newest
		                            GROUP BY
			                            city_code
	                            ) a
                            JOIN statistics_house_newest b ON a.id = b.id
                            AND a.city_code = b.city_code";
            return await m_context.QueryFirstOrDefaultAsync<dynamic>(sql);
        }

        public async Task<HouseStatistics> GetByCityAsync(string cityDomain)
        {
            string sql = $@"SELECT id AS Id
                            ,house_total_count AS HouseTotalCount
                            , house_available_count AS HouseAvailableCount
                            , house_increased_count AS HouseIncreasedCount
                            , second_total_count AS SecondHouseTotalCount
                            , second_increased_count AS SecondHouseIncreasedCount
                            , rent_total_count AS RentHouseTotalCount
                            , rent_increased_count AS RentHouseIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , last_second_id AS LastSecondId
                            , last_rent_id AS LastRentId
                            FROM statistics_house_newest
                            WHERE city_code='{cityDomain}'";
            return await m_context.QueryFirstOrDefaultAsync<HouseStatistics>(sql);
        }

        public async Task<int> AddOrUpdateAsync(HouseStatistics houseStatistics)
        {
            var houseExists = await GetByCityAsync(houseStatistics.CityCode);
            if (houseExists == null)
            {
                return await AddAsync(houseStatistics);
            }
            else
            {
                houseStatistics.Id = houseExists.Id;
                return await UpdateAsync(houseStatistics);
            }
        }
    }
}
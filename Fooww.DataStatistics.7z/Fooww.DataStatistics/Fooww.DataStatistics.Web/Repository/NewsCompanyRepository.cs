﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class NewsCompanyRepository
    {
        private readonly DapperDBContext m_context;
        public NewsCompanyRepository(DapperDBContext context)
        {
            m_context = context;
        }

        public async Task<IEnumerable<NewsCompany>> GetAllAsync()
        {
            return await m_context.QueryAsync<NewsCompany>(@"SELECT
	                                                    id AS Id
                                                        ,name AS Name
                                                      FROM news_company;");
        }

    }
}

﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class NewestAcquisitionHouseRepository
    {
        private readonly DapperDBContext m_context;
        private readonly Dictionary<string, string> m_orderMapping;

        public NewestAcquisitionHouseRepository(DapperDBContext context)
        {
            m_context = context;
            m_orderMapping = new Dictionary<string, string>();
            m_orderMapping.Add("statisticsTime", "statistics_time");
            m_orderMapping.Add("totalCount", "house_total_count");
            m_orderMapping.Add("secondTotalCount", "second_total_count");
            m_orderMapping.Add("rentTotalCount", "rent_total_count");
            m_orderMapping.Add("totalIncreasedCount", "house_increased_count");
        }

        public async Task<IEnumerable<AcquisitionHouse>> GetByPageAsync(PageRequest request)
        {
            string where = string.IsNullOrWhiteSpace(request.Filter) ? "" : $@"WHERE city_code in ({request.Filter})";
            string sql = $@"SELECT id AS Id
                            , house_total_count AS TotalCount
                            , house_increased_count AS IncreasedCount
                            , second_total_count AS SecondTotalCount
                            , second_increased_count AS SecondIncreasedCount
                            , rent_total_count AS RentTotalCount
                            , rent_increased_count AS RentIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , last_second_id AS LastSecondId
                            , last_rent_id AS LastRentId
                            FROM acquisition_house_newest {where}
                            ORDER BY {m_orderMapping[request.Field]} {request.Order}
                            LIMIT {request.Limit * (request.Page - 1)},{request.Limit}";
            return await m_context.QueryAsync<AcquisitionHouse>(sql);
        }

        public async Task<int> GetCountAsync(string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code in ({filter})";
            string sql = $@"SELECT COUNT(*) FROM acquisition_house_newest {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> AddAsync(AcquisitionHouse acquisitionHouse)
        {
            string sqlSelect = $@"SELECT COUNT(*)
                                  FROM acquisition_house_newest
                                  WHERE city_code='{acquisitionHouse.CityCode}'
                                  AND statistics_time='{acquisitionHouse.StatisticsTime}'";
            int existsCount = await m_context.ExecuteScalarAsync(sqlSelect);
            if (existsCount > 0)
            {
                return 0;
            }
            string sql = $@"INSERT INTO acquisition_house_newest (house_total_count
                            , house_increased_count
                            , second_total_count
                            , second_increased_count
                            , rent_total_count
                            , rent_increased_count
                            , city_code
                            , statistics_time
                            , last_second_id
                            , last_rent_id)
                            SELECT @TotalCount,
                            @IncreasedCount,
                            @SecondTotalCount,@SecondIncreasedCount,
                            @RentTotalCount,@RentIncreasedCount,
                            @CityCode,@StatisticsTime,@LastSecondId,@LastRentId";
            return await m_context.ExecuteAsync(sql, acquisitionHouse);
        }
        public async Task<int> UpdateAsync(AcquisitionHouse acquisitionHouse)
        {
            string sql = @"UPDATE acquisition_house_newest SET
                              house_total_count = @TotalCount
                            , house_increased_count = @IncreasedCount
                            , second_total_count = @SecondTotalCount
                            , second_increased_count = @SecondIncreasedCount
                            , rent_total_count = @RentTotalCount
                            , rent_increased_count = @RentIncreasedCount
                            , city_code = @CityCode
                            , statistics_time = @StatisticsTime
                            , last_second_id = @LastSecondId
                            , last_rent_id = @LastRentId
                           WHERE id = @Id";
            return await m_context.ExecuteAsync(sql, acquisitionHouse);
        }

        public async Task<dynamic> CalculateSumOfLatestAllCityLatest()
        {
            string sql = @"SELECT SUM(b.house_total_count) TotalCount
                            ,SUM(b.house_increased_count) TotalIncreased
                            ,SUM(b.second_total_count) SecondTotalCount
                            ,SUM(b.second_increased_count) SecondIncreased
                            ,SUM(b.rent_total_count) RentTotalCount
                            ,SUM(b.rent_increased_count) RentIncreased
                            ,COUNT(b.id) CityCount
                            FROM
	                            (
		                            SELECT
			                            city_code,
			                            MAX(id) id
		                            FROM
			                            acquisition_house_newest
		                            GROUP BY
			                            city_code
	                            ) a
                            JOIN acquisition_house_newest b ON a.id = b.id
                            AND a.city_code = b.city_code";
            return await m_context.QueryFirstOrDefaultAsync<dynamic>(sql);
        }

        public async Task<AcquisitionHouse> GetByCityAsync(string cityDomain)
        {
            string sql = $@"SELECT id AS Id
                            , house_total_count AS TotalCount
                            , house_increased_count AS IncreasedCount
                            , second_total_count AS SecondTotalCount
                            , second_increased_count AS SecondIncreasedCount
                            , rent_total_count AS RentTotalCount
                            , rent_increased_count AS RentIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , last_second_id AS LastSecondId
                            , last_rent_id AS LastRentId
                            FROM acquisition_house_newest
                            WHERE id=(SELECT MAX(id) FROM acquisition_house_newest WHERE city_code='{cityDomain}')";
            return await m_context.QueryFirstOrDefaultAsync<AcquisitionHouse>(sql);
        }

        public async Task<int> AddOrUpdateAsync(AcquisitionHouse acquisitionHouse)
        {
            var acquisitionHouseExists = await GetByCityAsync(acquisitionHouse.CityCode);
            if (acquisitionHouseExists == null)
            {
                return await AddAsync(acquisitionHouse);
            }
            else
            {
                acquisitionHouse.Id = acquisitionHouseExists.Id;
                return await UpdateAsync(acquisitionHouse);
            }
        }

    }
}
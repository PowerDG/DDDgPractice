﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class NewsRepository
    {
        private readonly DapperDBContext m_context;
        public NewsRepository(DapperDBContext context)
        {
            m_context = context;
        }

        public async Task<IEnumerable<News>> GetAllAsync()
        {
            return await m_context.QueryAsync<News>(@"SELECT
	                                                    id AS Id
                                                        ,publish_time AS PublishTime
                                                        ,title AS Title
                                                        ,company_id AS CompanyId
                                                        ,summary AS Summary
                                                        ,news_url AS NewsUrl
                                                      FROM news;");
        }

        public async Task<IEnumerable<News>> GetByPageAsync(int companyId, string titleFilter, DateTime startTime, 
            DateTime endTime, int page, int limit)
        {
            var newsFilter = GetNewsFilter(companyId, titleFilter, startTime, endTime);
            string sql = $@"SELECT
	                            id AS Id
                                ,publish_time AS PublishTime
                                ,title AS Title
                                ,company_id AS CompanyId
                                ,summary AS Summary
                                ,news_url AS NewsUrl
                                FROM news
                            RIGHT JOIN( SELECT id as newsId FROM news WHERE 1=1 {newsFilter} GROUP BY news_url) newsIds
                            ON news.id = newsIds.newsId ORDER BY publish_time DESC limit {(page - 1) * limit},{limit} ";
            return await m_context.QueryAsync<News>(sql);
        }

        public async Task<int> GetTotalCount(int companyId, string titleFilter, DateTime startTime,DateTime endTime)
        {
            var newsFilter = GetNewsFilter(companyId, titleFilter, startTime, endTime);
            string sql = $@"SELECT COUNT(*) FROM news WHERE 1=1 {newsFilter}";
            return await m_context.ExecuteScalarAsync(sql);
        }
        private string GetNewsFilter(int companyId, string titleFilter, DateTime startTime, DateTime endTime)
        {
            var companyIdCondition = companyId == 0 ? "" : $@" AND company_id = {companyId}";
            var titleCondition = string.IsNullOrEmpty(titleFilter) ? "" : $@" AND LOCATE('{titleFilter}',title)>0";
            var pulishTimeCondition = startTime == DateTime.MinValue
                ? endTime == DateTime.MinValue ? "" : $" AND publish_time<'{endTime.ToString("yyyy-MM-dd")}'"
                : endTime == DateTime.MinValue ? $" AND publish_time > '{startTime.ToString("yyyy-MM-dd")}'"
                    : $@" AND publish_time BETWEEN '{startTime.ToString("yyyy-MM-dd")}' AND '{endTime.ToString("yyyy-MM-dd")}'";
            return $@" {titleCondition} {companyIdCondition} {pulishTimeCondition}";
        }

    }

}

﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class NewestDemandStatisticsRepository
    {
        private readonly DapperDBContext m_context;
        private readonly Dictionary<string, string> m_orderMapping;

        public NewestDemandStatisticsRepository(DapperDBContext context)
        {
            m_context = context;
            m_orderMapping = new Dictionary<string, string>();
            m_orderMapping.Add("statisticsTime", "statistics_time");
            m_orderMapping.Add("demandTotalCount", "demand_total_count");
            m_orderMapping.Add("demandAvailableCount", "demand_available_count");
            m_orderMapping.Add("demandIncreasedCount", "demand_increased_count");
            m_orderMapping.Add("secondDemandTotalCount", "second_total_count");
            m_orderMapping.Add("secondDemandIncreasedCount", "second_increased_count");
            m_orderMapping.Add("rentDemandTotalCount", "rent_total_count");
            m_orderMapping.Add("rentDemandIncreasedCount", "rent_increased_count");
        }

        public async Task<IEnumerable<DemandStatistics>> GetByPageAsync(PageRequest request)
        {
            string where = string.IsNullOrWhiteSpace(request.Filter) ? "" : $@"WHERE city_code in ({request.Filter})";
            string sql = $@"SELECT id AS Id
                            , demand_total_count AS DemandTotalCount
                            , demand_available_count AS DemandAvailableCount
                            , demand_increased_count AS DemandIncreasedCount
                            , second_total_count AS SecondDemandTotalCount
                            , second_increased_count AS SecondDemandIncreasedCount
                            , rent_total_count AS RentDemandTotalCount
                            , rent_increased_count AS RentDemandIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , last_second_id AS LastSecondId
                            , last_rent_id AS LastRentId
                            FROM statistics_demand_newest {where}
                            ORDER BY {m_orderMapping[request.Field]} {request.Order}
                            LIMIT {request.Limit * (request.Page - 1)},{request.Limit}";
            return await m_context.QueryAsync<DemandStatistics>(sql);
        }

        public async Task<int> GetCountAsync(string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code in ({filter})";
            string sql = $@"SELECT COUNT(*) FROM statistics_demand_newest {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> AddAsync(DemandStatistics demandStatistics)
        {
            string sqlSelect = $@"SELECT COUNT(*)
                                  FROM statistics_demand_newest
                                  WHERE city_code='{demandStatistics.CityCode}'
                                  AND statistics_time='{demandStatistics.StatisticsTime}'";
            int existsCount = await m_context.ExecuteScalarAsync(sqlSelect);
            if (existsCount > 0)
            {
                return 0;
            }
            string sql = $@"INSERT INTO statistics_demand_newest (demand_total_count
                            , demand_increased_count
                            , second_total_count
                            , second_increased_count
                            , rent_total_count
                            , rent_increased_count
                            , city_code
                            , statistics_time
                            , latest_statistics_id
                            , last_second_id
                            , last_rent_id)
                            SELECT @DemandTotalCount,
                            @DemandIncreasedCount,
                            @SecondDemandTotalCount,@SecondDemandIncreasedCount,
                            @RentDemandTotalCount,@RentDemandIncreasedCount,
                            @CityCode,@StatisticsTime,@LatestStatisticsId,@LastSecondId,@LastRentId";
            return await m_context.ExecuteScalarAsync(sql, demandStatistics);
        }
        public async Task<int> UpdateAsync(DemandStatistics demandStatistics)
        {
            string sql = @"UPDATE statistics_demand_newest SET
                              demand_total_count=@DemandTotalCount
                            , demand_increased_count=@DemandIncreasedCount
                            , second_total_count=@SecondDemandTotalCount
                            , second_increased_count=@SecondDemandIncreasedCount
                            , rent_total_count=@RentDemandTotalCount
                            , rent_increased_count=@RentDemandIncreasedCount
                            , city_code=@CityCode
                            , statistics_time=@StatisticsTime
                            , latest_statistics_id=@LatestStatisticsId
                            , last_second_id=@LastSecondId
                            , last_rent_id=@LastRentId
                           WHERE id = @Id";
            return await m_context.ExecuteAsync(sql, demandStatistics);
        }

        public async Task<dynamic> CalculateSumOfLatestAllCityLatest()
        {
            string sql = @"SELECT SUM(b.demand_total_count) DemandCount,COUNT(b.id) CityCount
                            FROM
	                            (
		                            SELECT
			                            city_code,
			                            MAX(id) id
		                            FROM
			                            statistics_demand_newest
		                            GROUP BY
			                            city_code
	                            ) a
                            JOIN statistics_demand_newest b ON a.id = b.id
                            AND a.city_code = b.city_code";
            return await m_context.QueryFirstOrDefaultAsync<dynamic>(sql);
        }

        public async Task<DemandStatistics> GetByCityAsync(string cityDomain)
        {
            string sql = $@"SELECT id AS Id
                            , demand_total_count AS DemandTotalCount
                            , demand_available_count AS DemandAvailableCount
                            , demand_increased_count AS DemandIncreasedCount
                            , second_total_count AS SecondDemandTotalCount
                            , second_increased_count AS SecondDemandIncreasedCount
                            , rent_total_count AS RentDemandTotalCount
                            , rent_increased_count AS RentDemandIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , last_second_id AS LastSecondId
                            , last_rent_id AS LastRentId
                            FROM statistics_demand_newest
                            WHERE city_code='{cityDomain}'";
            return await m_context.QueryFirstOrDefaultAsync<DemandStatistics>(sql);
        }

        public async Task<int> AddOrUpdateAsync(DemandStatistics demandStatistics)
        {
            var demandExists = await GetByCityAsync(demandStatistics.CityCode);
            if (demandExists == null)
            {
                return await AddAsync(demandStatistics);
            }
            else
            {
                demandStatistics.Id = demandExists.Id;
                return await UpdateAsync(demandStatistics);
            }
        }

    }
}
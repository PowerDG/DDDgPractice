﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class NewsWordCountRepository
    {
        private readonly DapperDBContext m_context;
        public NewsWordCountRepository(DapperDBContext context)
        {
            m_context = context;
        }

        public async Task<IEnumerable<NewsWordCount>> GetAllAsync()
        {
            return await m_context.QueryAsync<NewsWordCount>(@"SELECT
	                                                                word AS Word
                                                                    ,count AS Count
                                                               FROM news_word_count;");
        }

        public async Task<IEnumerable<NewsWordCount>> GetByCompanyIdAsync(int companyId)
        {
            return await m_context.QueryAsync<NewsWordCount>($@"SELECT
	                                                                word AS Word
                                                                    ,count AS Count
                                                                FROM news_word_count 
                                                                WHERE company_id={companyId};");
        }

    }
}

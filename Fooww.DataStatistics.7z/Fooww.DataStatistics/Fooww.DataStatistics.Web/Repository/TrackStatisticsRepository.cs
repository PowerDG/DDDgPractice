﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class TrackStatisticsRepository
    {
        private readonly DapperDBContext m_context;
        private readonly Dictionary<string, string> m_orderMapping;

        public TrackStatisticsRepository(DapperDBContext context)
        {
            m_context = context;
            m_orderMapping = new Dictionary<string, string>();
            m_orderMapping.Add("statisticsTime", "id");
            m_orderMapping.Add("trackTotalCount", "track_total_count");
            m_orderMapping.Add("trackAvailableCount", "track_available_count");
            m_orderMapping.Add("trackIncreasedCount", "track_increased_count");
            m_orderMapping.Add("houseTrackTotalCount", "house_track_total_count");
            m_orderMapping.Add("houseTrackIncreasedCount", "house_track_increased_count");
            m_orderMapping.Add("demandTrackTotalCount", "demand_track_total_count");
            m_orderMapping.Add("demandTrackIncreasedCount", "demand_track_increased_count");
        }

        public async Task<IEnumerable<TrackStatistics>> GetByPageAsync(PageRequest request)
        {
            string where = string.IsNullOrWhiteSpace(request.Filter) ? "" : $@"WHERE b.city_code in ({request.Filter})";
            string sql = $@"SELECT b.id AS Id
                            , b.track_total_count AS TrackTotalCount
                            , b.track_available_count AS TrackAvailableCount
                            , b.track_increased_count AS TrackIncreasedCount
                            , b.house_track_total_count AS HouseTrackTotalCount
                            , b.house_track_increased_count AS HouseTrackIncreasedCount
                            , b.demand_track_total_count AS DemandTrackTotalCount
                            , b.demand_track_increased_count AS DemandTrackIncreasedCount
                            , b.city_code AS CityCode
                            , b.statistics_time AS StatisticsTime
                            , last_track_operatetime AS LastTrackOperateTime
                            FROM
	                            (
		                            SELECT
			                            city_code,
			                            MAX(id) id
		                            FROM
			                            statistics_track
		                            GROUP BY
			                            city_code
	                            ) a
                            JOIN statistics_track b ON a.id = b.id
                            AND a.city_code = b.city_code {where}
                            ORDER BY b.{m_orderMapping[request.Field]} {request.Order}
                            LIMIT {request.Limit * (request.Page - 1)},{request.Limit}";
            return await m_context.QueryAsync<TrackStatistics>(sql);
        }

        public async Task<int> GetTotalCount(string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code in ({filter})";
            string sql = $@"SELECT COUNT(DISTINCT city_code) FROM statistics_track {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> AddAsync(TrackStatistics trackStatistics)
        {
            string sqlSelect = $@"SELECT * 
                                  FROM statistics_track 
                                  WHERE city_code='{trackStatistics.CityCode}' 
                                  AND statistics_time='{trackStatistics.StatisticsTime}'";
            int existsCount = await m_context.ExecuteScalarAsync(sqlSelect);
            if (existsCount > 0)
            {
                return 0;
            }
            string sql = $@"INSERT INTO statistics_track (track_total_count
                            , track_available_count
                            , track_increased_count
                            , house_track_total_count
                            , house_track_increased_count
                            , demand_track_total_count
                            , demand_track_increased_count
                            , city_code
                            , statistics_time
                            , latest_statistics_id
                            , last_track_operatetime)
                            SELECT @TrackTotalCount,@TrackAvailableCount,
                            @TrackIncreasedCount,
                            @HouseTrackTotalCount,@HouseTrackIncreasedCount,
                            @DemandTrackTotalCount,@DemandTrackIncreasedCount,
                            @CityCode,@StatisticsTime,@LatestStatisticsId,@LastTrackOperateTime";
            return await m_context.ExecuteScalarAsync(sql, trackStatistics);
        }

        public async Task<dynamic> CalculateSumOfLatestAllCityLatest()
        {
            string sql = @"SELECT SUM(b.track_total_count) TrackCount,COUNT(b.id) CityCount
                            FROM
	                            (
		                            SELECT
			                            city_code,
			                            MAX(id) id
		                            FROM
			                            statistics_track
		                            GROUP BY
			                            city_code
	                            ) a
                            JOIN statistics_track b ON a.id = b.id
                            AND a.city_code = b.city_code";
            return await m_context.QueryFirstOrDefaultAsync<dynamic>(sql);
        }
        public async Task<TrackStatistics> GetLatest(string cityDomain)
        {
            string sql = $@"SELECT id AS Id
                            , track_total_count AS TrackTotalCount
                            , track_available_count AS TrackAvailableCount
                            , track_increased_count AS TrackIncreasedCount
                            , house_track_total_count AS HouseTrackTotalCount
                            , house_track_increased_count AS HouseTrackIncreasedCount
                            , demand_track_total_count AS DemandTrackTotalCount
                            , demand_track_increased_count AS DemandTrackIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , last_track_operatetime AS LastTrackOperateTime
                            FROM statistics_track
                            WHERE id=(SELECT MAX(id) FROM statistics_track WHERE city_code='{cityDomain}')";
            return await m_context.QueryFirstOrDefaultAsync<TrackStatistics>(sql);
        }

        public async Task<IEnumerable<dynamic>> GetTotalCountListByYear(string cityDomain)
        {
            string sql = $@"SELECT id AS Id
                            , track_total_count AS TotalCount1
                            , house_track_total_count AS TotalCount2
                            , demand_track_total_count AS TotalCount3
                            , statistics_time AS StatisticsTime
                            FROM statistics_track
                            WHERE city_code='{cityDomain}' AND statistics_time > DATE_SUB(statistics_time,INTERVAL 12 MONTH)
                            ORDER BY statistics_time";
            return await m_context.QueryAsync<dynamic>(sql);
        }

        public async Task<IEnumerable<dynamic>> GetTotalIncreasedCountListByYear(string cityDomain)
        {
            string sql = $@"SELECT id AS Id
                            , track_increased_count AS TotalCount1
                            , house_track_increased_count AS TotalCount2
                            , demand_track_increased_count AS TotalCount3
                            , statistics_time AS StatisticsTime
                            FROM statistics_track
                            WHERE city_code='{cityDomain}' AND statistics_time > DATE_SUB(statistics_time,INTERVAL 12 MONTH)
                            ORDER BY statistics_time";
            return await m_context.QueryAsync<dynamic>(sql);
        }

    }
}
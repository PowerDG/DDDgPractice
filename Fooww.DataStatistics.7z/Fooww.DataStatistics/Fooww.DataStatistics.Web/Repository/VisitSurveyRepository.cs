﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class VisitSurveyStatisticsRepository
    {
        private readonly DapperDBContext m_context;
        private readonly Dictionary<string, string> m_orderMapping;

        public VisitSurveyStatisticsRepository(DapperDBContext context)
        {
            m_context = context;
            m_orderMapping = new Dictionary<string, string>();
            m_orderMapping.Add("statisticsTime", "id");
            m_orderMapping.Add("visitTotalCount", "visit_total_count");
            m_orderMapping.Add("visitAvailableCount", "visit_available_count");
            m_orderMapping.Add("visitIncreasedCount", "visit_increased_count");
            m_orderMapping.Add("surveyTotalCount", "survey_total_count");
            m_orderMapping.Add("surveyAvailableCount", "survey_available_count");
            m_orderMapping.Add("surveyIncreasedCount", "survey_increased_count");
        }

        public async Task<IEnumerable<VisitSurveyStatistics>> GetByPageAsync(PageRequest request)
        {
            string where = string.IsNullOrWhiteSpace(request.Filter) ? "" : $@"WHERE b.city_code in ({request.Filter})";
            string sql = $@"SELECT b.id AS Id
                            , b.visit_total_count AS VisitTotalCount
                            , b.visit_available_count AS VisitAvailableCount
                            , b.visit_increased_count AS VisitIncreasedCount
                            , b.survey_total_count AS SurveyTotalCount
                            , b.survey_available_count AS SurveyAvailableCount
                            , b.survey_increased_count AS SurveyIncreasedCount
                            , b.city_code AS CityCode
                            , b.statistics_time AS StatisticsTime
                            , b.visit_execution_time AS LastVisitExecutionTime
                            , b.survey_create_time AS LastSurveyCreateTime
                            FROM
	                            (
		                            SELECT
			                            city_code,
			                            MAX(id) id
		                            FROM
			                            statistics_visit_survey
		                            GROUP BY
			                            city_code
	                            ) a
                            JOIN statistics_visit_survey b ON a.id = b.id
                            AND a.city_code = b.city_code {where}
                            ORDER BY b.{m_orderMapping[request.Field]} {request.Order}
                            LIMIT {request.Limit * (request.Page - 1)},{request.Limit}";
            return await m_context.QueryAsync<VisitSurveyStatistics>(sql);
        }

        public async Task<int> GetTotalCount(string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code in ({filter})";
            string sql = $@"SELECT COUNT(DISTINCT city_code) FROM statistics_visit_survey {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> AddAsync(VisitSurveyStatistics visitSurveyStatistics)
        {
            string sqlSelect = $@"SELECT * 
                                  FROM statistics_visit_survey 
                                  WHERE city_code='{visitSurveyStatistics.CityCode}' 
                                  AND statistics_time='{visitSurveyStatistics.StatisticsTime}'";
            int existsCount = await m_context.ExecuteScalarAsync(sqlSelect);
            if (existsCount > 0)
            {
                return 0;
            }
            string sql = $@"INSERT INTO statistics_visit_survey (visit_total_count
                            , visit_available_count
                            , visit_increased_count
                            , survey_total_count
                            , survey_available_count
                            , survey_increased_count
                            , city_code
                            , statistics_time
                            , latest_statistics_id
                            , visit_execution_time
                            , survey_create_time)
                            SELECT @VisitTotalCount,@VisitAvailableCount,
                            @VisitIncreasedCount,
                            @SurveyTotalCount,@SurveyAvailableCount,
                            @SurveyIncreasedCount,
                            @CityCode,@StatisticsTime,@LatestStatisticsId,@LastVisitExecutionTime,@LastSurveyCreateTime";
            return await m_context.ExecuteScalarAsync(sql, visitSurveyStatistics);
        }


        public async Task<dynamic> CalculateSumOfLatestAllCityLatest()
        {
            string sql = @"SELECT
                            SUM(b.visit_total_count) VisitCount,SUM(b.survey_total_count) SurveyCount,COUNT(b.id) CityCount
                            FROM
	                            (
		                            SELECT
			                            city_code,
			                            MAX(id) id
		                            FROM
			                            statistics_visit_survey
		                            GROUP BY
			                            city_code
	                            ) a
                            JOIN statistics_visit_survey b ON a.id = b.id
                            AND a.city_code = b.city_code";
            return await m_context.QueryFirstOrDefaultAsync<dynamic>(sql);
        }
        public async Task<VisitSurveyStatistics> GetLatest(string cityDomain)
        {
            string sql = $@"SELECT id AS Id
                            , visit_total_count AS VisitTotalCount
                            , visit_available_count AS VisitAvailableCount
                            , visit_increased_count AS VisitIncreasedCount
                            , survey_total_count AS SurveyTotalCount
                            , survey_available_count AS SurveyAvailableCount
                            , survey_increased_count AS SurveyIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , visit_execution_time AS LastVisitExecutionTime
                            , survey_create_time AS LastSurveyCreateTime
                            FROM statistics_visit_survey
                            WHERE id=(SELECT MAX(id) FROM statistics_visit_survey WHERE city_code='{cityDomain}')";
            return await m_context.QueryFirstOrDefaultAsync<VisitSurveyStatistics>(sql);
        }

        public async Task<IEnumerable<dynamic>> GetTotalCountListByYear(string cityDomain)
        {
            string sql = $@"SELECT id AS Id
                            , visit_total_count AS TotalCount1
                            , survey_total_count AS TotalCount2
                            , statistics_time AS StatisticsTime
                            FROM statistics_visit_survey
                            WHERE city_code='{cityDomain}' AND statistics_time > DATE_SUB(statistics_time,INTERVAL 12 MONTH)
                            ORDER BY statistics_time";
            return await m_context.QueryAsync<dynamic>(sql);
        }
        public async Task<IEnumerable<dynamic>> GetTotalIncreasedCountListByYear(string cityDomain)
        {
            string sql = $@"SELECT id AS Id
                            , visit_increased_count AS TotalCount1
                            , survey_increased_count AS TotalCount2
                            , statistics_time AS StatisticsTime
                            FROM statistics_visit_survey
                            WHERE city_code='{cityDomain}' AND statistics_time > DATE_SUB(statistics_time,INTERVAL 12 MONTH)
                            ORDER BY statistics_time";
            return await m_context.QueryAsync<dynamic>(sql);
        }

    }
}
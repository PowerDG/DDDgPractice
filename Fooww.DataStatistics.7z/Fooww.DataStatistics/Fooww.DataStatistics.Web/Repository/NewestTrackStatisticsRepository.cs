﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class NewestTrackStatisticsRepository
    {
        private readonly DapperDBContext m_context;
        private readonly Dictionary<string, string> m_orderMapping;

        public NewestTrackStatisticsRepository(DapperDBContext context)
        {
            m_context = context;
            m_orderMapping = new Dictionary<string, string>();
            m_orderMapping.Add("statisticsTime", "statistics_time");
            m_orderMapping.Add("trackTotalCount", "track_total_count");
            m_orderMapping.Add("trackAvailableCount", "track_available_count");
            m_orderMapping.Add("trackIncreasedCount", "track_increased_count");
            m_orderMapping.Add("houseTrackTotalCount", "house_track_total_count");
            m_orderMapping.Add("houseTrackIncreasedCount", "house_track_increased_count");
            m_orderMapping.Add("demandTrackTotalCount", "demand_track_total_count");
            m_orderMapping.Add("demandTrackIncreasedCount", "demand_track_increased_count");
        }

        public async Task<IEnumerable<TrackStatistics>> GetByPageAsync(PageRequest request)
        {
            string where = string.IsNullOrWhiteSpace(request.Filter) ? "" : $@"WHERE city_code in ({request.Filter})";
            string sql = $@"SELECT id AS Id
                            , track_total_count AS TrackTotalCount
                            , track_available_count AS TrackAvailableCount
                            , track_increased_count AS TrackIncreasedCount
                            , house_track_total_count AS HouseTrackTotalCount
                            , house_track_increased_count AS HouseTrackIncreasedCount
                            , demand_track_total_count AS DemandTrackTotalCount
                            , demand_track_increased_count AS DemandTrackIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , last_track_operatetime AS LastTrackOperateTime
                            FROM statistics_track_newest {where}
                            ORDER BY {m_orderMapping[request.Field]} {request.Order}
                            LIMIT {request.Limit * (request.Page - 1)},{request.Limit}";
            return await m_context.QueryAsync<TrackStatistics>(sql);
        }

        public async Task<int> GetCountAsync(string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code in ({filter})";
            string sql = $@"SELECT COUNT(*) FROM statistics_track_newest {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> AddAsync(TrackStatistics trackStatistics)
        {
            string sqlSelect = $@"SELECT COUNT(*)
                                  FROM statistics_track_newest 
                                  WHERE city_code='{trackStatistics.CityCode}' 
                                  AND statistics_time='{trackStatistics.StatisticsTime}'";
            int existsCount = await m_context.ExecuteScalarAsync(sqlSelect);
            if (existsCount > 0)
            {
                return 0;
            }
            string sql = $@"INSERT INTO statistics_track_newest (track_total_count
                            , track_available_count
                            , track_increased_count
                            , house_track_total_count
                            , house_track_increased_count
                            , demand_track_total_count
                            , demand_track_increased_count
                            , city_code
                            , statistics_time
                            , latest_statistics_id
                            , last_track_operatetime)
                            SELECT @TrackTotalCount,@TrackAvailableCount,
                            @TrackIncreasedCount,
                            @HouseTrackTotalCount,@HouseTrackIncreasedCount,
                            @DemandTrackTotalCount,@DemandTrackIncreasedCount,
                            @CityCode,@StatisticsTime,@LatestStatisticsId,@LastTrackOperateTime";
            return await m_context.ExecuteScalarAsync(sql, trackStatistics);
        }
        public async Task<int> UpdateAsync(TrackStatistics trackStatistics)
        {
            string sql = @"UPDATE statistics_track_newest SET
                              track_total_count=@TrackTotalCount
                            , track_available_count=@TrackAvailableCount
                            , track_increased_count=@TrackIncreasedCount
                            , house_track_total_count=@HouseTrackTotalCount
                            , house_track_increased_count=@HouseTrackIncreasedCount
                            , demand_track_total_count=@DemandTrackTotalCount
                            , demand_track_increased_count=@DemandTrackIncreasedCount
                            , city_code=@CityCode
                            , statistics_time=@StatisticsTime
                            , last_track_operatetime=@LastTrackOperateTime
                           WHERE id = @Id";
            return await m_context.ExecuteAsync(sql, trackStatistics);
        }

        public async Task<dynamic> CalculateSumOfLatestAllCityLatest()
        {
            string sql = @"SELECT SUM(b.track_total_count) TrackCount,COUNT(b.id) CityCount
                            FROM
	                            (
		                            SELECT
			                            city_code,
			                            MAX(id) id
		                            FROM
			                            statistics_track_newest
		                            GROUP BY
			                            city_code
	                            ) a
                            JOIN statistics_track_newest b ON a.id = b.id
                            AND a.city_code = b.city_code";
            return await m_context.QueryFirstOrDefaultAsync<dynamic>(sql);
        }
        public async Task<TrackStatistics> GetByCityAsync(string cityDomain)
        {
            string sql = $@"SELECT id AS Id
                            , track_total_count AS TrackTotalCount
                            , track_available_count AS TrackAvailableCount
                            , track_increased_count AS TrackIncreasedCount
                            , house_track_total_count AS HouseTrackTotalCount
                            , house_track_increased_count AS HouseTrackIncreasedCount
                            , demand_track_total_count AS DemandTrackTotalCount
                            , demand_track_increased_count AS DemandTrackIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , last_track_operatetime AS LastTrackOperateTime
                            FROM statistics_track_newest
                            WHERE city_code='{cityDomain}'";
            return await m_context.QueryFirstOrDefaultAsync<TrackStatistics>(sql);
        }
        public async Task<int> AddOrUpdateAsync(TrackStatistics trackStatistics)
        {
            var trackExists = await GetByCityAsync(trackStatistics.CityCode);
            if (trackExists == null)
            {
                return await AddAsync(trackStatistics);
            }
            else
            {
                trackStatistics.Id = trackExists.Id;
                return await UpdateAsync(trackStatistics);
            }
        }

    }
}
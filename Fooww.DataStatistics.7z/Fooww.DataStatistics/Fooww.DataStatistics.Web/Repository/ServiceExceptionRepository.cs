﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class ServiceExceptionRepository
    {
        private readonly DapperDBContext m_context;
        private readonly Dictionary<string, string> m_orderMapping;

        public ServiceExceptionRepository(DapperDBContext context)
        {
            m_context = context;
            m_orderMapping = new Dictionary<string, string>();
            m_orderMapping.Add("responseTime", @"(case is_accessible
                                                           when 1 then response_duration
                                                           else response_duration + 15
                                                           end)");
            m_orderMapping.Add("accessibleTime", "accessible_time");
            m_orderMapping.Add("ip", "inet_aton(ip)");
        }

        public async Task<IEnumerable<ServiceException>> GetByPageAsync(PageRequest request)
        {
            string cityCode = request.Filter.Split(',')[0];
            string serviceType = request.Filter.Split(',')[1];
            string where = $@"WHERE city_code = '{cityCode}' AND service_type = {serviceType}";
            string sql = $@"SELECT id AS Id
                            , city_code AS CityCode
                            , service_type AS ServiceType
                            , response_duration AS ResponseDuration
                            , accessible_time AS AccessibleTime
                            , is_accessible AS IsAccessible
                            FROM service_exception {where}
                            ORDER BY {m_orderMapping[request.Field]} {request.Order}
                            LIMIT {request.Limit * (request.Page - 1)},{request.Limit}";
            return await m_context.QueryAsync<ServiceException>(sql);
        }

        public async Task<IEnumerable<ServiceException>> GetByDateAndServiceTypeAsync(PageRequest request)
        {
            string startDate = request.StartDate.ToString("yyyy-MM-dd");
            string endDate = request.EndDate.AddDays(1).ToString("yyyy-MM-dd");
            string cityCodeCondition = "";
            if (string.IsNullOrWhiteSpace(request.Filter))
            {
                cityCodeCondition = "1=1";
            }
            else if(!Regex.IsMatch(request.Filter, @"^[0-9]"))
            {
                cityCodeCondition = $@" city_code in ({request.Filter})";
            }
            else
            {
                cityCodeCondition = $@" ip LIKE '%{request.Filter}%'";
            }
            string where = $"WHERE {cityCodeCondition}"
                + (request.ServiceType == 0 ? " AND 1=1 " : $@" AND service_type={request.ServiceType} ")
                + $@" AND accessible_time > '{startDate}' AND accessible_time < '{endDate}'";
            string sql = $@"SELECT id AS Id
                            , city_code AS CityCode
                            , service_type AS ServiceType
                            , response_duration AS ResponseDuration
                            , accessible_time AS AccessibleTime
                            , is_accessible AS IsAccessible
                            , ip AS IP
                            FROM service_exception {where}
                            ORDER BY {m_orderMapping[request.Field]} {request.Order}
                            LIMIT {request.Limit * (request.Page - 1)},{request.Limit}";
            return await m_context.QueryAsync<ServiceException>(sql);
        }
        public async Task<int> GetTotalCountByDateAndServiceTypeAsync(PageRequest request)
        {
            string startDate = request.StartDate.ToString("yyyy-MM-dd");
            string endDate = request.EndDate.AddDays(1).ToString("yyyy-MM-dd");
            string cityCodeCondition = "";
            if (string.IsNullOrWhiteSpace(request.Filter))
            {
                cityCodeCondition = "1=1";
            }
            else if (!Regex.IsMatch(request.Filter, @"^[0-9]"))
            {
                cityCodeCondition = $@" city_code in ({request.Filter})";
            }
            else
            {
                cityCodeCondition = $@" ip LIKE '%{request.Filter}%'";
            }
            string where = $"WHERE {cityCodeCondition}"
                + (request.ServiceType == 0 ? " AND 1=1 " : $@" AND service_type={request.ServiceType} ")
                + $@" AND accessible_time > '{startDate}' AND accessible_time < '{endDate}'";
            string sql = $@"SELECT COUNT(*) FROM service_exception {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> GetTotalCount(string filter)
        {
            string cityCode = filter.Split(',')[0];
            string serviceType = filter.Split(',')[1];
            string where = $@"WHERE city_code = '{cityCode}' AND service_type = {serviceType}";
            string sql = $@"SELECT COUNT(*) FROM service_exception {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> AddAsync(ServiceException serviceException)
        {
            string sql = $@"INSERT INTO service_exception (city_code
                            , service_type
                            , response_duration
                            , accessible_time
                            , is_accessible
                            , ip)
                            SELECT @CityCode,@ServiceType,
                            @ResponseDuration,
                            @AccessibleTime,@IsAccessible,@IP";
            return await m_context.ExecuteAsync(sql, serviceException);
        }


        public async Task<IEnumerable<ServiceException>> GetForChart(string cityCode, int serviceType, 
            string currentTime,int intervalHour)
        {
            string sql = $@"SELECT id AS Id
                            , city_code AS CityCode
                            , service_type AS ServiceType
                            , response_duration AS ResponseDuration
                            , accessible_time AS AccessibleTime
                            , is_accessible AS IsAccessible
                            FROM service_exception
                            WHERE city_code='{cityCode}' AND service_type={serviceType} AND 
                            (accessible_time  BETWEEN DATE_SUB('{currentTime}',INTERVAL {intervalHour} HOUR) AND '{currentTime}')
                            ORDER BY id DESC";
            return await m_context.QueryAsync<ServiceException>(sql);
        }
    }
}
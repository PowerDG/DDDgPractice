﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class NewestVisitSurveyStatisticsRepository
    {
        private readonly DapperDBContext m_context;
        private readonly Dictionary<string, string> m_orderMapping;

        public NewestVisitSurveyStatisticsRepository(DapperDBContext context)
        {
            m_context = context;
            m_orderMapping = new Dictionary<string, string>();
            m_orderMapping.Add("statisticsTime", "statistics_time");
            m_orderMapping.Add("visitTotalCount", "visit_total_count");
            m_orderMapping.Add("visitAvailableCount", "visit_available_count");
            m_orderMapping.Add("visitIncreasedCount", "visit_increased_count");
            m_orderMapping.Add("surveyTotalCount", "survey_total_count");
            m_orderMapping.Add("surveyAvailableCount", "survey_available_count");
            m_orderMapping.Add("surveyIncreasedCount", "survey_increased_count");
        }

        public async Task<IEnumerable<VisitSurveyStatistics>> GetByPageAsync(PageRequest request)
        {
            string where = string.IsNullOrWhiteSpace(request.Filter) ? "" : $@"WHERE city_code in ({request.Filter})";
            string sql = $@"SELECT id AS Id
                            , visit_total_count AS VisitTotalCount
                            , visit_available_count AS VisitAvailableCount
                            , visit_increased_count AS VisitIncreasedCount
                            , survey_total_count AS SurveyTotalCount
                            , survey_available_count AS SurveyAvailableCount
                            , survey_increased_count AS SurveyIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , visit_execution_time AS LastVisitExecutionTime
                            , survey_create_time AS LastSurveyCreateTime
                            FROM statistics_visit_survey_newest {where}
                            ORDER BY {m_orderMapping[request.Field]} {request.Order}
                            LIMIT {request.Limit * (request.Page - 1)},{request.Limit}";
            return await m_context.QueryAsync<VisitSurveyStatistics>(sql);
        }

        public async Task<int> GetCountAsync(string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code in ({filter})";
            string sql = $@"SELECT COUNT(*) FROM statistics_visit_survey_newest {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> AddAsync(VisitSurveyStatistics visitSurveyStatistics)
        {
            string sqlSelect = $@"SELECT COUNT(*)
                                  FROM statistics_visit_survey_newest 
                                  WHERE city_code='{visitSurveyStatistics.CityCode}' 
                                  AND statistics_time='{visitSurveyStatistics.StatisticsTime}'";
            int existsCount = await m_context.ExecuteScalarAsync(sqlSelect);
            if (existsCount > 0)
            {
                return 0;
            }
            string sql = $@"INSERT INTO statistics_visit_survey_newest (visit_total_count
                            , visit_available_count
                            , visit_increased_count
                            , survey_total_count
                            , survey_available_count
                            , survey_increased_count
                            , city_code
                            , statistics_time
                            , latest_statistics_id
                            , visit_execution_time
                            , survey_create_time)
                            SELECT @VisitTotalCount,@VisitAvailableCount,
                            @VisitIncreasedCount,
                            @SurveyTotalCount,@SurveyAvailableCount,
                            @SurveyIncreasedCount,
                            @CityCode,@StatisticsTime,@LatestStatisticsId,@LastVisitExecutionTime,@LastSurveyCreateTime";
            return await m_context.ExecuteScalarAsync(sql, visitSurveyStatistics);
        }
        public async Task<int> UpdateAsync(VisitSurveyStatistics visitSurveyStatistics)
        {
            string sql = @"UPDATE statistics_visit_survey_newest SET
                              visit_total_count=@VisitTotalCount
                            , visit_available_count=@VisitAvailableCount
                            , visit_increased_count=@VisitIncreasedCount
                            , survey_total_count=@SurveyTotalCount
                            , survey_available_count=@SurveyAvailableCount
                            , survey_increased_count=@SurveyIncreasedCount
                            , city_code=@CityCode
                            , statistics_time=@StatisticsTime
                            , visit_execution_time=@LastVisitExecutionTime
                            , survey_create_time=@LastSurveyCreateTime
                           WHERE id = @Id";
            return await m_context.ExecuteAsync(sql, visitSurveyStatistics);
        }


        public async Task<dynamic> CalculateSumOfLatestAllCityLatest()
        {
            string sql = @"SELECT
                            SUM(b.visit_total_count) VisitCount,SUM(b.survey_total_count) SurveyCount,COUNT(b.id) CityCount
                            FROM
	                            (
		                            SELECT
			                            city_code,
			                            MAX(id) id
		                            FROM
			                            statistics_visit_survey_newest
		                            GROUP BY
			                            city_code
	                            ) a
                            JOIN statistics_visit_survey_newest b ON a.id = b.id
                            AND a.city_code = b.city_code";
            return await m_context.QueryFirstOrDefaultAsync<dynamic>(sql);
        }
        public async Task<VisitSurveyStatistics> GetByCityAsync(string cityDomain)
        {
            string sql = $@"SELECT id AS Id
                            , visit_total_count AS VisitTotalCount
                            , visit_available_count AS VisitAvailableCount
                            , visit_increased_count AS VisitIncreasedCount
                            , survey_total_count AS SurveyTotalCount
                            , survey_available_count AS SurveyAvailableCount
                            , survey_increased_count AS SurveyIncreasedCount
                            , city_code AS CityCode
                            , statistics_time AS StatisticsTime
                            , visit_execution_time AS LastVisitExecutionTime
                            , survey_create_time AS LastSurveyCreateTime
                            FROM statistics_visit_survey_newest
                            WHERE city_code='{cityDomain}'";
            return await m_context.QueryFirstOrDefaultAsync<VisitSurveyStatistics>(sql);
        }
        public async Task<int> AddOrUpdateAsync(VisitSurveyStatistics visitSurveyStatistics)
        {
            var visitSurveyExists = await GetByCityAsync(visitSurveyStatistics.CityCode);
            if (visitSurveyExists == null)
            {
                return await AddAsync(visitSurveyStatistics);
            }
            else
            {
                visitSurveyStatistics.Id = visitSurveyExists.Id;
                return await UpdateAsync(visitSurveyStatistics);
            }
        }

    }
}
﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class AcquisitionTotalRepository
    {
        private readonly DapperDBContext m_context;
        private readonly Dictionary<string, string> m_orderMapping;

        public AcquisitionTotalRepository(DapperDBContext context)
        {
            m_context = context;
        }

        public async Task<IEnumerable<AcquisitionTotal>> GetByPageAsync(int limit, int page, string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code in ({filter})";
            string sql = $@"SELECT id AS Id
                            , total_house_count AS TotalHouseCount
                            , second_house_count AS SecondHouseCount
                            , rent_house_count AS RentHouseCount
                            , statistics_time StatisticsTime
                            FROM statistics_latest {where}
                            ORDER BY id DESC
                            LIMIT {limit * (page - 1)},{limit}";
            return await m_context.QueryAsync<AcquisitionTotal>(sql);
        }

        public async Task<int> GetTotalCount(string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code in ({filter})";
            string sql = $@"SELECT COUNT(DISTINCT city_code) FROM acquisition_total {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> AddAsync(AcquisitionTotal acquisitionHouse)
        {
            string sqlSelect = $@"SELECT COUNT(*)
                                  FROM acquisition_total
                                  WHERE statistics_time='{acquisitionHouse.StatisticsTime}'";
            int existsCount = await m_context.ExecuteScalarAsync(sqlSelect);
            if (existsCount > 0)
            {
                return 0;
            }
            string sql = $@"INSERT INTO acquisition_total (total_house_count
                            , total_house_increased_count
                            , second_house_count
                            , second_house_increased_count
                            , rent_house_count
                            , rent_house_increased_count
                            , statistics_time)
                            SELECT @TotalHouseCount,@TotalHouseIncreasedCount,
                            @SecondHouseCount,@SecondHouseIncreasedCount,
                            @RentHouseCount,@RentHouseIncreasedCount,@StatisticsTime";
            return await m_context.ExecuteAsync(sql, acquisitionHouse);
        }

        public async Task<AcquisitionTotal> GetLatestAsync()
        {
            string sql = $@"SELECT id AS Id
                            ,total_house_count AS TotalHouseCount
                            , total_house_increased_count AS TotalHouseIncreasedCount
                            , second_house_count AS SecondHouseCount
                            , second_house_increased_count AS SecondHouseIncreasedCount
                            , rent_house_count AS RentHouseCount
                            , rent_house_increased_count AS RentHouseIncreasedCount
                            , statistics_time AS StatisticsTime
                            FROM acquisition_total
                            WHERE id=(SELECT MAX(id) FROM acquisition_total)";
            return await m_context.QueryFirstOrDefaultAsync<AcquisitionTotal>(sql);
        }
    }
}
﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class ServiceDetectionRepository
    {
        private readonly DapperDBContext m_context;
        private readonly Dictionary<string, string> m_orderMapping;

        public ServiceDetectionRepository(DapperDBContext context)
        {
            m_context = context;
            m_orderMapping = new Dictionary<string, string>();
            m_orderMapping.Add("accessibleRate", "accessible_rate");
            m_orderMapping.Add("totalAccessibleCount", "total_accessible_count");
            m_orderMapping.Add("unableAccessibleCount", "unable_accessible_count");
            m_orderMapping.Add("bigthan5sAccessibleCount", "bigthan5s_accessible_count");
            m_orderMapping.Add("bigthan2sAccessibleCount", "bigthan2s_accessible_count");
            m_orderMapping.Add("lastUnableAccessibleTime", "last_unable_accessible_time");
            m_orderMapping.Add("lastResponseDuration", @"(case last_accessible_state
                                                            when 'red' then 15
                                                           else last_response_duration
                                                           end)");
            m_orderMapping.Add("lastAccessibleTime", "last_accessible_time");
            m_orderMapping.Add("lastAccessibleState", @"(case last_accessible_state
                                                            when 'red' then 1
                                                            when 'yellow' then 2
                                                            when 'green' then 3
                                                         else 4
                                                         end)");
        }

        public async Task<ServiceDetection> GetByIDAsync(int id)
        {
            string sql = @"SELECT id AS Id
                            , city_code AS CityCode
                            , accessible_rate AS AccessibleRate
                            , total_accessible_count AS TotalAccessibleCount
                            , unable_accessible_count AS UnableAccessibleCount
                            , bigthan5s_accessible_count AS Bigthan5sAccessibleCount
                            , bigthan2s_accessible_count AS Bigthan2sAccessibleCount
                            , last_unable_accessible_time AS LastUnableAccessibleTime
                            , last_accessible_state AS LastAccessibleState
                            , last_response_duration AS LastResponseDuration
                            , last_accessible_time AS LastAccessibleTime
                            , ip AS Ip
                            , service_type AS ServiceType
                            FROM service_detection
                            WHERE id = @Id";
            return await m_context.QueryFirstOrDefaultAsync<ServiceDetection>(sql, new { Id = id });
        }

        public async Task<ServiceDetection> GetByCityAndService(string cityCode, int serviceType)
        {
            string sql = $@"SELECT id AS Id
                            , city_code AS CityCode
                            , accessible_rate AS AccessibleRate
                            , total_accessible_count AS TotalAccessibleCount
                            , unable_accessible_count AS UnableAccessibleCount
                            , bigthan5s_accessible_count AS Bigthan5sAccessibleCount
                            , bigthan2s_accessible_count AS Bigthan2sAccessibleCount
                            , last_unable_accessible_time AS LastUnableAccessibleTime
                            , last_accessible_state AS LastAccessibleState
                            , last_response_duration AS LastResponseDuration
                            , last_accessible_time AS LastAccessibleTime
                            , ip AS Ip
                            , service_type AS ServiceType
                            FROM service_detection
                            WHERE city_code = '{cityCode}' AND service_type = {serviceType}";
            return await m_context.QueryFirstOrDefaultAsync<ServiceDetection>(sql);
        }

        public async Task<IEnumerable<ServiceDetection>> GetByPageAsync(PageRequest request)
        {
            string serviceTypeCondition = "WHERE " + (request.ServiceType == 0 ? 
                "1=1 " : $@" service_type={request.ServiceType} ");
            string cityCodeCondition = "AND " + (string.IsNullOrWhiteSpace(request.Filter) ? 
                "1=1 " : $@" city_code in ({request.Filter}) ");
            string where = serviceTypeCondition + cityCodeCondition;
            string sql = $@"SELECT id AS Id
                            , city_code AS CityCode
                            , accessible_rate AS AccessibleRate
                            , total_accessible_count AS TotalAccessibleCount
                            , unable_accessible_count AS UnableAccessibleCount
                            , bigthan5s_accessible_count AS Bigthan5sAccessibleCount
                            , bigthan2s_accessible_count AS Bigthan2sAccessibleCount
                            , last_unable_accessible_time AS LastUnableAccessibleTime
                            , last_accessible_state AS LastAccessibleState
                            , last_response_duration AS LastResponseDuration
                            , last_accessible_time AS LastAccessibleTime
                            , ip AS Ip
                            , service_type AS ServiceType
                            FROM service_detection {where}
                            ORDER BY {m_orderMapping[request.Field]} {request.Order} 
                            {(request.Field == "lastUnableAccessibleTime" ? ",accessible_rate ASC" : "")}
                            LIMIT {request.Limit * (request.Page - 1)},{request.Limit}";
            return await m_context.QueryAsync<ServiceDetection>(sql);
        }

        public async Task<int> GetTotalCount(string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code in ({filter})";
            string sql = $@"SELECT COUNT(*) FROM service_detection {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> AddAsync(ServiceDetection serviceDetection)
        {
            string sql = $@"INSERT INTO service_detection (city_code
                            , accessible_rate
                            , total_accessible_count
                            , unable_accessible_count
                            , bigthan5s_accessible_count
                            , bigthan2s_accessible_count
                            , last_unable_accessible_time
                            , last_accessible_state
                            , last_response_duration
                            , last_accessible_time
                            , ip
                            , service_type)
                            SELECT @CityCode,@AccessibleRate,
                            @TotalAccessibleCount,
                            @UnableAccessibleCount,@Bigthan5sAccessibleCount,
                            @Bigthan2sAccessibleCount,@LastUnableAccessibleTime,
                            @LastAccessibleState,@LastResponseDuration,@LastAccessibleTime,@Ip,@ServiceType";
            return await m_context.ExecuteAsync(sql, serviceDetection);
        }

        public async Task<bool> UpdateAsync(ServiceDetection serviceDetection)
        {
            string sql = @"UPDATE service_detection SET
                              city_code = @CityCode
                            , accessible_rate = @AccessibleRate
                            , total_accessible_count = @TotalAccessibleCount
                            , unable_accessible_count = @UnableAccessibleCount
                            , bigthan5s_accessible_count = @Bigthan5sAccessibleCount
                            , bigthan2s_accessible_count = @Bigthan2sAccessibleCount
                            , last_unable_accessible_time = @LastUnableAccessibleTime
                            , last_accessible_state = @LastAccessibleState
                            , last_response_duration = @LastResponseDuration
                            , last_accessible_time = @LastAccessibleTime
                            , ip = @Ip
                           WHERE id = @Id AND service_type = @ServiceType";
            return await m_context.ExecuteAsync(sql, serviceDetection) > 0;
        }

        public async Task<ServiceDetection> GetByCityCodeServiceType(string cityCode, int serviceType)
        {
            string where = string.IsNullOrWhiteSpace(cityCode) ? "" : $@"WHERE city_code in ({cityCode})";
            string sql = $@"SELECT id AS Id
                            , city_code AS CityCode
                            , accessible_rate AS AccessibleRate
                            , total_accessible_count AS TotalAccessibleCount
                            , unable_accessible_count AS UnableAccessibleCount
                            , bigthan5s_accessible_count AS Bigthan5sAccessibleCount
                            , bigthan2s_accessible_count AS Bigthan2sAccessibleCount
                            , last_unable_accessible_time AS LastUnableAccessibleTime
                            , last_accessible_state AS LastAccessibleState
                            , last_response_duration AS LastResponseDuration
                            , last_accessible_time AS LastAccessibleTime
                            , ip AS Ip
                            , service_type AS ServiceType
                            FROM service_detection
                            WHERE city_code='{cityCode}' AND service_type={serviceType}";
            return await m_context.QueryFirstOrDefaultAsync<ServiceDetection>(sql);
        }

        public async Task<IEnumerable<ServiceDetection>> GetForInputSearch(int limit, int page, string filterCities)
        {
            string where = $@"WHERE city_code in ({filterCities})";
            string sql = $@"SELECT id AS Id
                            , city_code AS CityCode
                            , accessible_rate AS AccessibleRate
                            , total_accessible_count AS TotalAccessibleCount
                            , unable_accessible_count AS UnableAccessibleCount
                            , bigthan5s_accessible_count AS Bigthan5sAccessibleCount
                            , bigthan2s_accessible_count AS Bigthan2sAccessibleCount
                            , last_unable_accessible_time AS LastUnableAccessibleTime
                            , last_accessible_state AS LastAccessibleState
                            , last_response_duration AS LastResponseDuration
                            , last_accessible_time AS LastAccessibleTime
                            , ip AS Ip
                            , service_type AS ServiceType
                            FROM service_detection {where}
                            ORDER BY city_code, service_type
                            LIMIT {limit * (page - 1)},{limit}";
            return await m_context.QueryAsync<ServiceDetection>(sql);
        }
    }
}
﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Repository
{
    public class LatestStatisticsRepository
    {
        private readonly DapperDBContext m_context;

        public LatestStatisticsRepository(DapperDBContext context)
        {
            m_context = context;
        }

        public async Task<IEnumerable<LatestStatistics>> GetByPageAsync(int limit, int page, string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code in ({filter})";
            string sql = $@"SELECT id AS Id
                            , house_count AS HouseCount
                            , house_demand_count AS HouseDemandCount
                            , track_count AS TrackCount
                            , visit_count AS VisitCount
                            , survey_count AS SurveyCount
                            , statistics_time StatisticsTime
                            FROM statistics_latest {where}
                            ORDER BY id DESC
                            LIMIT {limit * (page - 1)},{limit}";
            return await m_context.QueryAsync<LatestStatistics>(sql);
        }

        public async Task<int> GetTotalCount(string filter)
        {
            string where = string.IsNullOrWhiteSpace(filter) ? "" : $@"WHERE city_code='{filter}'";
            string sql = $@"SELECT COUNT(*) FROM statistics_latest {where}";
            return await m_context.ExecuteScalarAsync(sql);
        }

        public async Task<int> AddAsync(LatestStatistics latestStatistics)
        {
            string sql = $@"INSERT INTO statistics_latest (
                              house_count
                            , house_increased_count
                            , house_demand_count
                            , house_increased_demand_count
                            , track_count
                            , track_increased_count
                            , visit_count
                            , visit_increased_count
                            , survey_count
                            , survey_increased_count
                            , statistics_time)
                            SELECT @HouseCount,@HouseIncreasedCount,
                            @HouseDemandCount,@HouseIncreasedDemandCount,
                            @TrackCount,@TrackIncreasedCount,
                            @VisitCount,@VisitIncreasedCount,
                            @SurveyCount,@SurveyIncreasedCount,
                            @StatisticsTime";
            return await m_context.ExecuteScalarAsync(sql, latestStatistics);
        }

        public async Task<LatestStatistics> GetLatestAsync()
        {
            string sql = $@"SELECT id AS Id
                            , house_count AS HouseCount
                            , house_increased_count AS HouseIncreasedCount
                            , house_demand_count AS HouseDemandCount
                            , house_increased_demand_count AS HouseIncreasedDemandCount
                            , track_count AS TrackCount
                            , track_increased_count AS TrackIncreasedCount
                            , visit_count AS VisitCount
                            , visit_increased_count AS VisitIncreasedCount
                            , survey_count AS SurveyCount
                            , survey_increased_count AS SurveyIncreasedCount
                            , statistics_time StatisticsTime
                            FROM statistics_latest
                            WHERE id=(SELECT MAX(id) FROM statistics_latest)";
            return await m_context.QueryFirstOrDefaultAsync<LatestStatistics>(sql);
        }
    }
}
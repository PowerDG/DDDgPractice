﻿using Fooww.DataStatistics.Web.Helper;
using Fooww.DataStatistics.Web.Models;
using Fooww.DataStatistics.Web.Repository;
using Fooww.DataStatistics.Web.ViewModels;
using Fooww.DataStatistics.Web.ViewModels.Home;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Services
{
    public class HomeService
    {
        private readonly IConfiguration m_configuration;
        private readonly HouseStatisticsRepository m_houseRepository;
        private readonly DemandStatisticsRepository m_demandRepository;
        private readonly TrackStatisticsRepository m_trackRepository;
        private readonly VisitSurveyStatisticsRepository m_visitSurveyRepository;
        private readonly LatestStatisticsRepository m_latestRepository;
        private readonly ServiceDetectionRepository m_serviceDetection;
        private readonly ServiceExceptionRepository m_serviceException;
        private readonly AcquisitionTotalRepository m_acquisitionTotal;
        private readonly AcquisitionHouseRepository m_acquisitionHouse;

        private readonly NewestAcquisitionHouseRepository m_newestAcquisitionHouse;
        private readonly NewestVisitSurveyStatisticsRepository m_newestVisitSurveyStatistics;
        private readonly NewestTrackStatisticsRepository m_newestTrackStatistics;
        private readonly NewestHouseStatisticsRepository m_newestHouseStatistics;
        private readonly NewestDemandStatisticsRepository m_newestDemandStatistics;

        public HomeService(IConfiguration configuration, HouseStatisticsRepository houseRepository,
            TrackStatisticsRepository trackRepository, LatestStatisticsRepository latestRepository,
            DemandStatisticsRepository demandRepository, VisitSurveyStatisticsRepository visitSurveyRepository,
            ServiceDetectionRepository serviceDetection, ServiceExceptionRepository serviceException,
            AcquisitionTotalRepository acquisitionTotal, AcquisitionHouseRepository acquisitionHouse,
            NewestAcquisitionHouseRepository newestAcquisitionHouse, NewestTrackStatisticsRepository newestTrackStatistics,
            NewestHouseStatisticsRepository newestHouseStatistics, NewestDemandStatisticsRepository newestDemandStatistics,
            NewestVisitSurveyStatisticsRepository newestVisitSurveyStatistics)
        {
            m_configuration = configuration;
            m_houseRepository = houseRepository;
            m_demandRepository = demandRepository;
            m_latestRepository = latestRepository;
            m_trackRepository = trackRepository;
            m_visitSurveyRepository = visitSurveyRepository;
            m_serviceDetection = serviceDetection;
            m_serviceException = serviceException;
            m_acquisitionTotal = acquisitionTotal;
            m_acquisitionHouse = acquisitionHouse;
            m_newestAcquisitionHouse = newestAcquisitionHouse;
            m_newestVisitSurveyStatistics = newestVisitSurveyStatistics;
            m_newestTrackStatistics = newestTrackStatistics;
            m_newestHouseStatistics = newestHouseStatistics;
            m_newestDemandStatistics = newestDemandStatistics;
        }

        public async Task<IndexViewModel> GetIndexViewModel()
        {
            return new IndexViewModel()
            {
                Statistics = await GetStatisticsModel(),
                Acquisition = await GetAcquisitionModel()
            };
        }

        private async Task<StatisticsViewModel> GetStatisticsModel()
        {
            var latestStatistics = await m_latestRepository.GetLatestAsync();
            var model = new StatisticsViewModel();
            if (latestStatistics != null)
            {
                model.HouseCount = latestStatistics.HouseCount;
                model.HouseIncreasedCount = latestStatistics.HouseIncreasedCount;
                model.DemandCount = latestStatistics.HouseDemandCount;
                model.DemandIncreasedCount = latestStatistics.HouseIncreasedDemandCount;
                model.TrackCount = latestStatistics.TrackCount;
                model.TrackIncreasedCount = latestStatistics.TrackIncreasedCount;
                model.VisitCount = latestStatistics.VisitCount;
                model.VisitIncreasedCount = latestStatistics.VisitIncreasedCount;
                model.SurveyCount = latestStatistics.SurveyCount;
                model.SurveyIncreasedCount = latestStatistics.SurveyIncreasedCount;
            }
            return model;
        }

        private async Task<AcquisitionViewModel> GetAcquisitionModel()
        {
            var acquisitionTotal = await m_acquisitionTotal.GetLatestAsync();
            var model = new AcquisitionViewModel();
            if (acquisitionTotal != null)
            {
                model.TotalHouseCount = acquisitionTotal.TotalHouseCount;
                model.TotalHouseIncreasedCount = acquisitionTotal.TotalHouseIncreasedCount;
                model.SecondHouseCount = acquisitionTotal.SecondHouseCount;
                model.SecondHouseIncreasedCount = acquisitionTotal.SecondHouseIncreasedCount;
                model.RentHouseCount = acquisitionTotal.RentHouseCount;
                model.RentHouseIncreasedCount = acquisitionTotal.RentHouseIncreasedCount;
            }
            return model;
        }

        public async Task<PageViewModel> GetHousePageData(PageRequest request)
        {
            IEnumerable<City> filterCities = GetFilterCities(request);
            if (filterCities.Count() == 0)
            {
                return new PageViewModel(null, 0);
            }
            var housePageData = await m_newestHouseStatistics.GetByPageAsync(request);
            var housePageDataResult = housePageData.Select(h => new
            {
                h.HouseTotalCount,
                h.HouseAvailableCount,
                h.HouseIncreasedCount,
                h.RentHouseTotalCount,
                h.RentHouseIncreasedCount,
                h.SecondHouseTotalCount,
                h.SecondHouseIncreasedCount,
                h.StatisticsTime,
                h.CityCode,
                City = filterCities.FirstOrDefault(c => c.Domain == h.CityCode).Name
            });
            int totalCount = await m_newestHouseStatistics.GetCountAsync(request.Filter);
            PageViewModel result = new PageViewModel();
            return new PageViewModel(housePageDataResult, totalCount);
        }

        public async Task<PageViewModel> GetDemandPageData(PageRequest request)
        {
            IEnumerable<City> filterCities = GetFilterCities(request);
            if (filterCities.Count() == 0)
            {
                return new PageViewModel(null, 0);
            }
            var demandPageData = await m_newestDemandStatistics.GetByPageAsync(request);
            var demandPageDataResult = demandPageData.Select(d => new
            {
                d.DemandTotalCount,
                d.DemandIncreasedCount,
                d.RentDemandTotalCount,
                d.RentDemandIncreasedCount,
                d.SecondDemandTotalCount,
                d.SecondDemandIncreasedCount,
                d.StatisticsTime,
                d.CityCode,
                City = filterCities.FirstOrDefault(c => c.Domain == d.CityCode).Name
            });
            int totalCount = await m_newestDemandStatistics.GetCountAsync(request.Filter);
            PageViewModel result = new PageViewModel();
            return new PageViewModel(demandPageDataResult, totalCount);
        }

        public async Task<PageViewModel> GetTrackPageData(PageRequest request)
        {
            IEnumerable<City> filterCities = GetFilterCities(request);
            if (filterCities.Count() == 0)
            {
                return new PageViewModel(null, 0);
            }
            var trackPageData = await m_newestTrackStatistics.GetByPageAsync(request);
            var trackPageDataResult = trackPageData.Select(t => new
            {
                t.TrackTotalCount,
                t.TrackAvailableCount,
                t.TrackIncreasedCount,
                t.HouseTrackTotalCount,
                t.HouseTrackIncreasedCount,
                t.DemandTrackTotalCount,
                t.DemandTrackIncreasedCount,
                t.StatisticsTime,
                t.CityCode,
                City = filterCities.FirstOrDefault(c => c.Domain == t.CityCode).Name
            });
            int totalCount = await m_newestTrackStatistics.GetCountAsync(request.Filter);
            PageViewModel result = new PageViewModel();
            return new PageViewModel(trackPageDataResult, totalCount);
        }

        public async Task<PageViewModel> GetVisitSurveyPageData(PageRequest request)
        {
            IEnumerable<City> filterCities = GetFilterCities(request);
            if (filterCities.Count() == 0)
            {
                return new PageViewModel(null, 0);
            }
            var visitSurveyPageData = await m_newestVisitSurveyStatistics.GetByPageAsync(request);
            var visitSurveyPageDataResult = visitSurveyPageData.Select(v => new
            {
                v.VisitTotalCount,
                v.VisitAvailableCount,
                v.VisitIncreasedCount,
                v.SurveyTotalCount,
                v.SurveyAvailableCount,
                v.SurveyIncreasedCount,
                v.StatisticsTime,
                v.CityCode,
                City = filterCities.FirstOrDefault(c => c.Domain == v.CityCode).Name
            });
            int totalCount = await m_newestVisitSurveyStatistics.GetCountAsync(request.Filter);
            PageViewModel result = new PageViewModel();
            return new PageViewModel(visitSurveyPageDataResult, totalCount);
        }

        public async Task<PageViewModel> GetServiceDetectionPageData(PageRequest request)
        {
            IEnumerable<City> filterCities = GetFilterCities(request);
            if (filterCities.Count() == 0)
            {
                return new PageViewModel(null, 0);
            }
            var serviceDetectionPageData = await m_serviceDetection.GetByPageAsync(request);
            var serviceDetectionPageDataResult = serviceDetectionPageData.Select(d => new
            {
                d.Id,
                d.CityCode,
                AccessibleRate = Math.Round(d.AccessibleRate * 100, 2),
                d.TotalAccessibleCount,
                d.UnableAccessibleCount,
                d.Bigthan5sAccessibleCount,
                d.Bigthan2sAccessibleCount,
                LastUnableAccessibleTime = d.LastUnableAccessibleTime.ToFormatString(),
                d.LastAccessibleState,
                d.LastResponseDuration,
                LastAccessibleTime = d.LastAccessibleTime.ToFormatString(),
                d.Ip,
                d.ServiceType,
                City = filterCities.FirstOrDefault(c => c.Domain == d.CityCode).Name
            });
            int totalCount = await m_serviceDetection.GetTotalCount(request.Filter);
            PageViewModel result = new PageViewModel();
            return new PageViewModel(serviceDetectionPageDataResult, totalCount);
        }

        public async Task<GetServiceDetectionByCityViewModel> GetServiceDetectionDetail(int detectionId)
        {
            GetServiceDetectionByCityViewModel result;
            ServiceDetection model = await m_serviceDetection.GetByIDAsync(detectionId);
            result = new GetServiceDetectionByCityViewModel
            {
                Id = model.Id,
                CityCode = model.CityCode,
                CityName = m_configuration.GetSection("foowwcities").Get<List<City>>()
                    .FirstOrDefault(c => c.Domain == model.CityCode).Name,
                Domain = model.ServiceType != 2 ? $"{model.CityCode}.fooww.com" : $"{model.CityCode}.fooww.biz",
                Ip = model.Ip,
                LastAccessibleState = model.LastAccessibleState,
                AccessibleRate = Math.Round(model.AccessibleRate * 100, 2) + "%",
                LastResponseDuration = model.LastAccessibleState == "red" ? "不可访问" : $"{model.LastResponseDuration}s",
                ServiceType = model.ServiceType,
                LastUnableAccessibleTime = model.LastUnableAccessibleTime.ToFormatString(),
                UnableAccessibleCount = model.UnableAccessibleCount,
                Bigthan5sAccessibleCount = model.Bigthan5sAccessibleCount
            };
            return result;
        }

        public async Task<GetServiceDetectionByCityViewModel> GetServiceDetectionDetail(string cityCode,int serviceType)
        {
            GetServiceDetectionByCityViewModel result;
            ServiceDetection model = await m_serviceDetection.GetByCityAndService(cityCode, serviceType);
            result = new GetServiceDetectionByCityViewModel
            {
                Id = model.Id,
                CityCode = model.CityCode,
                CityName = m_configuration.GetSection("foowwcities").Get<List<City>>()
                    .FirstOrDefault(c => c.Domain == model.CityCode).Name,
                Domain = model.ServiceType != 2 ? $"{model.CityCode}.fooww.com" : $"{model.CityCode}.fooww.biz",
                Ip = model.Ip,
                LastAccessibleState = model.LastAccessibleState,
                AccessibleRate = Math.Round(model.AccessibleRate * 100, 2) + "%",
                LastResponseDuration = model.LastAccessibleState == "red" ? "不可访问" : $"{model.LastResponseDuration}s",
                ServiceType = model.ServiceType,
                LastUnableAccessibleTime = model.LastUnableAccessibleTime.ToFormatString(),
                UnableAccessibleCount = model.UnableAccessibleCount,
                TotalAccessibleCount = model.TotalAccessibleCount,
                Bigthan5sAccessibleCount = model.Bigthan5sAccessibleCount
            };
            return result;
        }

        public async Task<PageViewModel> GetServiceExceptionPageData(PageRequest request)
        {
            var city = m_configuration.GetSection("foowwcities").Get<List<City>>()
                .Where(c => c.Domain == request.Filter.Split(',')[0]).FirstOrDefault();

            var serviceExceptionPageData = await m_serviceException.GetByPageAsync(request);
            var serviceExceptionPageDataResult = serviceExceptionPageData.Select(d => new
            {
                City = city.Name,
                ServiceType = d.ServiceType,
                ResponseTime = d.IsAccessible == 1 ? d.ResponseDuration + "s" : "不可访问",
                d.AccessibleTime
            });
            int totalCount = await m_serviceException.GetTotalCount(request.Filter);
            PageViewModel result = new PageViewModel();
            return new PageViewModel(serviceExceptionPageDataResult, totalCount);
        }

        public async Task<List<List<string>>> GetServiceExceptionDataForChart(string cityCode, int serviceType, int intervalHour)
        {
            List<List<string>> result = new List<List<string>>();
            var currentTime = DateTime.Now;
            var serviceExceptions = await m_serviceException.GetForChart(cityCode, serviceType,
                currentTime.ToString("yyyy-MM-dd HH:mm"), intervalHour);
            for (int i = 1; i <= 60 * intervalHour; i++)
            {
                bool flag = false;
                var time = currentTime.AddMinutes(-i).ToString("yyyy-MM-dd HH:mm");
                List<string> accessibleTime = new List<string>();
                accessibleTime.Add(time);
                foreach (var serviceException in serviceExceptions)
                {
                    if (serviceException.AccessibleTime.ToString("yyyy-MM-dd HH:mm") == time)
                    {
                        flag = true;
                        var responseTime = ClassifyResponseTime(serviceException.ResponseDuration, serviceException.IsAccessible);
                        accessibleTime.Add(responseTime.ToString());
                    }
                }
                if (!flag)
                {
                    accessibleTime.Add("0");
                }
                result.Add(accessibleTime);
            }
            return result;
        }

        private int ClassifyResponseTime(double responseTime, int isAccessible)
        {
            var type = 0;
            if (isAccessible == 1)
            {
                if (responseTime <= 2)
                {
                    type = 0;
                }
                else if (responseTime <= 5)
                {
                    type = 5;
                }
                else
                {
                    type = 15;
                }
            }
            else
            {
                type = 15;
            }
            return type;
        }

        public IEnumerable<dynamic> GetCities(string filter)
        {
            var cities = m_configuration.GetSection("foowwcities").Get<List<City>>()
                 .Where(city => (city.Alias_Name.Contains(filter) || city.Name.Contains(filter)) && city.Vip_Enable != "0")
                 .OrderBy(city => city.Domain).Take(10);
            return cities.Select(city => new
            {
                Id=city.Domain,
                Name=city.Name
            });
        }


        private IEnumerable<City> GetFilterCities(PageRequest request)
        {
            IEnumerable<City> filterCities;
            if (string.IsNullOrWhiteSpace(request.Filter))
            {
                filterCities = m_configuration.GetSection("foowwcities").Get<List<City>>().Where(c => c.Is_Deleted == "0");
                request.Filter = "";
            }
            else
            {
                request.Filter = request.Filter.ToLower();
                filterCities = m_configuration.GetSection("foowwcities").Get<List<City>>()
                    .Where(c => c.Alias_Name.Contains(request.Filter) || c.Name.Contains(request.Filter)).ToList();
                if (filterCities.Count() > 0)
                {
                    request.Filter = string.Join(",", filterCities.Select(f => $@"'{f.Domain}'"));
                }
            }
            return filterCities;
        }

        public async Task<PageViewModel> GetAcquisitionPageData(PageRequest request)
        {
            IEnumerable<City> filterCities = GetFilterCities(request);
            if (filterCities.Count() == 0)
            {
                return new PageViewModel(null, 0);
            }
            var housePageData = await m_newestAcquisitionHouse.GetByPageAsync(request);
            var housePageDataResult = housePageData.Select(h => new
            {
                h.TotalCount,
                TotalIncreasedCount=h.IncreasedCount,
                h.SecondTotalCount,
                h.RentTotalCount,
                h.StatisticsTime,
                h.CityCode,
                City = filterCities.FirstOrDefault(c => c.Domain == h.CityCode).Name
            });
            int totalCount = await m_newestAcquisitionHouse.GetCountAsync(request.Filter);
            PageViewModel result = new PageViewModel();
            return new PageViewModel(housePageDataResult, totalCount);
        }

        public async Task<List<List<string>>[]> GetStatisticsDataForCharts(string cityCode, string chartId)
        {
            List<List<string>>[] result= new List<List<string>>[3] 
            {
                new List<List<string>>(),new List<List<string>>(),new List<List<string>>()
            };
            var operationDictionary = new Dictionary<string, Func<string, Task<IEnumerable<dynamic>>>>
            {
                { "houseNew", m_houseRepository.GetTotalCountListByYear },
                { "houseAdd", m_houseRepository.GetTotalIncreasedCountListByYear },
                { "demandNew", m_demandRepository.GetTotalCountListByYear },
                { "demandAdd", m_demandRepository.GetTotalIncreasedCountListByYear },
                { "trackNew", m_trackRepository.GetTotalCountListByYear },
                { "trackAdd", m_trackRepository.GetTotalIncreasedCountListByYear },
                { "visitSurveyNew", m_visitSurveyRepository.GetTotalCountListByYear },
                { "visitSurveyAdd", m_visitSurveyRepository.GetTotalIncreasedCountListByYear },
                { "acquisitionNew", m_acquisitionHouse.GetTotalCountListByYear },
                { "acquisitionAdd", m_acquisitionHouse.GetTotalIncreasedCountListByYear }
            };
            IEnumerable<dynamic> queryResult = await operationDictionary[chartId].Invoke(cityCode);

            GenerateResultList(result, queryResult, chartId);
            return result;
        }

        private void GenerateResultList(List<List<string>>[] result, IEnumerable<dynamic> queryResult, string chartId)
        {
            DateTime start = DateTime.Now.AddMonths(-12);
            DateTime lastStatisticsTime = Convert.ToDateTime(queryResult.LastOrDefault().StatisticsTime);
            for (int month = 1; month < 13; month++)
            {
                DateTime monthStartDay = new DateTime(start.AddMonths(month).Year, start.AddMonths(month).Month, 1);
                DateTime monthMiddleDay = new DateTime(start.AddMonths(month).Year, start.AddMonths(month).Month, 15);
                DateTime monthEndDay = new DateTime(start.AddMonths(month).Year, start.AddMonths(month + 1).Month, 1);
                bool existsMonthStartDay = false;
                bool existsMonthMiddleDay = false;
                foreach (var item in queryResult)
                {
                    DateTime statisticsTime = Convert.ToDateTime(item.StatisticsTime);
                    bool isMonthStart = DateTime.Compare(statisticsTime, monthStartDay) >= 0 
                        && DateTime.Compare(statisticsTime, monthMiddleDay) < 0;
                    bool isMonthMiddle = DateTime.Compare(statisticsTime, monthMiddleDay) >= 0
                        && DateTime.Compare(statisticsTime, monthEndDay) < 0;
                    if (isMonthStart && !existsMonthStartDay)
                    {
                        AddItemToResult(result, statisticsTime, item, chartId);
                        existsMonthStartDay = true;
                    }
                    if (isMonthMiddle && !existsMonthMiddleDay)
                    {
                        AddItemToList(existsMonthStartDay, monthStartDay, result);
                        AddItemToResult(result, statisticsTime, item, chartId);
                        existsMonthStartDay = true;
                        existsMonthMiddleDay = true;
                        break;
                    }
                }
                if(monthStartDay < lastStatisticsTime)
                {
                    AddItemToList(existsMonthStartDay, monthStartDay, result);
                }
                if (monthMiddleDay < lastStatisticsTime)
                {
                    AddItemToList(existsMonthMiddleDay, monthMiddleDay, result);
                }
            }
            //添加最后一天统计信息
            AddItemToResult(result, Convert.ToDateTime(queryResult.LastOrDefault().StatisticsTime), 
                queryResult.LastOrDefault(), chartId);
        }

        private void AddItemToResult(List<List<string>>[] result, DateTime statisticsTime, dynamic item, string chartId)
        {
            List<string> count1 = new List<string>();
            count1.Add(statisticsTime.ToString("yyyy-MM-dd"));
            count1.Add(Convert.ToString(item.TotalCount1));
            result[0].Add(count1);

            List<string> count2 = new List<string>();
            count2.Add(statisticsTime.ToString("yyyy-MM-dd"));
            count2.Add(Convert.ToString(item.TotalCount2));
            result[1].Add(count2);
            if (chartId != "visitSurveyNew" && chartId != "visitSurveyAdd")
            {
                List<string> count3 = new List<string>();
                count3.Add(statisticsTime.ToString("yyyy-MM-dd"));
                count3.Add(Convert.ToString(item.TotalCount3));
                result[2].Add(count3);
            }
        }

        private void AddItemToList(bool condition, DateTime date, List<List<string>>[] result)
        {
            if (!condition)
            {
                List<string> count = new List<string>();
                count.Add(date.ToString("yyyy-MM-dd"));
                count.Add(null);
                result[0].Add(count);
                result[1].Add(count);
                result[2].Add(count);
            }
        }

        public async Task<PageViewModel> GetServiceDetectionViewPageData(PageRequest request)
        {
            IEnumerable<City> filterCities = m_configuration.GetSection("foowwcities").Get<List<City>>();
            bool isSearchByCity = request.Filter == null ? true : !Regex.IsMatch(request.Filter, @"^[0-9]");
            if (isSearchByCity)
            {
                filterCities = GetFilterCities(request);
            }
            var serviceExceptionPageData = await m_serviceException.GetByDateAndServiceTypeAsync(request);
            if (serviceExceptionPageData.Count() == 0)
            {
                return new PageViewModel(null, 0);
            }
            var serviceExceptionPageDataResult = serviceExceptionPageData.Select(d => new
            {
                City = filterCities.FirstOrDefault(c => c.Domain == d.CityCode).Name,
                ServiceType = d.ServiceType,
                ResponseTime = d.IsAccessible == 1 ? d.ResponseDuration + "s" : "不可访问",
                d.AccessibleTime,
                Ip = d.Ip
            });
            int totalCount = await m_serviceException.GetTotalCountByDateAndServiceTypeAsync(request);
            PageViewModel result = new PageViewModel();
            return new PageViewModel(serviceExceptionPageDataResult, totalCount);
        }
    }
}
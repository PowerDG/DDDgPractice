﻿using Fooww.DataStatistics.Web.Models;
using Fooww.DataStatistics.Web.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Services
{
    public class NewsAnalysisService
    {
        private readonly NewsRepository m_newsRepository;
        private readonly NewsCompanyRepository m_newsCompanyRepository;
        private readonly NewsWordCountRepository m_newsWordCountRepository;
        public NewsAnalysisService(NewsRepository newsRepository, NewsCompanyRepository newsCompanyRepository, 
            NewsWordCountRepository newsWordCountRepository)
        {
            m_newsRepository = newsRepository;
            m_newsCompanyRepository = newsCompanyRepository;
            m_newsWordCountRepository = newsWordCountRepository;
        }

        public async Task<IEnumerable<News>> GetNews()
        {
            return await m_newsRepository.GetAllAsync();
        }
        public async Task<IEnumerable<News>> GetNews(int companyId, string titleFilter, DateTime startTime,
            DateTime endTime, int page, int limit)
        {
            return await m_newsRepository.GetByPageAsync(companyId, titleFilter, startTime, endTime, page, limit);
        }
        public async Task<int> GetNewsCount(int companyId, string titleFilter, DateTime startTime,DateTime endTime)
        {
            return await m_newsRepository.GetTotalCount(companyId, titleFilter, startTime, endTime);
        }

        public async Task<IEnumerable<NewsCompany>> GetNewsCompany()
        {
            return await m_newsCompanyRepository.GetAllAsync();
        }

        public async Task<IEnumerable<NewsWordCount>> GetNewsWordCount()
        {
            return await m_newsWordCountRepository.GetAllAsync();
        }
        public async Task<IEnumerable<NewsWordCount>> GetNewsWordCount(int companyId)
        {
            return await m_newsWordCountRepository.GetByCompanyIdAsync(companyId);
        }

    }
}

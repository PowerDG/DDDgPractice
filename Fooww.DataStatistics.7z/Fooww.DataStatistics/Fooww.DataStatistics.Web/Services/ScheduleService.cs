﻿using Fooww.DataStatistics.Web.Helper;
using Fooww.DataStatistics.Web.Models;
using Fooww.DataStatistics.Web.Repository;
using Hangfire;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Services
{
    public class ScheduleService
    {
        private readonly IConfiguration m_configuration;
        private readonly HouseStatisticsRepository m_houseRepository;
        private readonly DemandStatisticsRepository m_demandRepository;
        private readonly TrackStatisticsRepository m_trackRepository;
        private readonly VisitSurveyStatisticsRepository m_visitSurveyRepository;
        private readonly LatestStatisticsRepository m_latestRepository;
        private readonly ServiceDetectionRepository m_serviceDetection;
        private readonly ServiceExceptionRepository m_serviceException;
        private readonly AcquisitionHouseRepository m_acquisitionHouse;
        private readonly AcquisitionTotalRepository m_acquisitionTotal;

        private readonly NewestAcquisitionHouseRepository m_newestAcquisitionHouse;
        private readonly NewestVisitSurveyStatisticsRepository m_newestVisitSurveyStatistics;
        private readonly NewestTrackStatisticsRepository m_newestTrackStatistics;
        private readonly NewestHouseStatisticsRepository m_newestHouseStatistics;
        private readonly NewestDemandStatisticsRepository m_newestDemandStatistics;

        public ScheduleService(IConfiguration configuration, HouseStatisticsRepository houseRepository,
            DemandStatisticsRepository demandRepository, LatestStatisticsRepository latestRepository,
            TrackStatisticsRepository trackRepository, VisitSurveyStatisticsRepository visitSurveyRepository,
            ServiceDetectionRepository serviceDetection, ServiceExceptionRepository serviceException,
            AcquisitionHouseRepository acquisitionHouse, AcquisitionTotalRepository acquisitionTotal,
            NewestAcquisitionHouseRepository newestAcquisitionHouse, NewestTrackStatisticsRepository newestTrackStatistics,
            NewestHouseStatisticsRepository newestHouseStatistics, NewestDemandStatisticsRepository newestDemandStatistics,
            NewestVisitSurveyStatisticsRepository newestVisitSurveyStatistics)
        {
            m_configuration = configuration;
            m_houseRepository = houseRepository;
            m_demandRepository = demandRepository;
            m_latestRepository = latestRepository;
            m_trackRepository = trackRepository;
            m_visitSurveyRepository = visitSurveyRepository;
            m_serviceDetection = serviceDetection;
            m_serviceException = serviceException;
            m_acquisitionHouse = acquisitionHouse;
            m_acquisitionTotal = acquisitionTotal;
            m_newestAcquisitionHouse = newestAcquisitionHouse;
            m_newestVisitSurveyStatistics = newestVisitSurveyStatistics;
            m_newestTrackStatistics = newestTrackStatistics;
            m_newestHouseStatistics = newestHouseStatistics;
            m_newestDemandStatistics = newestDemandStatistics;
        }

        #region 数据统计

        public async Task<string> ExecuteAllCityWebServiceSY()
        {
            var cities = m_configuration.GetSection("foowwcities").Get<List<City>>().Where(c => c.Is_Deleted == "0");
            await GetCityWebServiceData("cz", 0);
            return $"sy城市service开始统计！";
        }

        [Queue("statistics")]
        public void StartSchedule()
        {
            var cities = m_configuration.GetSection("foowwcities").Get<List<City>>()
                .Where(c => c.Is_Deleted == "0" && c.Name != "公共");

            Task.Run(() =>
            {
                foreach (var city in cities)
                {
                    RecurringJob.AddOrUpdate<ScheduleService>($"GetCityWebServiceData-{city.Domain}",
                        s => s.GetCityWebServiceData(city.Domain, 0), m_configuration["RecurringJob:Statistics"]);
                }
                RecurringJob.AddOrUpdate<ScheduleService>(s => s.CalculateLatestStatistics(),
                    m_configuration["RecurringJob:StatisticsTotal"]);
                if (m_configuration["RecurringJob:ExecuteImmediate"] == "1")
                {
                    foreach (var city in cities)
                    {
                        BackgroundJob.Enqueue<ScheduleService>(s => s.GetCityWebServiceData(city.Domain, 0));
                    }
                }
            });
        }

        [Queue("statistics")]
        public async Task GetCityWebServiceData(string cityDomain, int latestStatisticsId)
        {
            string serviceKey = GenerateServiceKey();
            string method = "GetServerDataWithSql";
            HouseStatistics houseStatistics = await GetHouseStatistics(cityDomain, method, latestStatisticsId, serviceKey);
            DemandStatistics demandStatistics = await GetDemandStatistics(cityDomain, method, latestStatisticsId, serviceKey);
            TrackStatistics trackStatistics = await GetTrackStatistics(cityDomain, method, latestStatisticsId, serviceKey);
            VisitSurveyStatistics visitSurveyStatistics = await GetVisitSurveyStatistics(cityDomain, method,
                latestStatisticsId, serviceKey);

            await m_houseRepository.AddAsync(houseStatistics);
            await m_demandRepository.AddAsync(demandStatistics);
            await m_trackRepository.AddAsync(trackStatistics);
            await m_visitSurveyRepository.AddAsync(visitSurveyStatistics);

            await m_newestHouseStatistics.AddOrUpdateAsync(houseStatistics);
            await m_newestDemandStatistics.AddOrUpdateAsync(demandStatistics);
            await m_newestTrackStatistics.AddOrUpdateAsync(trackStatistics);
            await m_newestVisitSurveyStatistics.AddOrUpdateAsync(visitSurveyStatistics);
        }

        public async Task<HouseStatistics> GetHouseStatistics(string cityDomain, string method, int latestStatisticsId,
            string serviceKey)
        {
            HouseStatistics lastHouse = await m_houseRepository.GetLatest(cityDomain);
            if (lastHouse == null)
            {
                lastHouse = new HouseStatistics();
            }
            string sql = $@"SELECT COUNT(*) AS StatiscisCount,MAX([HouseDealSecondID]) AS LastHouseId
                        FROM [dbo].[HouseDealSecond] WHERE [HouseDealSecondID] > {lastHouse.LastSecondId}
                        UNION ALL
                        SELECT COUNT(*) AS StatiscisCount,0 AS LastHouseId
                        FROM [dbo].[HouseDealSecond] WHERE [HouseDealSecondID] > {lastHouse.LastSecondId} AND DeleteStatus = 0
                        UNION ALL
                        SELECT COUNT(*) AS StatiscisCount,MAX([HouseDealRentID]) AS LastHouseId
                        FROM [dbo].[HouseDealRent] WHERE [HouseDealRentID]> {lastHouse.LastRentId}
                        UNION ALL
                        SELECT COUNT(*) AS StatiscisCount,0 AS LastHouseId
                        FROM [dbo].[HouseDealRent] WHERE [HouseDealRentID] > {lastHouse.LastRentId} AND DeleteStatus = 0";
            string url = $"http://{cityDomain}.fooww.com/service/SyncService.asmx";
            Hashtable ht = new Hashtable
            {
                { "sql", sql },
                { "serviceKey", serviceKey }
            };
            var xmlResult = WebServiceHelper.QuerySoapWebService(url, "GetServerDataWithSql", ht);
            var dataSet = ServiceUtil.GetDataSetFromUnifiedServiceResult(xmlResult);
            HouseStatistics houseStatistics = new HouseStatistics()
            {
                HouseTotalCount = lastHouse.HouseTotalCount + Convert.ToInt32(dataSet.Tables[0].Rows[0][0])
                                    + Convert.ToInt32(dataSet.Tables[0].Rows[2][0]),
                HouseAvailableCount = lastHouse.HouseAvailableCount + Convert.ToInt32(dataSet.Tables[0].Rows[1][0])
                                        + Convert.ToInt32(dataSet.Tables[0].Rows[3][0]),
                HouseIncreasedCount = Convert.ToInt32(dataSet.Tables[0].Rows[0][0])
                                        + Convert.ToInt32(dataSet.Tables[0].Rows[2][0]),
                SecondHouseTotalCount = lastHouse.SecondHouseTotalCount + Convert.ToInt32(dataSet.Tables[0].Rows[0][0]),
                SecondHouseIncreasedCount = Convert.ToInt32(dataSet.Tables[0].Rows[0][0]),
                RentHouseTotalCount = lastHouse.RentHouseTotalCount + Convert.ToInt32(dataSet.Tables[0].Rows[2][0]),
                RentHouseIncreasedCount = Convert.ToInt32(dataSet.Tables[0].Rows[2][0]),
                CityCode = cityDomain,
                StatisticsTime = DateTime.Now,
                LatestStatisticsId = latestStatisticsId,
                LastSecondId = Convert.ToInt32(dataSet.Tables[0].Rows[0][0]) == 0 ?
                    lastHouse.LastSecondId : Convert.ToInt32(dataSet.Tables[0].Rows[0][1]),
                LastRentId = Convert.ToInt32(dataSet.Tables[0].Rows[2][0]) == 0 ?
                    lastHouse.LastRentId : Convert.ToInt32(dataSet.Tables[0].Rows[2][1])
            };
            return houseStatistics;
        }

        public async Task<DemandStatistics> GetDemandStatistics(string cityDomain, string method, int latestStatisticsId,
            string serviceKey)
        {
            DemandStatistics lastDemand = await m_demandRepository.GetLatest(cityDomain);
            if (lastDemand == null)
            {
                lastDemand = new DemandStatistics();
            }
            string sql = $@"SELECT COUNT(*) AS StatiscisCount,MAX([DemandID]) AS LastDemandId
                            FROM [dbo].[HouseDemandSecond] WHERE [DemandID] > {lastDemand.LastSecondId}
                            UNION ALL
                            SELECT COUNT(*) AS StatiscisCount,MAX([DemandID]) AS LastDemandId
                            FROM [dbo].[HouseDemandRent] WHERE [DemandID]> {lastDemand.LastRentId}";
            string url = $"http://{cityDomain}.fooww.com/service/SyncService.asmx";
            Hashtable ht = new Hashtable
            {
                { "sql", sql },
                { "serviceKey", serviceKey }
            };
            var xmlResult = WebServiceHelper.QuerySoapWebService(url, "GetServerDataWithSql", ht);
            var dataSet = ServiceUtil.GetDataSetFromUnifiedServiceResult(xmlResult);
            DemandStatistics demandStatistics = new DemandStatistics()
            {
                DemandTotalCount = lastDemand.DemandTotalCount + Convert.ToInt32(dataSet.Tables[0].Rows[0][0])
                + Convert.ToInt32(dataSet.Tables[0].Rows[1][0]),
                DemandIncreasedCount = Convert.ToInt32(dataSet.Tables[0].Rows[0][0])
                + Convert.ToInt32(dataSet.Tables[0].Rows[1][0]),
                SecondDemandTotalCount = lastDemand.SecondDemandTotalCount + Convert.ToInt32(dataSet.Tables[0].Rows[0][0]),
                SecondDemandIncreasedCount = Convert.ToInt32(dataSet.Tables[0].Rows[0][0]),
                RentDemandTotalCount = lastDemand.RentDemandTotalCount + Convert.ToInt32(dataSet.Tables[0].Rows[1][0]),
                RentDemandIncreasedCount = Convert.ToInt32(dataSet.Tables[0].Rows[1][0]),
                CityCode = cityDomain,
                StatisticsTime = DateTime.Now,
                LatestStatisticsId = latestStatisticsId,
                LastSecondId = Convert.ToInt32(dataSet.Tables[0].Rows[0][0]) == 0 ?
                    lastDemand.LastSecondId : Convert.ToInt32(dataSet.Tables[0].Rows[0][1]),
                LastRentId = Convert.ToInt32(dataSet.Tables[0].Rows[1][0]) == 0 ?
                    lastDemand.LastRentId : Convert.ToInt32(dataSet.Tables[0].Rows[1][1])
            };
            return demandStatistics;
        }

        public async Task<TrackStatistics> GetTrackStatistics(string cityDomain, string method, int latestStatisticsId,
            string serviceKey)
        {
            TrackStatistics lastTrack = await m_trackRepository.GetLatest(cityDomain);
            if (lastTrack == null)
            {
                lastTrack = new TrackStatistics()
                {
                    LastTrackOperateTime = new DateTime(1900, 1, 1, 0, 0, 0, 0).ToFormatString()
                };
            }
            else
            {
                lastTrack.LastTrackOperateTime = DateTime.Parse(lastTrack.LastTrackOperateTime).ToFormatString();
            }

            string trackTotalSql = $@"DECLARE @currentTime DATETIME = GETDATE()
                            SELECT COUNT(*) AS StatiscisCount,@currentTime AS TimeOnServer FROM [dbo].[BusinessTracking]
                            WHERE [OperateTime] > '{lastTrack.LastTrackOperateTime}' AND [OperateTime] <= @currentTime";
            DataSet TrackTotalDataSet = GetResponseFromWebService(cityDomain, trackTotalSql, serviceKey);
            string templastTrackOperateTime = Convert.ToDateTime(TrackTotalDataSet.Tables[0].Rows[0][1]).ToFormatString();

            string trackAvailableTotalSql = $@"SELECT COUNT(*) AS StatiscisCount FROM [dbo].[BusinessTracking]
                                               WHERE [OperateTime] > '{lastTrack.LastTrackOperateTime}'
                                               AND [OperateTime] <= '{templastTrackOperateTime}' AND DeleteStatus = 0";
            string houseTrackTotalSql = $@"SELECT COUNT(*) AS StatiscisCount FROM [dbo].[BusinessTracking]
                                           WHERE [OperateTime] > '{lastTrack.LastTrackOperateTime}'
                                           AND [OperateTime] <= '{templastTrackOperateTime}' AND BusinessType = 0";
            string demandTrackTotalSql = $@"SELECT COUNT(*) AS StatiscisCount FROM [dbo].[BusinessTracking]
                                            WHERE [OperateTime] > '{lastTrack.LastTrackOperateTime}'
                                            AND [OperateTime] <= '{templastTrackOperateTime}' AND BusinessType = 1";

            DataSet TrackAvailableDataSet = GetResponseFromWebService(cityDomain, trackAvailableTotalSql, serviceKey);
            DataSet HouseTracklDataSet = GetResponseFromWebService(cityDomain, houseTrackTotalSql, serviceKey);
            DataSet DemandTrackDataSet = GetResponseFromWebService(cityDomain, demandTrackTotalSql, serviceKey);
            TrackStatistics trackStatistics = new TrackStatistics()
            {
                TrackTotalCount = lastTrack.TrackTotalCount + Convert.ToInt32(TrackTotalDataSet.Tables[0].Rows[0][0]),
                TrackAvailableCount = lastTrack.TrackAvailableCount + Convert.ToInt32(TrackAvailableDataSet.Tables[0].Rows[0][0]),
                TrackIncreasedCount = Convert.ToInt32(TrackTotalDataSet.Tables[0].Rows[0][0]),
                HouseTrackTotalCount = lastTrack.HouseTrackTotalCount + Convert.ToInt32(HouseTracklDataSet.Tables[0].Rows[0][0]),
                HouseTrackIncreasedCount = Convert.ToInt32(HouseTracklDataSet.Tables[0].Rows[0][0]),
                DemandTrackTotalCount = lastTrack.DemandTrackTotalCount + Convert.ToInt32(DemandTrackDataSet.Tables[0].Rows[0][0]),
                DemandTrackIncreasedCount = Convert.ToInt32(DemandTrackDataSet.Tables[0].Rows[0][0]),
                CityCode = cityDomain,
                StatisticsTime = DateTime.Now,
                LatestStatisticsId = latestStatisticsId,
                LastTrackOperateTime = templastTrackOperateTime
            };
            return trackStatistics;
        }

        public DataSet GetResponseFromWebService(string cityDomain, string sql, string serviceKey)
        {
            string url = $"http://{cityDomain}.fooww.com/service/SyncService.asmx";
            Hashtable ht = new Hashtable
            {
                { "sql", sql },
                { "serviceKey", serviceKey }
            };
            var xmlResult = WebServiceHelper.QuerySoapWebService(url, "GetServerDataWithSql", ht);
            var dataSet = ServiceUtil.GetDataSetFromUnifiedServiceResult(xmlResult);
            return dataSet;
        }

        public async Task<VisitSurveyStatistics> GetVisitSurveyStatistics(string cityDomain, string method,
            int latestStatisticsId, string serviceKey)
        {
            VisitSurveyStatistics lastVisitSurvey = await m_visitSurveyRepository.GetLatest(cityDomain);
            if (lastVisitSurvey == null)
            {
                lastVisitSurvey = new VisitSurveyStatistics()
                {
                    LastVisitExecutionTime = new DateTime(1900, 1, 1, 0, 0, 0, 0).ToFormatString(),
                    LastSurveyCreateTime = new DateTime(1900, 1, 1, 0, 0, 0, 0).ToFormatString()
                };
            }
            else
            {
                lastVisitSurvey.LastVisitExecutionTime = DateTime.Parse(lastVisitSurvey.LastVisitExecutionTime).ToFormatString();
                lastVisitSurvey.LastSurveyCreateTime = DateTime.Parse(lastVisitSurvey.LastSurveyCreateTime).ToFormatString();
            }
            string sql = $@"DECLARE @currentTime DATETIME = GETDATE()
        SELECT COUNT(*) AS StatiscisCount,@currentTime AS TimeOnServer FROM [dbo].[HouseVisitRecords]
        WHERE [ExecutionTime] > '{lastVisitSurvey.LastVisitExecutionTime}' AND [ExecutionTime] < @currentTime
        UNION ALL
        SELECT COUNT(*) AS StatiscisCount,@currentTime AS TimeOnServer FROM [dbo].[HouseVisitRecords]
        WHERE DeleteStatus=0 AND [ExecutionTime] > '{lastVisitSurvey.LastVisitExecutionTime}' AND [ExecutionTime] < @currentTime
        UNION ALL
        SELECT COUNT(*) AS StatiscisCount,@currentTime AS TimeOnServer FROM [dbo].[HouseSurveyRecords]
        WHERE [CreateTime] > '{lastVisitSurvey.LastSurveyCreateTime}' AND [CreateTime] < @currentTime
        UNION ALL
        SELECT COUNT(*) AS StatiscisCount,@currentTime AS TimeOnServer FROM [dbo].[HouseSurveyRecords]
        WHERE DeleteStatus=0 AND [CreateTime] > '{lastVisitSurvey.LastSurveyCreateTime}' AND [CreateTime] < @currentTime
";
            string url = $"http://{cityDomain}.fooww.com/service/SyncService.asmx";
            Hashtable ht = new Hashtable
            {
                { "sql", sql },
                { "serviceKey", serviceKey }
            };
            var xmlResult = WebServiceHelper.QuerySoapWebService(url, "GetServerDataWithSql", ht);
            var dataSet = ServiceUtil.GetDataSetFromUnifiedServiceResult(xmlResult);
            VisitSurveyStatistics visitSurveyStatistics = new VisitSurveyStatistics()
            {
                VisitTotalCount = lastVisitSurvey.VisitTotalCount + Convert.ToInt32(dataSet.Tables[0].Rows[0][0]),
                VisitAvailableCount = lastVisitSurvey.VisitAvailableCount + Convert.ToInt32(dataSet.Tables[0].Rows[1][0]),
                VisitIncreasedCount = Convert.ToInt32(dataSet.Tables[0].Rows[0][0]),
                SurveyTotalCount = lastVisitSurvey.SurveyTotalCount + Convert.ToInt32(dataSet.Tables[0].Rows[2][0]),
                SurveyAvailableCount = lastVisitSurvey.SurveyAvailableCount + Convert.ToInt32(dataSet.Tables[0].Rows[3][0]),
                SurveyIncreasedCount = Convert.ToInt32(dataSet.Tables[0].Rows[2][0]),
                CityCode = cityDomain,
                StatisticsTime = DateTime.Now,
                LatestStatisticsId = latestStatisticsId,
                LastVisitExecutionTime = Convert.ToDateTime(dataSet.Tables[0].Rows[0][1]).ToFormatString(),
                LastSurveyCreateTime = Convert.ToDateTime(dataSet.Tables[0].Rows[0][1]).ToFormatString()
            };
            return visitSurveyStatistics;
        }

        public string GenerateServiceKey()
        {
            long ticks = DateTime.Now.Ticks;
            //Guid pkUser = new Guid("fd284fb4-a952-418f-8880-e900c585cedf");
            Guid pkUser = new Guid("991E4EE5-F315-43F6-87BD-FE0CB921CE5F");
            return ServiceUtil.GetServiceKey(pkUser, 0, ticks);
        }

        public async Task CalculateLatestStatistics()
        {
            LatestStatistics latestStatistics = new LatestStatistics();
            var houseCalculate = await m_newestHouseStatistics.CalculateSumOfLatestAllCityLatest();
            var demandCalculate = await m_newestDemandStatistics.CalculateSumOfLatestAllCityLatest();
            var trackCalculate = await m_newestTrackStatistics.CalculateSumOfLatestAllCityLatest();
            var visitSurveyCalculate = await m_newestVisitSurveyStatistics.CalculateSumOfLatestAllCityLatest();
            var latest = await m_latestRepository.GetLatestAsync();
            if (latest == null)
            {
                latest = new LatestStatistics()
                {
                    HouseCount = Convert.ToInt64(houseCalculate.HouseCount),
                    HouseDemandCount = Convert.ToInt64(demandCalculate.DemandCount),
                    TrackCount = Convert.ToInt64(trackCalculate.TrackCount),
                    VisitCount = Convert.ToInt64(visitSurveyCalculate.VisitCount),
                    SurveyCount = Convert.ToInt64(visitSurveyCalculate.SurveyCount)
                };
            }
            latestStatistics.HouseCount = Convert.ToInt64(houseCalculate.HouseCount);
            latestStatistics.HouseIncreasedCount = (int)(latestStatistics.HouseCount - latest.HouseCount);
            latestStatistics.HouseDemandCount = Convert.ToInt64(demandCalculate.DemandCount);
            latestStatistics.HouseIncreasedDemandCount = (int)(latestStatistics.HouseDemandCount - latest.HouseDemandCount);
            latestStatistics.TrackCount = Convert.ToInt64(trackCalculate.TrackCount);
            latestStatistics.TrackIncreasedCount = (int)(latestStatistics.TrackCount - latest.TrackCount);
            latestStatistics.VisitCount = Convert.ToInt64(visitSurveyCalculate.VisitCount);
            latestStatistics.VisitIncreasedCount = (int)(latestStatistics.VisitCount - latest.VisitCount);
            latestStatistics.SurveyCount = Convert.ToInt64(visitSurveyCalculate.SurveyCount);
            latestStatistics.SurveyIncreasedCount = (int)(latestStatistics.SurveyCount - latest.SurveyCount);
            latestStatistics.StatisticsTime = DateTime.Now;
            await m_latestRepository.AddAsync(latestStatistics);
        }

        #endregion 数据统计

        #region 站点监测

        public void StartServiceDetection()
        {
            var syncCities = m_configuration.GetSection("foowwcities").Get<List<City>>()
                .Where(c => c.Is_Deleted == "0" && c.Sync_Enable != "0");

            var vipCities = m_configuration.GetSection("foowwcities").Get<List<City>>()
                .Where(c => c.Is_Deleted == "0" && c.Vip_Enable != "0");
            Task.Run(() =>
            {
                foreach (var city in syncCities)
                {
                    RecurringJob.AddOrUpdate<ScheduleService>($"SyncService-{city.Domain}",
                        s => s.ExecHeartBeatForSyncService(city.Domain), m_configuration["RecurringJob:SyncServiceHeartBeat"]);
                }
                foreach (var city in vipCities)
                {
                    RecurringJob.AddOrUpdate<ScheduleService>($"VIPHouseInfoService-{city.Domain}",
                        s => s.ExecHeartBeatForVIPHouseInfoService(city.Domain),
                        m_configuration["RecurringJob:VIPServiceHeartBeat"]);
                }
                RecurringJob.AddOrUpdate<ScheduleService>("MessageService",
                        s => s.ExecHeartBeatForMessageService(),
                        m_configuration["RecurringJob:VIPServiceHeartBeat"]);
                RecurringJob.AddOrUpdate<ScheduleService>("SettingService",
                        s => s.ExecHeartBeatForSettingService(),
                        m_configuration["RecurringJob:VIPServiceHeartBeat"]);
            });
        }

        [Queue("heartbeat_vip")]
        [DisplayName("HeartBeatForVIPHouseInfoService-{0}")]
        public async Task ExecHeartBeatForVIPHouseInfoService(string cityDomain)
        {
            string url = $"http://{cityDomain}.fooww.biz/service/VIPHouseInfoService.asmx";
            string serviceKey = GenerateServiceKey();
            Hashtable ht = new Hashtable
            {
                { "PKUser", "991E4EE5-F315-43F6-87BD-FE0CB921CE5F" },
                { "serviceKey", serviceKey }
            };
            bool success = true;
            DateTime startTime = DateTime.Now;
            DateTime endTime;
            try
            {
                var xmlResult = WebServiceHelper.QuerySoapWebService(url, "GetUserHouseIndexKeywords", ht);
                endTime = DateTime.Now;
            }
            catch
            {
                endTime = DateTime.Now;
                success = false;
            }
            TimeSpan timeSpan = endTime - startTime;
            double duration = timeSpan.TotalSeconds;
            await SaveHeartBeatResult(cityDomain, success, duration, startTime, 2);
        }

        [Queue("heartbeat_sync")]
        [DisplayName("HeartBeatForSyncService-{0}")]
        public async Task ExecHeartBeatForSyncService(string cityDomain)
        {
            string url = $"http://{cityDomain}.fooww.com/service/SyncService.asmx";
            string serviceKey = GenerateServiceKey();
            Hashtable ht = new Hashtable
            {
                { "PKUser", "991E4EE5-F315-43F6-87BD-FE0CB921CE5F" },
                { "serviceKey", serviceKey }
            };
            bool success = true;
            DateTime startTime = DateTime.Now;
            DateTime endTime;
            try
            {
                var xmlResult = WebServiceHelper.QuerySoapWebService(url, "GetFoowwUserPermissions", ht);
                endTime = DateTime.Now;
            }
            catch
            {
                endTime = DateTime.Now;
                success = false;
            }
            TimeSpan timeSpan = endTime - startTime;
            double duration = timeSpan.TotalSeconds;
            await SaveHeartBeatResult(cityDomain, success, duration, startTime, 1);
        }

        public async Task SaveHeartBeatResult(string cityDomain, bool success, double duration,
            DateTime accessTime, int serviceType)
        {
            IPAddress ip = GetIPAddress(cityDomain, serviceType);
            var serviceDetection = GenerateServiceDetection(cityDomain, success, duration, accessTime, serviceType, ip);
            var serviceException = new ServiceException()
            {
                CityCode = cityDomain,
                ServiceType = serviceType,
                ResponseDuration = Math.Round(duration, 4),
                AccessibleTime = accessTime,
                IsAccessible = (duration >= 15 || !success) ? 0 : 1,
                Ip = ip.ToString()
            };
            var detection = await m_serviceDetection.GetByCityCodeServiceType(cityDomain, serviceType);
            if (detection == null)
            {
                await m_serviceDetection.AddAsync(serviceDetection);
            }
            else
            {
                serviceDetection.TotalAccessibleCount += detection.TotalAccessibleCount;
                serviceDetection.UnableAccessibleCount += detection.UnableAccessibleCount;
                serviceDetection.Bigthan2sAccessibleCount += detection.Bigthan2sAccessibleCount;
                serviceDetection.Bigthan5sAccessibleCount += detection.Bigthan5sAccessibleCount;
                serviceDetection.AccessibleRate = Math.Round(1.00 -
                    (serviceDetection.UnableAccessibleCount / (double)serviceDetection.TotalAccessibleCount), 4);
                serviceDetection.LastUnableAccessibleTime =
                    serviceDetection.LastUnableAccessibleTime ?? detection.LastUnableAccessibleTime;
                serviceDetection.Id = detection.Id;
                await m_serviceDetection.UpdateAsync(serviceDetection);
            }
            if (serviceException.IsAccessible == 0 || serviceException.ResponseDuration > 2)
            {
                await m_serviceException.AddAsync(serviceException);
            }
        }

        private ServiceDetection GenerateServiceDetection(string cityDomain, bool success, double duration
            , DateTime accessTime, int serviceType, IPAddress ip)
        {
            var serviceDetection = new ServiceDetection()
            {
                CityCode = cityDomain,
                LastResponseDuration = Math.Round(duration, 2),
                LastAccessibleTime = accessTime,
                Ip = ip.ToString(),
                ServiceType = serviceType,
                TotalAccessibleCount = 1
            };
            if (duration >= 15 || !success)
            {
                serviceDetection.UnableAccessibleCount = 1;
                serviceDetection.Bigthan2sAccessibleCount = 0;
                serviceDetection.Bigthan5sAccessibleCount = 0;
                serviceDetection.AccessibleRate = 0.00;
                serviceDetection.LastAccessibleState = "red";
                serviceDetection.LastUnableAccessibleTime = accessTime;
            }
            else if (duration > 5)
            {
                serviceDetection.UnableAccessibleCount = 0;
                serviceDetection.Bigthan2sAccessibleCount = 0;
                serviceDetection.Bigthan5sAccessibleCount = 1;
                serviceDetection.AccessibleRate = 1.00;
                serviceDetection.LastAccessibleState = "red";
                serviceDetection.LastUnableAccessibleTime = null;
            }
            else if (duration > 2)
            {
                serviceDetection.UnableAccessibleCount = 0;
                serviceDetection.Bigthan2sAccessibleCount = 1;
                serviceDetection.Bigthan5sAccessibleCount = 0;
                serviceDetection.AccessibleRate = 1.00;
                serviceDetection.LastAccessibleState = "yellow";
                serviceDetection.LastUnableAccessibleTime = null;
            }
            else
            {
                serviceDetection.UnableAccessibleCount = 0;
                serviceDetection.Bigthan2sAccessibleCount = 0;
                serviceDetection.Bigthan5sAccessibleCount = 0;
                serviceDetection.AccessibleRate = 1.00;
                serviceDetection.LastAccessibleState = "green";
                serviceDetection.LastUnableAccessibleTime = null;
            }
            return serviceDetection;
        }

        private IPAddress GetIPAddress(string cityDomain, int serviceType)
        {
            string dns = "";
            if (serviceType == 2)
            {
                dns = $"{cityDomain}.fooww.biz";
            }
            else
            {
                dns = $"{cityDomain}.fooww.com";
            }
            IPHostEntry host = Dns.GetHostEntry(dns);
            return host.AddressList[0];
        }

        [Queue("heartbeat_vip")]
        [DisplayName("HeartBeatForMessageService")]
        public async Task ExecHeartBeatForMessageService()
        {
            string url = $"http://sta.fooww.com/service/MessageService.asmx";
            Hashtable ht = new Hashtable
            {
                { "username", "彭训贵" }
            };
            bool success = true;
            DateTime startTime = DateTime.Now;
            DateTime endTime;
            try
            {
                var xmlResult = WebServiceHelper.QuerySoapWebService(url, "GetFoowwUserIDByName", ht);
                endTime = DateTime.Now;
            }
            catch
            {
                endTime = DateTime.Now;
                success = false;
            }
            TimeSpan timeSpan = endTime - startTime;
            double duration = timeSpan.TotalSeconds;
            await SaveHeartBeatResult("sta", success, duration, startTime, 3);
        }
        [Queue("heartbeat_vip")]
        [DisplayName("HeartBeatForSettingService")]
        public async Task ExecHeartBeatForSettingService()
        {
            string url = $"http://www.fooww.com/service/SettingService.asmx";
            Hashtable ht = new Hashtable();
            bool success = true;
            DateTime startTime = DateTime.Now;
            DateTime endTime;
            try
            {
                var xmlResult = WebServiceHelper.QuerySoapWebService(url, "GetMessageServer", ht);
                endTime = DateTime.Now;
            }
            catch
            {
                endTime = DateTime.Now;
                success = false;
            }
            TimeSpan timeSpan = endTime - startTime;
            double duration = timeSpan.TotalSeconds;
            await SaveHeartBeatResult("www", success, duration, startTime, 4);
        }

        #endregion 站点监测

        #region 采集数据

        public async Task StartAcquisitionSY()
        {
            await GetAcquisitionData("sy");
        }

        public void StartAcquisition()
        {
            var vipCities = m_configuration.GetSection("foowwcities").Get<List<City>>()
                .Where(c => c.Is_Deleted == "0" && c.Vip_Enable != "0");
            Task.Run(() =>
            {
                foreach (var city in vipCities)
                {
                    RecurringJob.AddOrUpdate<ScheduleService>($"AcquisitionService-{city.Domain}",
                        s => s.GetAcquisitionData(city.Domain), m_configuration["RecurringJob:Acquisition"]);
                }
                RecurringJob.AddOrUpdate<ScheduleService>(s => s.CalculateTotalAcquisition(),
                    m_configuration["RecurringJob:AcquisitionTotal"]);

                if (m_configuration["RecurringJob:ExecuteImmediate"] == "1")
                {
                    foreach (var city in vipCities)
                    {
                        BackgroundJob.Enqueue<ScheduleService>(s => s.GetAcquisitionData(city.Domain));
                    }
                }
            });
        }

        [Queue("acquisition_vip")]
        [DisplayName("AcquisitionService-{0}")]
        public async Task GetAcquisitionData(string cityDomain)
        {
            string serviceKey = GenerateServiceKey();
            string method = "GetServerDataWithSql";
            AcquisitionHouse acquisitionHouse = await GetAcquisitionHouseStatistics(cityDomain, method, serviceKey);

            await m_acquisitionHouse.AddAsync(acquisitionHouse);
            await m_newestAcquisitionHouse.AddOrUpdateAsync(acquisitionHouse);
        }

        public async Task<AcquisitionHouse> GetAcquisitionHouseStatistics(string cityDomain, string method, string serviceKey)
        {
            bool isEmptyTable = false;
            AcquisitionHouse lastHouse = await m_acquisitionHouse.GetLatest(cityDomain);
            if (lastHouse == null)
            {
                isEmptyTable = true;
                lastHouse = new AcquisitionHouse();
            }
            string sql = $@"SELECT COUNT(*) AS StatiscisCount,MAX([HouseDealSecondID]) AS LastHouseId
                            FROM [dbo].[HouseDealSecond]
                            UNION ALL
                            SELECT COUNT(*) AS StatiscisCount,0 AS LastHouseId
                            FROM [dbo].[HouseDealSecond] WHERE [HouseDealSecondID] > {lastHouse.LastSecondId}
                            UNION ALL
                            SELECT COUNT(*) AS StatiscisCount,MAX([HouseDealRentID]) AS LastHouseId
                            FROM [dbo].[HouseDealRent]
                            UNION ALL
                            SELECT COUNT(*) AS StatiscisCount,0 AS LastHouseId
                            FROM [dbo].[HouseDealRent] WHERE [HouseDealRentID]> {lastHouse.LastRentId}";
            string url = $"http://{cityDomain}.fooww.biz/service/VIPHouseInfoService.asmx";
            Hashtable ht = new Hashtable
            {
                { "sql", sql },
                { "serviceKey", serviceKey }
            };
            var xmlResult = WebServiceHelper.QuerySoapWebService(url, "GetServerDataWithSql", ht);
            var dataSet = ServiceUtil.GetDataSetFromUnifiedServiceResult(xmlResult);
            var totalCount = Convert.ToInt64(dataSet.Tables[0].Rows[0][0]) + Convert.ToInt64(dataSet.Tables[0].Rows[2][0]);
            var totalIncreased = Convert.ToInt32(dataSet.Tables[0].Rows[1][0]) + Convert.ToInt32(dataSet.Tables[0].Rows[3][0]);
            AcquisitionHouse acquisitionHouse = new AcquisitionHouse()
            {
                TotalCount = totalCount,
                IncreasedCount = isEmptyTable ? 0 : totalIncreased,
                SecondTotalCount = Convert.ToInt64(dataSet.Tables[0].Rows[0][0]),
                SecondIncreasedCount = isEmptyTable ? 0 : Convert.ToInt32(dataSet.Tables[0].Rows[1][0]),
                RentTotalCount = Convert.ToInt64(dataSet.Tables[0].Rows[2][0]),
                RentIncreasedCount = isEmptyTable ? 0 : Convert.ToInt32(dataSet.Tables[0].Rows[3][0]),
                CityCode = cityDomain,
                StatisticsTime = DateTime.Now,
                LastSecondId = Convert.ToInt64(dataSet.Tables[0].Rows[0][0]) == 0 ? lastHouse.LastSecondId
                    : Convert.ToInt64(dataSet.Tables[0].Rows[0][1]),
                LastRentId = Convert.ToInt64(dataSet.Tables[0].Rows[2][0]) == 0 ? lastHouse.LastRentId
                    : Convert.ToInt64(dataSet.Tables[0].Rows[2][1])
            };
            return acquisitionHouse;
        }

        public async Task CalculateTotalAcquisition()
        {
            AcquisitionTotal acquisitionTotal = new AcquisitionTotal();
            var houseCalculate = await m_newestAcquisitionHouse.CalculateSumOfLatestAllCityLatest();
            var latest = await m_acquisitionTotal.GetLatestAsync();
            if (latest == null)
            {
                latest = new AcquisitionTotal()
                {
                    TotalHouseCount = Convert.ToInt64(houseCalculate.TotalCount),
                    SecondHouseCount = Convert.ToInt64(houseCalculate.SecondTotalCount),
                    RentHouseCount = Convert.ToInt64(houseCalculate.RentTotalCount)
                };
            }
            acquisitionTotal.TotalHouseCount = Convert.ToInt64(houseCalculate.TotalCount);
            acquisitionTotal.TotalHouseIncreasedCount = Convert.ToInt32(houseCalculate.TotalIncreased);
            acquisitionTotal.SecondHouseCount = Convert.ToInt64(houseCalculate.SecondTotalCount);
            acquisitionTotal.SecondHouseIncreasedCount = Convert.ToInt32(houseCalculate.SecondIncreased);
            acquisitionTotal.RentHouseCount = Convert.ToInt64(houseCalculate.RentTotalCount);
            acquisitionTotal.RentHouseIncreasedCount = Convert.ToInt32(houseCalculate.RentIncreased);
            acquisitionTotal.StatisticsTime = DateTime.Now;
            await m_acquisitionTotal.AddAsync(acquisitionTotal);
        }

        #endregion 采集数据
    }
}
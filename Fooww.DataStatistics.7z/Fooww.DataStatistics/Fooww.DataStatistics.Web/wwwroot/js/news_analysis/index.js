﻿$(function () {
    $('#copyRight').text(new Date().getFullYear());
    $('#mainContent').css("min-height", $(window).height() - $('#menuContent').outerHeight() - 10);
    $('#newsContainer').css("min-height", $('#mainContent').outerHeight() - $('#flagsContent').outerHeight() - $('#searchIconDiv').outerHeight());
    $('#newsContent').css("min-height", $('#newsContainer').outerHeight() - $('#trackPaging').outerHeight() - $('#bottomContent').outerHeight());

    $('#newsDetailContent').css("min-height", $(window).height() - $('#menuContent').outerHeight() - 10);
    $('#newsDetailCenterContent').css("min-height", $('#newsDetailContent').outerHeight() - $('#bottomContent').outerHeight());

    $('#startTime').val(startTime);
    //加一天
    var timestamp = Date.parse(new Date());
    timestamp = timestamp / 1000;
    timestamp += 86400;//加一天
    endTime = toDateString(new Date(timestamp * 1000), 'yyyy-MM-dd');
    $('#endTime').val(endTime);
    needUpdateWordCloud = true;
    $('.layui-nav .layui-nav-item').first().click();
});

var resizeTimer = null;
var myLabelChart;
myLabelChart = echarts.init(document.getElementById('flagsContent'));

$(window).bind('resize', function () {
    myLabelChart.resize();
});

var startTime = "";
var endTime = "";
var selectedCompanyId;

window.Router = new Router();
Router.route('/', function () {
    $('#newsDetailContent').css("display", "none");
    $('#mainContent').css("display", "block");
});

Router.route('/newsdetail', function () {
    $('#mainContent').css("display", "none");
    $('#newsDetailContent').css("display", "block");
    var newsDetailCenterContent = document.querySelector('#newsDetailCenterContent');
    newsDetailCenterContent.innerHTML = newDetailContent;
});

Router.init();

var digit = function (num, length) {
    var str = '';
    num = String(num);
    length = length || 2;
    for (var i = num.length; i < length; i++) {
        str += '0';
    }
    return num < Math.pow(10, length) ? str + (num | 0) : num;
};
var toDateString = function (time, format) {
    var that = this
        , date = new Date(time || new Date())
        , ymd = [
            that.digit(date.getFullYear(), 4)
            , that.digit(date.getMonth() + 1)
            , that.digit(date.getDate())
        ]
        , hms = [
            that.digit(date.getHours())
            , that.digit(date.getMinutes())
            , that.digit(date.getSeconds())
        ];

    format = format || 'yyyy-MM-dd HH:mm:ss';

    return format.replace(/yyyy/g, ymd[0])
        .replace(/MM/g, ymd[1])
        .replace(/dd/g, ymd[2])
        .replace(/HH/g, hms[0])
        .replace(/mm/g, hms[1])
        .replace(/ss/g, hms[2]);
};

function menuSelectedChanged(companyId) {
    selectedCompanyId = companyId;
    $('.layui-nav .layui-nav-item').removeClass("layui-this");
    $('.layui-nav #nav-item-' + companyId).addClass("layui-this");
    $('#searchTitle').val('');
    window.location.href = '#/';
    needUpdateWordCloud = true;
    getNews(companyId);
}

var needUpdateWordCloud = false;
layui.use('laydate', function () {
    var laydate = layui.laydate;
    laydate.render({
        elem: '#startTime', //指定元素
        type: 'date',
        done: function (value) {
            startTime = value;
            if (value !== '' && endTime !== '' && endTime < value) {
                $('#startTime').val('');
                startTime = '';
                alert("结束时间不能小于开始时间");
                return;
            }
            $('.layui-laydate').css("display", "none");
            $('#startTime').val(value);
            needUpdateWordCloud = true;
        }
    }), laydate.render({
        elem: '#endTime', //指定元素
        type: 'date',
        done: function (value) {
            endTime = value;
            if (value !== '' && startTime !== '' && startTime > value) {
                $('#endTime').val('');
                endTime = '';
                alert("结束时间不能小于开始时间");
                return;
            }
            $('.layui-laydate').css("display", "none");
            $('#endTime').val(value);
            needUpdateWordCloud = true;
        }
    });
});

jQuery.support.cors = true;
//var myLabelChart;
function getWordCloud(companyId) {
    if (!needUpdateWordCloud && $('#startTime').val() === startTime && $('#endTime').val() === endTime) {
        return;
    }
    startTime = $('#startTime').val();
    endTime = $('#endTime').val();
    needUpdateWordCloud = false;
    //myLabelChart = echarts.init(document.getElementById('flagsContent'));
    $.ajax({
        type: "GET",
        dataType: "json",
        crossDomain: true,
        url: "/NewsAnalysis/GetWordCloudData/?startTime=" + startTime + "&companyId=" + companyId
            + "&endTime=" + endTime,
        success: function (data) {
            if (data === null) return;
            wordCloudsData = data.data;
            var option = {
                backgroundColor: '#F7F7F7',
                tooltip: {
                    show: true
                },
                series: [{
                    name: '次数',
                    type: 'wordCloud',
                    sizeRange: [20, 66],
                    rotationRange: [-45, 90],
                    shape: 'diamond',
                    textPadding: 0,
                    autoSize: {
                        enable: true,
                        minSize: 30
                    },
                    textStyle: {
                        normal: {
                            color: function () {
                                return 'rgb(' + [
                                    Math.round(Math.random() * 160),
                                    Math.round(Math.random() * 160),
                                    Math.round(Math.random() * 160)
                                ].join(',') + ')';
                            }
                        },
                        emphasis: {
                            shadowBlur: 10,
                            shadowColor: '#333'
                        }
                    },
                    data: data.data
                }]
            };
            myLabelChart.on("click", eConsole);
            myLabelChart.setOption(option);
        }
    });
}

function eConsole(param) {
    $('#searchTitle').val(param.name);
    $('#searchBtn').click();
}

function getNews(companyId) {
    getWordCloud(companyId);
    myLabelChart.resize();

    layui.use(['laytpl', 'laypage'], function () {
        var laytpl = layui.laytpl;
        var laypage = layui.laypage;
        var titleFilter = $('#searchTitle').val();
        var startTime = $('#startTime').val();
        var endTime = $('#endTime').val();
        $.ajax({
            type: "GET",
            dataType: "json",
            url: "/NewsAnalysis/GetNewsCount",
            data: { companyId: companyId, titleFilter: titleFilter, startTime: startTime, endTime: endTime },
            success: function (data) {
                laypage.render({
                    elem: 'trackPaging'
                    , count: data
                    , limit: 10
                    , groups: 5
                    , layout: ['prev', 'page', 'next', 'count']
                    , prev: '<i class="layui-icon layui-icon-left"></i>'
                    , next: '<i class="layui-icon layui-icon-right"></i>'
                    , jump: function (obj) {
                        $.ajax({
                            type: "GET",
                            dataType: "json",
                            url: "NewsAnalysis/GetNews",
                            data: {
                                companyId: companyId, titleFilter: titleFilter, startTime: startTime, endTime: endTime,
                                page: obj.curr, limit: obj.limit
                            },
                            success: function (data) {
                                if (data === null) return;
                                var newsTitleMaster = document.getElementById('newsTitleMaster');
                                var getTpl = newsTitleMaster.innerHTML;
                                var newsContent = document.getElementById('newsContent');
                                laytpl(getTpl).render(data, function (html) {
                                    newsContent.innerHTML = html;
                                });
                            }
                        });
                    }
                });
            }
        });
    });
}

var newDetailContent = "";
function showNewsDetail(newsId) {
    console.log(newsId);
    $.ajax({
        type: "GET",
        dataType: "json",
        async: false,
        url: "/Home/GetNewsContent",
        data: {
            newsId: newsId
        },
        success: function (data) {
            if (data === null || data === "") {
                parent.alert("暂未采集到该新闻的详情内容");
                return;
            }
            newDetailContent = data;
            $('#news_title_' + newsId).attr("href", "#/newsdetail");
        }
    });
}
﻿layui.define('jquery', function (exports) {
    "use strict";
    const $ = layui.jquery;

    let yutons_sug = {};
	/**
	 * yutons_sug搜索框提示插件||输入框提示插件初始化
	 */
    yutons_sug.render = function (opt) {
        //初始化输入框提示容器
        var sug_box = $("<div id='sug_box'></div>");
        sug_box.css({
            "background-color": "#fff",
            "display": "none",
            "z-index": "1989",
            "position": "absolute",
            "width": "100%",
            "border": "solid #e6e6e6 0.5px"
        });
        $("#" + opt.id).after(sug_box);

        /* 输入框鼠标松开事件 */
        /* 输入框键盘抬起事件 */
        $("#" + opt.id).on('mouseup keyup', function () {
            $("#sug_box").empty();
            sessionStorage.setItem("inputId", opt.id)
            let kw = $.trim($(this).val());
            if (kw == "") {
                sug_box.hide();
                return false;
            }
            //sug下拉框异步加载数据并渲染下拉框
            $.ajax({
                type: "get",
                url: opt.url + kw,
                success: function (data) {
                    layui.each(data, (index, item) => {
                        let sug_item = $(`<div class="item" data-id="${item["id"]}" data-name="${item["name"]}">${item["name"]}</div>`);
                        $("#sug_box").append(sug_item).show();
                        sug_item.css({
                            "padding": "3px 10px",
                            "cursor": "pointer"
                        });
                        sug_item.mouseenter(function () {
                            $(".item").css("background", "");
                            $(this).css("background", "#e6e6e6");
                        });
                        sug_item.click(function () {
                            let value = $(this).text();
                            $("#" + opt.id).val(value);
                            $("#sug_box").empty().hide();
                            opt.select($(this).data('id'), $(this).data('name'));
                        });
                    });
                }
            });
        });
        //输入框提示容器移出事件：鼠标移出隐藏输入提示框
        $("#" + opt.id).parent().mouseleave(function () {
            $("#sug_box").empty().hide();
        });
        //搜索框提示插件||输入框提示插件--sug-下拉框上下键移动事件和回车事件
        $(document).keydown(function (e) {
            e = e || window.event;
            let keycode = e.which ? e.which : e.keyCode;
            if (keycode == 38) {
                //上键事件
                event.preventDefault();
                if ($.trim($("#sug_box").html()) == "") {
                    return;
                }
                movePrev(opt.id);
            } else if (keycode == 40) {
                //下键事件
                event.preventDefault();
                if ($.trim($("#sug_box").html()) == "") {
                    return;
                }
                $("#" + opt.id).blur();
                if ($(".item").hasClass("addbg")) {
                    moveNext();
                } else {
                    $(".item").removeClass('addbg').css("background", "").eq(0).addClass('addbg').css("background", "#e6e6e6");
                }
            } else if (keycode == 13) {
                //回车事件
                dojob();
            }
        });
        //上键事件
        let movePrev = function (id) {
            $("#" + id).blur();
            let index = $(".addbg").prevAll().length;
            if (index == 0) {
                $(".item").removeClass('addbg').css("background", "").eq($(".item").length - 1).addClass('addbg').css(
                    "background", "#e6e6e6");
            } else {
                $(".item").removeClass('addbg').css("background", "").eq(index - 1).addClass('addbg').css("background", "#e6e6e6");
            }
        }
        //下键事件
        let moveNext = function () {
            let index = $(".addbg").prevAll().length;

            if (index == $(".item").length - 1) {
                $(".item").removeClass('addbg').css("background", "").eq(0).addClass('addbg').css("background", "#e6e6e6");
            } else {
                $(".item").removeClass('addbg').css("background", "").eq(index + 1).addClass('addbg').css("background", "#e6e6e6");
            }
        }
        //回车事件
        let dojob = function () {
            let value = $(".addbg").text();
            let id = $(".addbg").data('id');
            let paramter = $(".addbg").data('paramter');

            $("#" + opt.id).blur();
            $("#" + opt.id).val(value);
            $("#sug_box").empty().hide();
            opt.select(id, paramter);
        }
    }

    //暴露方法
    exports("yutons_sug", yutons_sug);
});
﻿$('#copyRight').text(new Date().getFullYear());
var last;
var exceptionServiceType;
var exceptionStartDate;
var exceptionEndDate;
var exceptionSearchKeyword;
layui.use(['element', 'table', 'util', 'form', 'laydate'], function () {
    var element = layui.element;
    var table = layui.table;
    var util = layui.util;
    var form = layui.form;
    var laydate = layui.laydate;

    $('.card-count,.card-increment').each(function () {
        var count = $(this).text().split('').reverse().join('')
            .replace(/(\d{4})/g, '$1 ').replace(/\,$/, '').split('').reverse().join('');
        $(this).text(count);
    })
    var tableIns = table.render({
        elem: '#statisticsTable'
        , id: 'statisticsTable'
        , url: '/Home/GetHouseDataForTable'
        , initSort: {
            field: 'houseTotalCount'
            , type: 'desc'
        }
        , where: {
            field: 'houseTotalCount'
            , order: 'desc'
        }
        , autoSort: false
        , page: true
        , limit: 20
        , cols: [[
            { type: 'numbers', title: '编号' }
            , {
                field: 'city', title: '城市', templet: function (d) {
                    return '<a class="cityName" statistics-id="' + d.cityCode + '">' + d.city + '</a>';
                }
            }
            , { field: 'houseTotalCount', title: '房源总数', sort: true }
            , { field: 'houseAvailableCount', title: '有效总数', sort: true }
            , { field: 'houseIncreasedCount', title: '新增房源', sort: true }
            , { field: 'secondHouseTotalCount', title: '二手房源', sort: true }
            , { field: 'secondHouseIncreasedCount', title: '新增二手房', sort: true }
            , { field: 'rentHouseTotalCount', title: '租房总数', sort: true }
            , { field: 'rentHouseIncreasedCount', title: '新增租房', sort: true }
            , {
                field: 'statisticsTime', title: '统计时间', sort: true, width: 160, templet: function (d) {
                    return util.toDateString(d.statisticsTime, 'yyyy-MM-dd HH:mm:ss');
                }
            }
        ]]
        , done: function () {
            $('.cityName[statistics-id]').on('click', function () {
                $('#statistics_region').hide();
                $('#acquisition_region').hide();
                $('#detection_region').hide();
                var cityCode = $(this).attr('statistics-id');
                var cityName = $(this).text();
                $.ajax({
                    type: "GET",
                    dataType: "html",
                    url: "/Home/CityDetail",
                    data: { cityCode: cityCode, type: 'house' },
                    success: function (data) {
                        sessionStorage.setItem('cityName', cityName);
                        $('#city_detection_region').empty().append(data);
                        $('#city_detection_region').show();
                    }
                });
            });
        }
    });

    //监听排序事件
    table.on('sort(statisticsTable)', function (obj) {
        tableIns.reload({
            initSort: obj
            , where: {
                field: obj.field
                , order: obj.type
            }
        });
    });

    $('#house').click(function () {
        tableIns.reload({
            url: '/Home/GetHouseDataForTable'
            , page: {
                curr: 1
            }
            , initSort: {
                field: 'houseTotalCount'
                , type: 'desc'
            }
            , where: {
                field: 'houseTotalCount'
                , order: 'desc'
            }
            , cols: [[
                { type: 'numbers', title: '编号' }
                , {
                    field: 'city', title: '城市', templet: function (d) {
                        return '<a class="cityName" statistics-id="' + d.cityCode + '">' + d.city + '</a>';
                    }
                }
                , { field: 'houseTotalCount', title: '房源总数', sort: true }
                , { field: 'houseAvailableCount', title: '有效总数', sort: true }
                , { field: 'houseIncreasedCount', title: '新增房源', sort: true }
                , { field: 'secondHouseTotalCount', title: '二手房源', sort: true }
                , { field: 'secondHouseIncreasedCount', title: '新增二手房', sort: true }
                , { field: 'rentHouseTotalCount', title: '租房总数', sort: true }
                , { field: 'rentHouseIncreasedCount', title: '新增租房', sort: true }
                , {
                    field: 'statisticsTime', title: '统计时间', sort: true, width: 160, templet: function (d) {
                        return util.toDateString(d.statisticsTime, 'yyyy-MM-dd HH:mm:ss');
                    }
                }
            ]]
            , done: function () {
                $('.cityName[statistics-id]').on('click', function () {
                    $('#statistics_region').hide();
                    $('#acquisition_region').hide();
                    $('#detection_region').hide();
                    var cityCode = $(this).attr('statistics-id');
                    var cityName = $(this).text();
                    $.ajax({
                        type: "GET",
                        dataType: "html",
                        url: "/Home/CityDetail",
                        data: { cityCode: cityCode, type: 'house' },
                        success: function (data) {
                            sessionStorage.setItem('cityName', cityName);
                            $('#city_detection_region').empty().append(data);
                            $('#city_detection_region').show();
                        }
                    });
                });
            }
        });
    });
    $('#demand').click(function () {
        tableIns.reload({
            url: '/Home/GetDemandDataForTable'
            , page: {
                curr: 1
            }
            , initSort: {
                field: 'demandTotalCount'
                , type: 'desc'
            }
            , where: {
                field: 'demandTotalCount'
                , order: 'desc'
            }
            , cols: [[
                { type: 'numbers', title: '编号' }
                , {
                    field: 'city', title: '城市', width: 100, templet: function (d) {
                        return '<a class="cityName" statistics-id="' + d.cityCode + '">' + d.city + '</a>';
                    }
                }
                , { field: 'demandTotalCount', title: '客源总数', width: 110, sort: true }
                //, { field: 'demandAvailableCount', title: '有效总数', sort: true }
                , { field: 'demandIncreasedCount', title: '新增客源', sort: true }
                , { field: 'rentDemandTotalCount', title: '买房客源总数', sort: true }
                , { field: 'rentDemandIncreasedCount', title: '新增买房客源', sort: true }
                , { field: 'secondDemandTotalCount', title: '租房客源总数', sort: true }
                , { field: 'secondDemandIncreasedCount', title: '新增租房客源', sort: true }
                , {
                    field: 'statisticsTime', title: '统计时间', sort: true, width: 160, templet: function (d) {
                        return util.toDateString(d.statisticsTime, 'yyyy-MM-dd HH:mm:ss');
                    }
                }
            ]]
            , done: function () {
                $('.cityName[statistics-id]').on('click', function () {
                    $('#statistics_region').hide();
                    $('#acquisition_region').hide();
                    $('#detection_region').hide();
                    var cityCode = $(this).attr('statistics-id');
                    var cityName = $(this).text();
                    $.ajax({
                        type: "GET",
                        dataType: "html",
                        url: "/Home/CityDetail",
                        data: { cityCode: cityCode, type: 'demand' },
                        success: function (data) {
                            sessionStorage.setItem('cityName', cityName);
                            $('#city_detection_region').empty().append(data);
                            $('#city_detection_region').show();
                        }
                    });
                });
            }
        })
    });
    $('#track').click(function () {
        tableIns.reload({
            url: '/Home/GetTrackDataForTable'
            , page: {
                curr: 1 //重新从第 1 页开始
            }
            , initSort: {
                field: 'trackTotalCount'
                , type: 'desc'
            }
            , where: {
                field: 'trackTotalCount'
                , order: 'desc'
            }
            , cols: [[
                { type: 'numbers', title: '编号' }
                , {
                    field: 'city', title: '城市', templet: function (d) {
                        return '<a class="cityName" statistics-id="' + d.cityCode + '">' + d.city + '</a>';
                    }
                }
                , { field: 'trackTotalCount', title: '跟进总数', sort: true }
                , { field: 'trackAvailableCount', title: '有效总数', sort: true }
                , { field: 'trackIncreasedCount', title: '新增跟进', sort: true }
                , { field: 'houseTrackTotalCount', title: '房源跟进总数', sort: true }
                , { field: 'houseTrackIncreasedCount', title: '新增房源跟进', sort: true }
                , { field: 'demandTrackTotalCount', title: '客源跟进总数', sort: true }
                , { field: 'demandTrackIncreasedCount', title: '新增客源跟进', sort: true }
                , {
                    field: 'statisticsTime', title: '统计时间', sort: true, width: 160, templet: function (d) {
                        return util.toDateString(d.statisticsTime, 'yyyy-MM-dd HH:mm:ss');
                    }
                }
            ]]
            , done: function () {
                $('.cityName[statistics-id]').on('click', function () {
                    $('#statistics_region').hide();
                    $('#acquisition_region').hide();
                    $('#detection_region').hide();
                    var cityCode = $(this).attr('statistics-id');
                    var cityName = $(this).text();
                    $.ajax({
                        type: "GET",
                        dataType: "html",
                        url: "/Home/CityDetail",
                        data: { cityCode: cityCode, type: 'track' },
                        success: function (data) {
                            sessionStorage.setItem('cityName', cityName);
                            $('#city_detection_region').empty().append(data);
                            $('#city_detection_region').show();
                        }
                    });
                });
            }
        })
    });
    $('#visitSurvey').click(function () {
        tableIns.reload({
            url: '/Home/GetVisitSurveyDataForTable'
            , page: {
                curr: 1
            }
            , initSort: {
                field: 'visitTotalCount'
                , type: 'desc'
            }
            , where: {
                field: 'visitTotalCount'
                , order: 'desc'
            }
            , cols: [[
                { type: 'numbers', title: '编号' }
                , {
                    field: 'city', title: '城市', templet: function (d) {
                        return '<a class="cityName" statistics-id="' + d.cityCode + '">' + d.city + '</a>';
                    }
                }
                , { field: 'visitTotalCount', title: '带看总数', sort: true }
                , { field: 'visitAvailableCount', title: '有效带看', sort: true }
                , { field: 'visitIncreasedCount', title: '新增带看', sort: true }
                , { field: 'surveyTotalCount', title: '实勘总数', sort: true }
                , { field: 'surveyAvailableCount', title: '有效实勘', sort: true }
                , { field: 'surveyIncreasedCount', title: '新增实勘', sort: true }
                , {
                    field: 'statisticsTime', title: '统计时间', sort: true, width: 160, templet: function (d) {
                        return util.toDateString(d.statisticsTime, 'yyyy-MM-dd HH:mm:ss');
                    }
                }
            ]]
            , done: function () {
                $('.cityName[statistics-id]').on('click', function () {
                    $('#statistics_region').hide();
                    $('#acquisition_region').hide();
                    $('#detection_region').hide();
                    var cityCode = $(this).attr('statistics-id');
                    var cityName = $(this).text();
                    $.ajax({
                        type: "GET",
                        dataType: "html",
                        url: "/Home/CityDetail",
                        data: { cityCode: cityCode, type: 'visitSurvey' },
                        success: function (data) {
                            sessionStorage.setItem('cityName', cityName);
                            $('#city_detection_region').empty().append(data);
                            $('#city_detection_region').show();
                        }
                    });
                });
            }
        })
    });

    $('#statistics_search').keyup(function () {
        var keyWord = $('#statistics_search').val();
        table.reload('statisticsTable', {
            where: {
                filter: keyWord
            }
            , page: {
                curr: 1
            }
        });
    });

    table.render({
        elem: '#service_detection'
        , id: 'service_detection'
        , url: '/Home/GetServiceDetectionDataForTable'
        , initSort: {
            field: 'lastUnableAccessibleTime'
            , type: 'desc'
        }
        , where: {
            field: 'lastUnableAccessibleTime'
            , serviceType: 0
            , order: 'desc'
        }
        , autoSort: false
        , page: true
        , limit: 20
        , cols: [[
            { type: 'numbers', title: '编号' }
            , {
                field: 'city', title: '城市', templet: function (d) {
                    return '<a class="cityName" data-detectionid="' + d.id + '">' + d.city + '</a>';
                }
            }
            , {
                field: 'serviceType', title: '服务类型', width: 105, sort: true, templet: function (d) {
                    var services = ["Sync", "VIPHouse", "Message", "Setting"];
                    return services[d.serviceType - 1];
                }
            }
            , {
                field: 'accessibleRate', title: '可访问性(%)', width: 124, sort: true, templet: function (d) {
                    return d.accessibleRate;
                }
            }
            , { field: 'totalAccessibleCount', title: '总访问', width: 87, sort: true }
            , { field: 'unableAccessibleCount', title: '不可访问', width: 101, sort: true }
            , { field: 'bigthan5sAccessibleCount', title: '超过5s', width: 90, sort: true }
            , { field: 'bigthan2sAccessibleCount', title: '超过2s', width: 90, sort: true }
            , { field: 'lastUnableAccessibleTime', title: '最近不可访问', width: 161, sort: true }
            , {
                field: 'lastAccessibleState', title: '最后状态', width: 101, sort: true, templet: function (d) {
                    return `<div class="${d.lastAccessibleState}-div"></div>`;
                }
            }
            , {
                field: 'lastResponseDuration', title: '最后响应', width: 101, sort: true, templet: function (d) {
                    return d.lastAccessibleState === 'red' && d.lastResponseDuration >= 15 ? "不可访问" : d.lastResponseDuration;
                }
            }
            , {
                field: 'lastAccessibleTime', title: '最后一次访问', width: 161, sort: true, templet: function (d) {
                    return util.toDateString(d.lastAccessibleTime, 'yyyy-MM-dd HH:mm:ss');
                }
            }
        ]]
        , done: function () {
            $('.cityName[data-detectionid]').on('click', function () {
                $('#statistics_region').hide();
                $('#acquisition_region').hide();
                $('#detection_region').hide();
                var detectionId = $(this).attr('data-detectionid');
                $.ajax({
                    type: "GET",
                    dataType: "html",
                    url: "/Home/GetServiceDetectionByCity",
                    data: { detectionId: detectionId },
                    success: function (data) {
                        $('#city_detection_region').empty().append(data);
                        $('#city_detection_region').show();
                    }
                });
            });
        }
    });
    //监听排序事件
    table.on('sort(service_detection)', function (obj) {
        table.reload('service_detection', {
            initSort: obj
            , where: {
                field: obj.field
                , order: obj.type
            }
        });
    });
    //下拉框事件
    form.on('select(service_type_filter)', function (data) {
        var keyWord = $('#detection_search').val();
        table.reload('service_detection', {
            where: {
                filter: keyWord,
                serviceType: data.value
            }
            , page: {
                curr: 1
            }
        });
    });

    $('#statistics').click(function () {
        $('#statistics_region').show();
        $('#detection_region').hide();
        $('#city_detection_region').hide();
        $('#acquisition_region').hide();
        $('#news_region').hide();
    });
    $('#detection').click(function () {
        $('#detection_region').show();
        table.resize('service_detection');
        table.resize('detection_exception_table');
        $('#statistics_region').hide();
        $('#city_detection_region').hide();
        $('#acquisition_region').hide();
        $('#news_region').hide();
    });
    $('#acquisition').click(function () {
        $('#detection_region').hide();
        $('#statistics_region').hide();
        $('#city_detection_region').hide();
        $('#acquisition_region').show();
        table.resize('acquisitionTable');
        $('#news_region').hide();
    });
    $('#news').click(function () {
        $('#detection_region').hide();
        $('#statistics_region').hide();
        $('#city_detection_region').hide();
        $('#acquisition_region').hide();
        table.resize('acquisitionTable');
        //$('#news_region').show();
        $.ajax({
            type: "GET",
            dataType: "html",
            url: "/NewsAnalysis/Index",
            success: function (data) {
                $('#news_region').empty().append(data);
                $('#news_region').show();
                $('#nav-item-0').click();
            }
        });
    });

    $('#detection_search').keyup(function () {
        var keyWord = $('#detection_search').val();
        table.reload('service_detection', {
            where: {
                filter: keyWord
            }
            , page: {
                curr: 1
            }
        });
    });

    setInterval(function () {
        $.ajax({
            type: "GET",
            dataType: "json",
            url: "/Home/GetIndexViewModel",
            timeout: 3000,
            success: function (data) {
                var statistics = data.statistics;
                var house_count = formatStatisticsData(statistics.houseCount);
                var demand_count = formatStatisticsData(statistics.demandCount);
                var track_count = formatStatisticsData(statistics.trackCount);
                var visit_count = formatStatisticsData(statistics.visitCount);
                var survey_count = formatStatisticsData(statistics.surveyCount);

                var house_increased_count = formatStatisticsData(statistics.houseIncreasedCount);
                var demand_increased_count = formatStatisticsData(statistics.demandIncreasedCount);
                var track_increased_count = formatStatisticsData(statistics.trackIncreasedCount);
                var visit_increased_count = formatStatisticsData(statistics.visitIncreasedCount);
                var survey_increased_count = formatStatisticsData(statistics.surveyIncreasedCount);

                $('#house_count').text(house_count);
                $('#demand_count').text(demand_count);
                $('#track_count').text(track_count);
                $('#visit_count').text(visit_count);
                $('#survey_count').text(survey_count);

                $('#house_increased_count').text(house_increased_count);
                $('#demand_increased_count').text(demand_increased_count);
                $('#track_increased_count').text(track_increased_count);
                $('#visit_increased_count').text(visit_increased_count);
                $('#survey_increased_count').text(survey_increased_count);

                var acquisition = data.acquisition;
                var acquisition_house_count = formatStatisticsData(acquisition.totalHouseCount);
                var acquisitio_house_increased_count = formatStatisticsData(acquisition.totalHouseIncreasedCount);
                var acquisition_second_count = formatStatisticsData(acquisition.secondHouseCount);
                var acquisition_second_increased_count = formatStatisticsData(acquisition.secondHouseIncreasedCount);
                var acquisition_rent_count = formatStatisticsData(acquisition.rentHouseCount);
                var acquisition_rent_increased_count = formatStatisticsData(acquisition.rentHouseIncreasedCount);

                $('#acquisition_house_count').text(acquisition_house_count);
                $('#acquisitio_house_increased_count').text(acquisitio_house_increased_count);
                $('#acquisition_second_count').text(acquisition_second_count);
                $('#acquisition_second_increased_count').text(acquisition_second_increased_count);
                $('#acquisition_rent_count').text(acquisition_rent_count);
                $('#acquisition_rent_increased_count').text(acquisition_rent_increased_count);

                $("#statistics_region .layui-laypage-btn").click();
            }
        });
    }, 600000)

    setInterval(function () {
        $.ajax({
            url: '/Home/GetServiceDetectionDataForTable'
            , data: {
                limit: 1
                , page: 1
                , field: 'lastUnableAccessibleTime'
                , order: 'desc'
            }
            , dataType: 'json'
            , timeout: 3000
            , success: function () {
                $("#detection_region .layui-laypage-btn").click();
            }
        });
    }, 60000);

    table.render({
        elem: '#acquisitionTable'
        , id: 'acquisitionTable'
        , url: '/Home/GetAcquisitionDataForTable'
        , initSort: {
            field: 'totalCount'
            , type: 'desc'
        }
        , where: {
            field: 'totalCount'
            , order: 'desc'
        }
        , autoSort: false
        , page: true
        , limit: 20
        , cols: [[
            { type: 'numbers', title: '编号' }
            , {
                field: 'city', title: '城市', templet: function (d) {
                    return '<a class="cityName" acquisition-id="' + d.cityCode + '">' + d.city + '</a>';
                }
            }
            , { field: 'totalCount', title: '采集房源总数', sort: true }
            , { field: 'secondTotalCount', title: '采集二手房总数', sort: true }
            , { field: 'rentTotalCount', title: '采集租房总数', sort: true }
            , { field: 'totalIncreasedCount', title: '新增采集总数', sort: true }
            , {
                field: 'statisticsTime', title: '统计时间', sort: true, width: 160, templet: function (d) {
                    return util.toDateString(d.statisticsTime, 'yyyy-MM-dd HH:mm:ss');
                }
            }
        ]]
        , done: function () {
            $('.cityName[acquisition-id]').on('click', function () {
                $('#statistics_region').hide();
                $('#acquisition_region').hide();
                $('#detection_region').hide();
                var cityCode = $(this).attr('acquisition-id');
                var cityName = $(this).text();
                $.ajax({
                    type: "GET",
                    dataType: "html",
                    url: "/Home/CityDetail",
                    data: { cityCode: cityCode, type: 'acquisition' },
                    success: function (data) {
                        sessionStorage.setItem('cityName', cityName);
                        $('#city_detection_region').empty().append(data);
                        $('#city_detection_region').show();
                    }
                });
            });
        }
    });
    table.on('sort(acquisitionTable)', function (obj) {
        table.reload('acquisitionTable', {
            initSort: obj
            , where: {
                field: obj.field
                , order: obj.type
            }
        });
    });

    $('#acquisition_search').keyup(function () {
        var keyWord = $('#acquisition_search').val();
        table.reload('acquisitionTable', {
            where: {
                filter: keyWord
            }
            , page: {
                curr: 1
            }
        });
    });

    //服务监测-异常视图
    exceptionStartDate = util.toDateString((new Date().setDate(new Date().getDate() - 30)), 'yyyy-MM-dd');
    exceptionEndDate = util.toDateString(new Date(), 'yyyy-MM-dd');
    laydate.render({
        elem: '#date_range'
        , range: '~'
        , value: exceptionStartDate + ' ~ ' + exceptionEndDate
        , done: function (value, date, endDate) {
            exceptionStartDate = $.trim(value.split('~')[0]);
            exceptionEndDate = $.trim(value.split('~')[1]);
            reloadDetectionExceptionTable(table);
        }
    });
    $('#detection_exception').click(function () {
        $('#detection_exception_view').show();
        $('#detection_city_view').hide();
    });
    $('#detection_city').click(function () {
        $('#detection_exception_view').hide();
        $('#detection_city_view').show();
    });
    table.render({
        elem: '#detection_exception_table'
        , id: 'detection_exception_table'
        , url: '/Home/GetServiceExceptionViewDataForTable'
        , initSort: {
            field: 'accessibleTime'
            , type: 'desc'
        }
        , where: {
            filter: exceptionSearchKeyword,
            serviceType: exceptionServiceType,
            startDate: exceptionStartDate,
            endDate: exceptionEndDate,
            field: 'accessibleTime',
            order: 'desc'
        }
        , autoSort: false
        , page: true
        , limit: 20
        , cols: [[
            { type: 'numbers', title: '编号', width: 60 }
            , { field: 'city', title: '城市' }
            , {
                field: 'serviceType', title: '测试服务', templet: function (d) {
                    var services = ["Sync", "VIPHouse", "Message", "Setting"];
                    return services[d.serviceType - 1];
                }
            }
            , { field: 'ip', title: 'IP地址', sort: true }
            , { field: 'responseTime', title: '响应时间', sort: true }
            , {
                field: 'accessibleTime', title: '测试时间', sort: true, width: 166, templet: function (d) {
                    return util.toDateString(d.accessibleTime, 'yyyy-MM-dd HH:mm:ss');
                }
            }
        ]]
    });
    //下拉框事件
    form.on('select(exception_service_type_filter)', function (data) {
        exceptionSearchKeyword = $('#detection_exception_search').val();
        exceptionServiceType = data.value;
        reloadDetectionExceptionTable(table);
    });
    $('#detection_exception_search').keyup(function () {
        exceptionSearchKeyword = $('#detection_exception_search').val();
        reloadDetectionExceptionTable(table);
    });

    table.on('sort(detection_exception_table)', function (obj) {
        table.reload('detection_exception_table', {
            initSort: obj
            , where: {
                field: obj.field
                , order: obj.type
            }
        });
    });
});

function formatStatisticsData(num) {
    return num.toString().split('').reverse().join('')
        .replace(/(\d{4})/g, '$1 ').replace(/\,$/, '').split('').reverse().join('');
}

function reloadDetectionExceptionTable(table) {
    table.reload('detection_exception_table', {
        where: {
            filter: exceptionSearchKeyword,
            serviceType: exceptionServiceType,
            startDate: exceptionStartDate,
            endDate: exceptionEndDate
        }
        , page: {
            curr: 1
        }
    });
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Models
{
    public class News
    {
        public int Id { get; set; }
        public DateTime PublishTime { get; set; }
        public string Title { get; set; }
        public int CompanyId { get; set; }
        public string Summary { get; set; }
        public string NewsUrl { get; set; }
    }
}

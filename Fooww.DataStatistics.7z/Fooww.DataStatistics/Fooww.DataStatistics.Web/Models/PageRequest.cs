﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Models
{
    public class PageRequest
    {
        public int Limit { get; set; }
        public int Page { get; set; }
        public string Filter { get; set; }
        public string Field { get; set; }
        public string Order { get; set; }
        public int ServiceType { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}

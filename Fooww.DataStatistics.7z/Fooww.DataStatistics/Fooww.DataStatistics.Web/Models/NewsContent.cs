﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Models
{
    public class NewsContent
    {
        public int Id { get; set; }
        public int NewsId { get; set; }
        public string Content { get; set; }
    }
}

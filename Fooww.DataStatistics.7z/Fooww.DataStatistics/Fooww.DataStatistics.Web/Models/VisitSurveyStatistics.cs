﻿using System;

namespace Fooww.DataStatistics.Web.Models
{
    public class VisitSurveyStatistics
    {
        public int Id { get; set; }
        public long VisitTotalCount { get; set; }
        public long VisitAvailableCount { get; set; }
        public int VisitIncreasedCount { get; set; }
        public long SurveyTotalCount { get; set; }
        public long SurveyAvailableCount { get; set; }
        public int SurveyIncreasedCount { get; set; }
        public string CityCode { get; set; }
        public DateTime StatisticsTime { get; set; }
        public int LatestStatisticsId { get; set; }
        public string LastVisitExecutionTime { get; set; }
        public string LastSurveyCreateTime { get; set; }
    }
}
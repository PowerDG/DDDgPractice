﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Models
{
    public class City
    {
        public string Name { get; set; }
        public string Domain { get; set; }
        public string Alias_Name { get; set; }
        public string Is_Deleted { get; set; }
        public string Vip_Enable { get; set; }
        public string Sync_Enable { get; set; }
    }
}

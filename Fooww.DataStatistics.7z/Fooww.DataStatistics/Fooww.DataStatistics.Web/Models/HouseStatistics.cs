﻿using System;

namespace Fooww.DataStatistics.Web.Models
{
    public class HouseStatistics
    {
        public int Id { get; set; }
        public long HouseTotalCount { get; set; }
        public long HouseAvailableCount { get; set; }
        public int HouseIncreasedCount { get; set; }
        public long SecondHouseTotalCount { get; set; }
        public int SecondHouseIncreasedCount { get; set; }
        public long RentHouseTotalCount { get; set; }
        public int RentHouseIncreasedCount { get; set; }
        public string CityCode { get; set; }
        public DateTime StatisticsTime { get; set; }
        public int LatestStatisticsId { get; set; }
        public long LastSecondId { get; set; }
        public long LastRentId { get; set; }
    }
}
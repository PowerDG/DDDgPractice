﻿using System;

namespace Fooww.DataStatistics.Web.Models
{
    public class TrackStatistics
    {
        public int Id { get; set; }
        public long TrackTotalCount { get; set; }
        public long TrackAvailableCount { get; set; }
        public int TrackIncreasedCount { get; set; }
        public long HouseTrackTotalCount { get; set; }
        public int HouseTrackIncreasedCount { get; set; }
        public long DemandTrackTotalCount { get; set; }
        public int DemandTrackIncreasedCount { get; set; }
        public string CityCode { get; set; }
        public DateTime StatisticsTime { get; set; }
        public int LatestStatisticsId { get; set; }
        public string LastTrackOperateTime { get; set; }
    }
}
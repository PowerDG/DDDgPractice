﻿using System;

namespace Fooww.DataStatistics.Web.Models
{
    public class DemandStatistics
    {
        public int Id { get; set; }
        public long DemandTotalCount { get; set; }
        //public long DemandAvailableCount { get; set; }
        public int DemandIncreasedCount { get; set; }
        public long SecondDemandTotalCount { get; set; }
        public int SecondDemandIncreasedCount { get; set; }
        public long RentDemandTotalCount { get; set; }
        public int RentDemandIncreasedCount { get; set; }
        public string CityCode { get; set; }
        public DateTime StatisticsTime { get; set; }
        public int LatestStatisticsId { get; internal set; }
        public long LastSecondId { get; set; }
        public long LastRentId { get; set; }
    }
}
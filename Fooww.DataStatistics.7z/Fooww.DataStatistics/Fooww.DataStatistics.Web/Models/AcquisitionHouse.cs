﻿using System;

namespace Fooww.DataStatistics.Web.Models
{
    public class AcquisitionHouse
    {
        public int Id { get; set; }
        public long TotalCount { get; set; }
        public int IncreasedCount { get; set; }
        public long SecondTotalCount { get; set; }
        public int SecondIncreasedCount { get; set; }
        public long RentTotalCount { get; set; }
        public int RentIncreasedCount { get; set; }
        public string CityCode { get; set; }
        public DateTime StatisticsTime { get; set; }
        public long LastSecondId { get; set; }
        public long LastRentId { get; set; }
    }
}
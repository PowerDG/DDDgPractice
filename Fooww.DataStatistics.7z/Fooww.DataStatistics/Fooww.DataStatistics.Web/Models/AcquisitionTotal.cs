﻿using System;

namespace Fooww.DataStatistics.Web.Models
{
    public class AcquisitionTotal
    {
        public int Id { get; set; }
        public long TotalHouseCount { get; set; }
        public int TotalHouseIncreasedCount { get; set; }
        public long SecondHouseCount { get; set; }
        public int SecondHouseIncreasedCount { get; set; }
        public long RentHouseCount { get; set; }
        public int RentHouseIncreasedCount { get; set; }
        public DateTime StatisticsTime { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Models
{
    public class OriginalStatistics
    {
        //房源
        public int SecondHouseTotalCount { get; set; }
        public int SecondHouseAvailableCount { get; set; }
        public int RentHouseTotalCount { get; set; }
        public int RentHouseAvailableCount { get; set; }
        public int HouseTotalCount { get; set; }
        public int HouseAvailableCount { get; set; }
        //客源
        public int SecondDemandTotalCount { get; set; }
        public int SecondDemandAvailableCount { get; set; }
        public int RentDemandTotalCount { get; set; }
        public int RentDemandAvailableCount { get; set; }
        public int DemandTotalCount { get; set; }
        public int DemandAvailableCount { get; set; }
        //跟进
        public int TrackTotalCount { get; set; }
        public int TrackAvailableCount { get; set; }
        public int HouseTrackTotalCount { get; set; }
        public int DemandTrackTotalCount { get; set; }
        //带看实勘
        public int VisitTotalCount { get; set; }
        public int VisitAvailableCount { get; set; }
        public int SurveyTotalCount { get; set; }
        public int SurveyAvailableCount { get; set; }

        public DateTime StatisticsTime { get; set; }
        public string CityCode { get; set; }
    }
}

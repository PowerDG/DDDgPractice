﻿using System;

namespace Fooww.DataStatistics.Web.Models
{
    public class ServiceException
    {
        public int Id { get; set; }
        public string CityCode { get; set; }
        public int ServiceType { get; set; }
        public double ResponseDuration { get; set; }
        public DateTime AccessibleTime { get; set; }
        public int IsAccessible { get; set; }
        public string Ip { get; set; }
    }
}
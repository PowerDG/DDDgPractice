﻿using System;

namespace Fooww.DataStatistics.Web.Models
{
    public class LatestStatistics
    {
        public int Id { get; set; }
        public long HouseCount { get; set; }
        public int HouseIncreasedCount { get; set; }
        public long HouseDemandCount { get; set; }
        public int HouseIncreasedDemandCount { get; set; }
        public long TrackCount { get; set; }
        public int TrackIncreasedCount { get; set; }
        public long VisitCount { get; set; }
        public int VisitIncreasedCount { get; set; }
        public long SurveyCount { get; set; }
        public int SurveyIncreasedCount { get; set; }
        public DateTime StatisticsTime { get; set; }
    }
}
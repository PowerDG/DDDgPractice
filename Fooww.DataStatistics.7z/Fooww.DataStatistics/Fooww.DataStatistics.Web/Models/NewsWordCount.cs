﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Models
{
    public class NewsWordCount
    {
        public int Id { get; set; }
        public string Word { get; set; }
        public int Count { get; set; }
        public int CompanyId { get; set; }
    }
}

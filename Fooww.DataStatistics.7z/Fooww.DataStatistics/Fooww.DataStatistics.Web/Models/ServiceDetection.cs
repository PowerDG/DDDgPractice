﻿using System;

namespace Fooww.DataStatistics.Web.Models
{
    public class ServiceDetection
    {
        public int Id { get; set; }
        public string CityCode { get; set; }
        public double AccessibleRate { get; set; }
        public int TotalAccessibleCount { get; set; }
        public int UnableAccessibleCount { get; set; }
        public int Bigthan5sAccessibleCount { get; set; }
        public int Bigthan2sAccessibleCount { get; set; }
        public DateTime? LastUnableAccessibleTime { get; set; }
        public string LastAccessibleState { get; set; }
        public double LastResponseDuration { get; set; }
        public DateTime LastAccessibleTime { get; set; }
        public string Ip { get; set; }
        /// <summary>
        /// 1=SyncService,2=VipService,3=StaService,4=WwwService
        /// </summary>
        public int ServiceType { get; set; }
    }
}
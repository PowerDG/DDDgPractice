﻿using Fooww.DataStatistics.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Controllers
{
    [Authorize]
    public class DataChartsController : Controller
    {
        private ScheduleService m_scheduleService;

        public DataChartsController(ScheduleService scheduleService)
        {
            m_scheduleService = scheduleService;
        }

        public JsonResult ExecuteAllCityWebService()
        {
            m_scheduleService.StartSchedule();
            return Json(new { message = "启动数据统计排程！" });
        }

        public async Task<string> ExecuteAllCityWebServiceSY()
        {
            await m_scheduleService.ExecuteAllCityWebServiceSY();
            return $"sy城市service开始统计！";
        }

        public JsonResult ExecuteServiceDetection()
        {
            m_scheduleService.StartServiceDetection();
            return Json(new { message = "启动站点监测排程！" });
        }
        public async Task<string> ExecuteAcquisitionSY()
        {
            await m_scheduleService.StartAcquisitionSY();
            return $"sy城市采集数据开始统计！";
        }
        public JsonResult ExecuteAcquisition()
        {
            m_scheduleService.StartAcquisition();
            return Json(new { message = "启动采集数据排程！" });
        }

    }
}
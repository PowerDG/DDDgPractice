﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Fooww.DataStatistics.Web.Models;
using Fooww.DataStatistics.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Fooww.DataStatistics.Web.Controllers
{
    public class NewsAnalysisController : Controller
    {
        private readonly NewsAnalysisService m_newsAnalysisService;
        public NewsAnalysisController(NewsAnalysisService newsAnalysisService)
        {
            m_newsAnalysisService = newsAnalysisService;
        }

        public async Task<IActionResult> Index()
        {
            var newsCompanyModel = (await m_newsAnalysisService.GetNewsCompany()).ToList();
            ViewBag.newsCompanyModel = newsCompanyModel;
            return View(newsCompanyModel);
        }

        [HttpGet]
        public async Task<JsonResult> GetNews(int companyId, string titleFilter, DateTime startTime, DateTime endTime, int page, int limit)
        {
            return Json(await m_newsAnalysisService.GetNews(companyId, titleFilter, startTime, endTime, page, limit));
        }

        [HttpGet]
        public async Task<JsonResult> GetNewsCount(int companyId, string titleFilter, DateTime startTime, DateTime endTime)
        {
            return Json(await m_newsAnalysisService.GetNewsCount(companyId, titleFilter, startTime, endTime));
        }

        //[HttpGet]
        //public async Task<JsonResult> GetNewsContent(int newsId)
        //{
        //    var newsContent = m_database.GetSQL<string>($@"SELECT contents FROM news_content WHERE news_id={newsId}");
        //    return Json(newsContent);
        //}

        [HttpGet]
        public async Task<JsonResult> GetWordCloudData(int companyId, DateTime startTime, DateTime endTime)
        {
            IEnumerable<NewsWordCount> newsWordCount;
            if (companyId == 0)
            {
                newsWordCount = await m_newsAnalysisService.GetNewsWordCount();
            }
            else
            {
                newsWordCount= await m_newsAnalysisService.GetNewsWordCount(companyId);
            }
            dynamic result = newsWordCount.Select(newsword => new { name = newsword.Word, value = newsword.Count });
            return Json(new { data = result });
        }

    }

}
﻿using Fooww.DataStatistics.Web.Models;
using Fooww.DataStatistics.Web.Services;
using Fooww.DataStatistics.Web.ViewModels.Home;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly IConfiguration m_configuration;
        private readonly HomeService m_homeService;
        private readonly ILogger<HomeController> m_logger;

        public HomeController(IConfiguration configuration, ILogger<HomeController> logger, HomeService homeService)
        {
            m_logger = logger;
            m_homeService = homeService;
            m_configuration = configuration;
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult Login(string returnUrl = null)
        {
            if (HttpContext.User?.Identity?.IsAuthenticated ?? false)
            {
                return RedirectToAction("Index");
            }

            TempData["returnUrl"] = returnUrl;
            return View();
        }

        public IActionResult CityDetail(string cityCode, string type)
        {
            ViewBag.cityCode = cityCode;
            ViewBag.type = type;
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login(string userName, string password, string returnUrl = null)
        {
            if (userName == m_configuration["Authentication:UserName"] && password == m_configuration["Authentication:Password"])
            {
                var claims = new List<Claim>
                    {
                        new Claim("Account", userName, ClaimValueTypes.String)
                    };
                var userIdentity = new ClaimsIdentity("localUserInfo");
                userIdentity.AddClaims(claims);
                await HttpContext.SignInAsync(m_configuration["Cookies:SchemeName"], new ClaimsPrincipal(userIdentity),
                         new AuthenticationProperties()
                         {
                             AllowRefresh = true,
                             IsPersistent = true,
                             ExpiresUtc = DateTime.UtcNow.AddYears(10)
                         });

                if (returnUrl == null)
                {
                    returnUrl = TempData["returnUrl"]?.ToString();
                }
                if (returnUrl != null)
                {
                    return Redirect(returnUrl);
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            else
            {
                TempData["LoginErrorMessage"] = "用户名或密码错误!";
                return View();
            }
        }

        public async Task<IActionResult> Index()
        {
            IndexViewModel viewModel = await m_homeService.GetIndexViewModel();
            return View(viewModel);
        }

        public async Task<JsonResult> GetIndexViewModel()
        {
            IndexViewModel viewModel = await m_homeService.GetIndexViewModel();
            return Json(viewModel);
        }

        public async Task<JsonResult> GetHouseDataForTable(PageRequest request)
        {
            return Json(await m_homeService.GetHousePageData(request));
        }

        public async Task<JsonResult> GetDemandDataForTable(PageRequest request)
        {
            return Json(await m_homeService.GetDemandPageData(request));
        }

        public async Task<JsonResult> GetTrackDataForTable(PageRequest request)
        {
            return Json(await m_homeService.GetTrackPageData(request));
        }

        public async Task<JsonResult> GetVisitSurveyDataForTable(PageRequest request)
        {
            return Json(await m_homeService.GetVisitSurveyPageData(request));
        }

        public async Task<JsonResult> GetServiceDetectionDataForTable(PageRequest request)
        {
            return Json(await m_homeService.GetServiceDetectionPageData(request));
        }

        public async Task<IActionResult> GetServiceDetectionByCity(int detectionId)
        {
            var viewModel = await m_homeService.GetServiceDetectionDetail(detectionId);
            return View(viewModel);
        }

        public async Task<JsonResult> GetServiceDetectionById(int detectionId)
        {
            return Json(await m_homeService.GetServiceDetectionDetail(detectionId));
        }

        public async Task<JsonResult> GetServiceDetectionByCityCodeAndServiceType(string cityCode, int serviceType)
        {
            return Json(await m_homeService.GetServiceDetectionDetail(cityCode, serviceType));
        }

        public async Task<JsonResult> GetServiceExceptionDataForTable(PageRequest request)
        {
            return Json(await m_homeService.GetServiceExceptionPageData(request));
        }

        public async Task<JsonResult> GetServiceExceptionDataForChart(string cityCode, int serviceType, int intervalHour)
        {
            return Json(await m_homeService.GetServiceExceptionDataForChart(cityCode, serviceType, intervalHour));
        }

        public JsonResult GetCities(string filter)
        {
            return Json(m_homeService.GetCities(filter));
        }

        public async Task<JsonResult> GetAcquisitionDataForTable(PageRequest request)
        {
            return Json(await m_homeService.GetAcquisitionPageData(request));
        }

        public async Task<JsonResult> GetStatisticsDataForCharts(string cityCode, string chartId)
        {
            return Json(await m_homeService.GetStatisticsDataForCharts(cityCode, chartId));
        }

        public async Task<JsonResult> GetServiceExceptionViewDataForTable(PageRequest request)
        {
            return Json(await m_homeService.GetServiceDetectionViewPageData(request));
        }
    }
}
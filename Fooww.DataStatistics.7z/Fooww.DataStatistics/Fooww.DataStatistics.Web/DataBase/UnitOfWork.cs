﻿using System;
using System.Data;

namespace Fooww.DataStatistics.Web.DataBase
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IContext m_context;

        public UnitOfWork(IContext context)
        {
            m_context = context;
            m_context.BeginTransaction();
        }

        public void SaveChanges()
        {
            if (!m_context.IsTransactionStarted)
                throw new InvalidOperationException("Transaction have already been commited or disposed.");

            m_context.Commit();
        }

        public void Dispose()
        {
            if (m_context.IsTransactionStarted)
                m_context.Rollback();
        }
    }
}

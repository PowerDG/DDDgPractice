﻿using Fooww.DataStatistics.Web.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.DataBase
{
    public class DapperUnitOfWorkFactory : IUnitOfWorkFactory
    {
        private readonly DapperDBContext m_context;

        public DapperUnitOfWorkFactory(DapperDBContext context)
        {
            m_context = context;
        }

        public IUnitOfWork Create()
        {
            return new UnitOfWork(m_context);
        }
    }
}

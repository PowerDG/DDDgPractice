﻿using Microsoft.Extensions.Options;
using MySql.Data.MySqlClient;
using Fooww.DataStatistics.Web.DataBase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.DataBase
{
    public class MySqlDBContext : DapperDBContext
    {
        public MySqlDBContext(IOptions<DapperDBContextOptions> optionsAccessor) : base(optionsAccessor)
        {
        }

        protected override IDbConnection CreateConnection(string connectionString)
        {
            IDbConnection conn = new MySqlConnection(connectionString);
            return conn;
        }
    }
}

﻿namespace Fooww.DataStatistics.Web.ViewModels.Home
{
    public class IndexViewModel
    {
        public StatisticsViewModel Statistics { get; set; }
        public AcquisitionViewModel Acquisition { get; set; }
    }

    public class StatisticsViewModel
    {
        public long HouseCount { get; set; }
        public int HouseIncreasedCount { get; set; }
        public long DemandCount { get; set; }
        public int DemandIncreasedCount { get; set; }
        public long TrackCount { get; set; }
        public int TrackIncreasedCount { get; set; }
        public int VisitIncreasedCount { get; set; }
        public long VisitCount { get; set; }
        public long SurveyCount { get; set; }
        public int SurveyIncreasedCount { get; set; }
    }

    public class AcquisitionViewModel
    {
        public long TotalHouseCount { get; set; }
        public int TotalHouseIncreasedCount { get; set; }
        public long SecondHouseCount { get; set; }
        public int SecondHouseIncreasedCount { get; set; }
        public long RentHouseCount { get; set; }
        public int RentHouseIncreasedCount { get; set; }
    }
}
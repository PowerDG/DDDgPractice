﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.ViewModels.Home
{
    public class GetServiceDetectionByCityViewModel
    {
        public int Id { get; set; }
        public string CityCode { get; set; }
        public string CityName { get; set; }
        public string Domain { get; set; }
        public string Ip { get; set; }
        public string LastAccessibleState { get; set; }
        public string AccessibleRate { get; set; }
        public string LastResponseDuration { get; set; }
        public string LastUnableAccessibleTime { get; set; }
        public int UnableAccessibleCount { get; set; }
        public int Bigthan5sAccessibleCount { get; set; }
        /// <summary>
        /// 1=SyncService,2=VipService
        /// </summary>
        public int ServiceType { get; set; }
        public int TotalAccessibleCount { get; set; }
    }
}

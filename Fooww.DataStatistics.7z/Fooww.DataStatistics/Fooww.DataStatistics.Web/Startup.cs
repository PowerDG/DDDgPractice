﻿using Fooww.DataStatistics.Web.DataBase;
using Fooww.DataStatistics.Web.hangfire;
using Fooww.DataStatistics.Web.Repository;
using Fooww.DataStatistics.Web.Services;
using Hangfire;
using Hangfire.MySql;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using System;
using System.Transactions;

namespace Fooww.DataStatistics.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            services.AddDapperDBContext<MySqlDBContext>(options =>
            {
                options.Configuration = Configuration["ConnectionStrings:MySqlConnection"];
            });
            services.AddAuthentication(Configuration["Cookies:SchemeName"])
                .AddCookie(Configuration["Cookies:SchemeName"], options =>
                {
                    options.LoginPath = new PathString("/home/login");
                });

            services.AddTransient<HouseStatisticsRepository>();
            services.AddTransient<DemandStatisticsRepository>();
            services.AddTransient<LatestStatisticsRepository>();
            services.AddTransient<TrackStatisticsRepository>();
            services.AddTransient<VisitSurveyStatisticsRepository>();
            services.AddTransient<ServiceDetectionRepository>();
            services.AddTransient<ServiceExceptionRepository>();
            services.AddTransient<AcquisitionHouseRepository>();
            services.AddTransient<AcquisitionTotalRepository>();

            services.AddTransient<NewestAcquisitionHouseRepository>();
            services.AddTransient<NewestVisitSurveyStatisticsRepository>();
            services.AddTransient<NewestTrackStatisticsRepository>();
            services.AddTransient<NewestHouseStatisticsRepository>();
            services.AddTransient<NewestDemandStatisticsRepository>();

            services.AddTransient<ScheduleService>();
            services.AddTransient<HomeService>();

            services.AddTransient<NewsRepository>();
            services.AddTransient<NewsWordCountRepository>();
            services.AddTransient<NewsCompanyRepository>();
            services.AddTransient<NewsAnalysisService>();

            services.AddHangfire(config =>
            {
                config.UseStorage(new MySqlStorage(Configuration["ConnectionStrings:MySqlConnection"], new MySqlStorageOptions
                {
                    TransactionIsolationLevel = IsolationLevel.ReadCommitted,
                    QueuePollInterval = TimeSpan.FromSeconds(15),
                    JobExpirationCheckInterval = TimeSpan.FromMinutes(3),
                    CountersAggregateInterval = TimeSpan.FromMinutes(1),
                    PrepareSchemaIfNecessary = true,
                    DashboardJobListLimit = 50000,
                    TransactionTimeout = TimeSpan.FromMinutes(1),
                    TablesPrefix = "hangfire_",
                    NumberOfRecordsInSinglePass = 2500,
                    JobExpireIn = TimeSpan.FromHours(12)
                }));
            });

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            loggerFactory.AddNLog();

            app.UseHangfireServer(new BackgroundJobServerOptions
            {
                Queues = new[] { "heartbeat_sync", "heartbeat_vip", "statistics", "acquisition_vip", "default" },
                WorkerCount = Environment.ProcessorCount * 5
            });
            app.UseHangfireDashboard("/hangfire", new DashboardOptions
            {
                Authorization = new[] { new MyAuthorizationFilter() }
            });
            //app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();
            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
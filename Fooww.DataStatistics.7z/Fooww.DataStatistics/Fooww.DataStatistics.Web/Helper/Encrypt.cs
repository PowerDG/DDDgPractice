﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Helper
{
    /// <summary>
    /// 自定义加密解密
    /// </summary>
    public class Encrypt
    {

        /// <summary>
        /// 自定义加密
        ///  如果<seealso cref="OriginalStr"/>是空值或空串，则返回空串
        /// </summary>
        /// <param name="OriginalStr">需要加密的字符串</param>
        public static string EncodeString(string OriginalStr)
        {
            if (string.IsNullOrEmpty(OriginalStr))
            {
                return string.Empty;
            }

            //奇+1 偶-3 倒置
            string EncodeStr = "";
            long CharAsc;
            foreach (char c in OriginalStr.ToCharArray())
            {
                CharAsc = Convert.ToInt64(c);
                if (CharAsc < 35)
                {
                    continue;
                }
                if ((CharAsc % 2) == 1)
                {//保证ASCII不会越界
                    EncodeStr = Convert.ToString((char)(CharAsc + 1)) + EncodeStr;
                }
                else
                {
                    EncodeStr = Convert.ToString((char)(CharAsc - 3)) + EncodeStr;
                }
            }
            return EncodeStr;
        }

        /// <summary>
        ///  自定义解密
        ///  如果<seealso cref="EncodeStr"/>是空值或空串，则返回空串
        /// </summary>
        /// <param name="EncodeStr">需要解密的字符串</param>
        public static string DecodeString(string EncodeStr)
        {
            if (string.IsNullOrEmpty(EncodeStr))
            {
                return string.Empty;
            }

            //奇+3 偶-1 倒置
            string DecodeStr = "";
            long CharAsc;
            foreach (char c in EncodeStr.ToCharArray())
            {
                CharAsc = Convert.ToInt64(c);
                if ((CharAsc % 2) == 1)
                {//保证ASCII不会越界
                    DecodeStr = Convert.ToString((char)(CharAsc + 3)) + DecodeStr;
                }
                else
                {
                    DecodeStr = Convert.ToString((char)(CharAsc - 1)) + DecodeStr;
                }
            }

            return DecodeStr;
        }

        /// <summary>
        /// 生成Service访问Key
        /// </summary>
        /// <param name="PKUser"></param>
        /// <param name="apiUserID"></param>
        /// <param name="nowTicks"></param>
        /// <returns></returns>
        public static string GetServiceKey(Guid PKUser, int apiUserID, long nowTicks)
        {
            string serviceKey = "{0}-{1}-{2}";
            serviceKey = string.Format(serviceKey, PKUser.ToString().Replace("-", ""), apiUserID, nowTicks);
            return EncodeString(serviceKey);
        }

        #region Openlab Encyrpte
        public static int tinyint(int b)
        {
            while (b < 0)
                b += 256;
            while (b > 256)
                b -= 256;
            return b;
        }

        public static string EncryptPassword(string mid, string password)
        {
            Encoding encoding = Encoding.ASCII;
            int i, j, a, b, len;
            string ep = "";
            byte[] bmid;
            len = password.Length;
            try
            {
                Guid gmid = new Guid(mid);
                bmid = gmid.ToByteArray();
            }
            catch
            {
                bmid = encoding.GetBytes(mid);
            }

            byte[] bpassword = encoding.GetBytes(password);



            for (i = 0; i < 16; i++)
            {
                IFormatProvider nfi = new NumberFormatInfo();
                a = Convert.ToInt32(bmid[i]);
                a = tinyint(a);

                if (i < len)
                    b = Convert.ToInt32(bpassword[i]);
                else
                    b = Convert.ToInt32(bmid[i - len]);

                b = tinyint(b);

                b = ~b;
                b = tinyint(b);

                j = a ^ b;
                j = tinyint(j);
                j = Math.Abs(j) % 94 + 33;
                ep += (char)j;
            }
            return ep;
        }
        #endregion

    }
}

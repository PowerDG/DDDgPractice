﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fooww.DataStatistics.Web.Helper
{
    public static class DateTimeExtensions
    {
        public static string ToFormatString(this DateTime? dateTime)
        {
            if (dateTime == null)
            {
                return "--";
            }
            else
            {
                return dateTime.Value.ToString("yyyy-MM-dd HH:mm:ss");
            }
        }

        public static string ToFormatString(this DateTime dateTime)
        {
                return dateTime.ToString("yyyy-MM-dd HH:mm:ss");
        }

    }
}

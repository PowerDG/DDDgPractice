﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace Fooww.DataStatistics.Web.Helper
{
    public static class ServiceUtil
    {
        /// <summary>
        /// 生成Service访问Key
        /// </summary>
        /// <param name="PKUser"></param>
        /// <param name="apiUserID">0=fooww</param>
        /// <param name="nowTicks"></param>
        /// <returns></returns>
        public static string GetServiceKey(Guid PKUser, int apiUserID, long nowTicks)
        {
            string serviceKey = "{0}-{1}-{2}";
            serviceKey = string.Format(serviceKey, PKUser.ToString().Replace("-", ""), apiUserID, nowTicks);
            return Encrypt.EncodeString(serviceKey);
        }

        /// <summary>
        /// 重构DataTable类型数据
        /// </summary>
        /// <param name="serviceResult"></param>
        /// <returns></returns>
        public static DataTable GetDataTableFromUnifiedServiceResult(UnifiedServiceResult serviceResult)
        {
            if (serviceResult == null || serviceResult.JSONResult == null || serviceResult.JSONResult.Count == 0)
            {
                return null;
            }

            return GetDataTableFromJSON(serviceResult.JSONResult[0]);
        }

        /// <summary>
        /// 重构DataSet类型数据
        /// </summary>
        /// <param name="sResult"></param>
        /// <returns></returns>
        public static DataSet GetDataSetFromUnifiedServiceResult(UnifiedServiceResult sResult)
        {
            if (sResult == null)
            {
                return null;
            }

            DataSet dataSet = new DataSet();
            foreach (string item in sResult.JSONResult)
            {
                dataSet.Tables.Add(GetDataTableFromJSON(item));
            }

            return dataSet;
        }

        public static DataSet GetDataSetFromUnifiedServiceResult(XmlDocument xmlResult)
        {
            var unifiedServiceResult = GetUnifiedServiceResult(xmlResult);
            return GetDataSetFromUnifiedServiceResult(unifiedServiceResult);
        }

        public static UnifiedServiceResult GetUnifiedServiceResult(XmlDocument xmlResult)
        {
            if (xmlResult == null)
            {
                return null;
            }
            var xmlTemp = new XmlDocument();
            xmlTemp.LoadXml($"<UnifiedServiceResult>{xmlResult.DocumentElement.InnerXml}</UnifiedServiceResult>");
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(UnifiedServiceResult));
            UnifiedServiceResult result = xmlSerializer.Deserialize(new StringReader(xmlTemp.OuterXml)) as UnifiedServiceResult;

            return result;
        }

        /// <summary>
        /// 从JSON 重构DataTable
        /// </summary>
        /// <param name="sJSON"></param>
        /// <returns></returns>
        public static DataTable GetDataTableFromJSON(string sJSON)
        {
            DataTableObject dto = (DataTableObject)JsonConvert.DeserializeObject(sJSON, typeof(DataTableObject));
            DataTable dt = new DataTable();

            dt.TableName = dto.TableName;
            foreach (var dco in dto.DataColumn)
            {
                dt.Columns.Add(new DataColumn(dco.Key, Type.GetType(dco.Value)));
            }

            foreach (List<string> dro in dto.DataRowValue)
            {
                DataRow row = dt.NewRow();
                int i = 0;
                foreach (string itemValue in dro)
                {
                    if (string.IsNullOrEmpty(itemValue))
                    {
                        switch (dt.Columns[i].DataType.FullName)
                        {
                            case "System.Boolean":
                                row[i] = "False";
                                break;

                            case "System.Int16":
                            case "System.Int32":
                            case "System.Int64":
                                row[i] = "0";
                                break;

                            case "System.DateTime":
                            case "System.Guid":
                                row[i] = DBNull.Value;
                                break;

                            case "System.String":
                            default:
                                row[i] = "";
                                break;
                        }
                    }
                    else
                    {
                        row[i] = itemValue;
                    }
                    i++;
                }

                dt.Rows.Add(row);
            }

            return dt;
        }
    }

    /// <summary>
    /// Service 返回结果统一格式，用于需要返回Dataset和DataTable的时候
    /// </summary>
    public class UnifiedServiceResult
    {
        public bool IsSuccess { get; set; }
        public string Error { get; set; }

        /// <summary>
        /// JSON数据格式,DataTable OR DataSet
        /// </summary>
        public List<string> JSONResult { get; set; }

        /// <summary>
        /// 数据类型0=DataTable,1=DataSet
        /// </summary>
        public int DataType { get; set; }
    }

    /// <summary>
    /// 用于序列化DataTable的中介等价对象,配合JSON使用
    /// </summary>
    public class DataTableObject
    {
        public string TableName { get; set; }
        public Dictionary<string, string> DataColumn { get; set; }
        public List<List<string>> DataRowValue { get; set; }

        public DataTableObject()
        {
            DataColumn = new Dictionary<string, string>();
            DataRowValue = new List<List<string>>();
        }
    }
}
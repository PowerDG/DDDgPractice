﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using System;

namespace SMSService.Controllers
{
    [Route("api/[controller]")]
    public class SmsController : Controller
    {
        [Route("send")]
        public bool Send(string msg)
        {
            Console.WriteLine("send a message: " + msg);
            return true;
        }

        [Route("refresh")]
        public string Refresh(string time)
        {
            return "Count 5 " + DateTime.Now;
        }
    }
}
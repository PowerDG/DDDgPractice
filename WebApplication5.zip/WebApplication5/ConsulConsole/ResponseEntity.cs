﻿using System.Net;

namespace ConsulConsole
{
    public class ResponseEntity<T>
    {
        public HttpStatusCode StatusCode { get; set; }
        public T Body { get; set; }
        public HttpResponseHeader Header { get; set; }
    }
}
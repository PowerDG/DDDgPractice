﻿using Microsoft.AspNetCore.Mvc;
using System;

namespace EmailService.Controllers
{
    [Route("api/[controller]")]
    public class EmailController
    {
        [Route("send")]
        public bool Send(string msg)
        {
            Console.WriteLine("send a email: " + msg);
            return true;
        }
    }
}
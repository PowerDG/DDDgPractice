﻿using JWT;
using JWT.Algorithms;
using JWT.Serializers;
using System;
using System.Collections.Generic;

namespace JwtConsole
{
    internal class Program
    {
        private const string secret = "GQDstcKsx0NHjPOuXOYg5MbeJ1XT0uFiwDVvVBrk";//不要泄露（这是服务器端秘钥

        private static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var token = GenerateToken();
            Console.WriteLine("--------decoder");
            System.Threading.Thread.Sleep(1000);
            DecoderToken(token);
            System.Threading.Thread.Sleep(4000);
            DecoderToken(token);
            Console.ReadKey();
        }

        private static void DecoderToken(string token)
        {
            try
            {
                IJsonSerializer serializer = new JsonNetSerializer();
                IDateTimeProvider provider = new UtcDateTimeProvider();
                IJwtValidator jwtValidator = new JwtValidator(serializer, provider);
                IBase64UrlEncoder urlEncoder = new JwtBase64UrlEncoder();
                IJwtDecoder jwtDecoder = new JwtDecoder(serializer, jwtValidator, urlEncoder);
                var json = jwtDecoder.Decode(token, secret, verify: true);
                Console.WriteLine(json);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static string GenerateToken()
        {
            var payload = new Dictionary<string, Object>
            {
                {"Id",1},
                {"UserName", "sun"},
                {"Level", "admin"},
                { "exp", DateTime.UtcNow.AddSeconds(3).Subtract(DateTime.Parse("1970-1-1")).TotalSeconds}
    };

            IJwtAlgorithm algorithm = new HMACSHA256Algorithm();
            IJsonSerializer serializer = new JsonNetSerializer();
            IBase64UrlEncoder urlEncoder = new JwtBase64UrlEncoder();
            IJwtEncoder encoder = new JwtEncoder(algorithm, serializer, urlEncoder);
            var token = encoder.Encode(payload, secret);
            Console.WriteLine(token);
            return token;
        }
    }
}
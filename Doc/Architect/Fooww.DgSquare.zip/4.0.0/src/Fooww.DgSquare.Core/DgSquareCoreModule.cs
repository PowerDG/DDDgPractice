﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using Fooww.DgSquare.Localization;

namespace Fooww.DgSquare
{
    public class DgSquareCoreModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Auditing.IsEnabledForAnonymousUsers = true;

            DgSquareLocalizationConfigurer.Configure(Configuration.Localization);
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgSquareCoreModule).GetAssembly());
        }
    }
}
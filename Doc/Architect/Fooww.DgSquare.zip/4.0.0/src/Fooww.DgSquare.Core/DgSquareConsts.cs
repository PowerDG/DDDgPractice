﻿namespace Fooww.DgSquare
{
    public class DgSquareConsts
    {
        public const string LocalizationSourceName = "DgSquare";

        public const string ConnectionStringName = "Default";
    }
}
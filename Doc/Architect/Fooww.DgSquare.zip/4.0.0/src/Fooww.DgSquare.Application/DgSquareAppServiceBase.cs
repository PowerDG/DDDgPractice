﻿using Abp.Application.Services;

namespace Fooww.DgSquare
{
    /// <summary>
    /// Derive your application services from this class.
    /// </summary>
    public abstract class DgSquareAppServiceBase : ApplicationService
    {
        protected DgSquareAppServiceBase()
        {
            LocalizationSourceName = DgSquareConsts.LocalizationSourceName;
        }
    }
}
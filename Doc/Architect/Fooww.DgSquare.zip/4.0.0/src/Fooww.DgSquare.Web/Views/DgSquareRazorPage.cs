﻿using Abp.AspNetCore.Mvc.Views;

namespace Fooww.DgSquare.Web.Views
{
    public abstract class DgSquareRazorPage<TModel> : AbpRazorPage<TModel>
    {
        protected DgSquareRazorPage()
        {
            LocalizationSourceName = DgSquareConsts.LocalizationSourceName;
        }
    }
}

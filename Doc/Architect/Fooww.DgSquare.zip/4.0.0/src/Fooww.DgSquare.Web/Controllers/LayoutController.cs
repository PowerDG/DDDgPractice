namespace Fooww.DgSquare.Web.Controllers
{
    public class LayoutController : DgSquareControllerBase
    {

    }
}
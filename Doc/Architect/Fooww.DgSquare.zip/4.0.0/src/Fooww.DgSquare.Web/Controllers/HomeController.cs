using Microsoft.AspNetCore.Mvc;

namespace Fooww.DgSquare.Web.Controllers
{
    public class HomeController : DgSquareControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
using Abp.AspNetCore.Mvc.Controllers;

namespace Fooww.DgSquare.Web.Controllers
{
    public abstract class DgSquareControllerBase: AbpController
    {
        protected DgSquareControllerBase()
        {
            LocalizationSourceName = DgSquareConsts.LocalizationSourceName;
        }
    }
}
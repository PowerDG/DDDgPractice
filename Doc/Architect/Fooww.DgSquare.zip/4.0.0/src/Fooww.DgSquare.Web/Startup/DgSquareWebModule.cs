﻿using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Fooww.DgSquare.Configuration;
using Fooww.DgSquare.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace Fooww.DgSquare.Web.Startup
{
    [DependsOn(
        typeof(DgSquareApplicationModule), 
        typeof(DgSquareEntityFrameworkCoreModule), 
        typeof(AbpAspNetCoreModule))]
    public class DgSquareWebModule : AbpModule
    {
        private readonly IConfigurationRoot _appConfiguration;

        public DgSquareWebModule(IHostingEnvironment env)
        {
            _appConfiguration = AppConfigurations.Get(env.ContentRootPath, env.EnvironmentName);
        }

        public override void PreInitialize()
        {
            Configuration.DefaultNameOrConnectionString = _appConfiguration.GetConnectionString(DgSquareConsts.ConnectionStringName);

            Configuration.Navigation.Providers.Add<DgSquareNavigationProvider>();

            Configuration.Modules.AbpAspNetCore()
                .CreateControllersForAppServices(
                    typeof(DgSquareApplicationModule).GetAssembly()
                );
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgSquareWebModule).GetAssembly());
        }
    }
}
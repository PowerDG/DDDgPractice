﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Fooww.DgSquare.EntityFrameworkCore
{
    public class DgSquareDbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...

        public DgSquareDbContext(DbContextOptions<DgSquareDbContext> options) 
            : base(options)
        {

        }
    }
}

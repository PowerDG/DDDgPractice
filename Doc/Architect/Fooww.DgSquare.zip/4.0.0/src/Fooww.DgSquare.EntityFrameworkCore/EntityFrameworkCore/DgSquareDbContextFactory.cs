﻿using Fooww.DgSquare.Configuration;
using Fooww.DgSquare.Web;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace Fooww.DgSquare.EntityFrameworkCore
{
    /* This class is needed to run EF Core PMC commands. Not used anywhere else */
    public class DgSquareDbContextFactory : IDesignTimeDbContextFactory<DgSquareDbContext>
    {
        public DgSquareDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<DgSquareDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            DbContextOptionsConfigurer.Configure(
                builder,
                configuration.GetConnectionString(DgSquareConsts.ConnectionStringName)
            );

            return new DgSquareDbContext(builder.Options);
        }
    }
}
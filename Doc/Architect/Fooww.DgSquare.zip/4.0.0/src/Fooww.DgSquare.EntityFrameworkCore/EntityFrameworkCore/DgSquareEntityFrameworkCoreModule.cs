﻿using Abp.EntityFrameworkCore;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace Fooww.DgSquare.EntityFrameworkCore
{
    [DependsOn(
        typeof(DgSquareCoreModule), 
        typeof(AbpEntityFrameworkCoreModule))]
    public class DgSquareEntityFrameworkCoreModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgSquareEntityFrameworkCoreModule).GetAssembly());
        }
    }
}
using Fooww.DgSquare.EntityFrameworkCore;

namespace Fooww.DgSquare.Tests.TestDatas
{
    public class TestDataBuilder
    {
        private readonly DgSquareDbContext _context;

        public TestDataBuilder(DgSquareDbContext context)
        {
            _context = context;
        }

        public void Build()
        {
            //create test data here...
        }
    }
}
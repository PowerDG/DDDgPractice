﻿using System;
using System.Threading.Tasks;
using Abp.TestBase;
using Fooww.DgSquare.EntityFrameworkCore;
using Fooww.DgSquare.Tests.TestDatas;

namespace Fooww.DgSquare.Tests
{
    public class DgSquareTestBase : AbpIntegratedTestBase<DgSquareTestModule>
    {
        public DgSquareTestBase()
        {
            UsingDbContext(context => new TestDataBuilder(context).Build());
        }

        protected virtual void UsingDbContext(Action<DgSquareDbContext> action)
        {
            using (var context = LocalIocManager.Resolve<DgSquareDbContext>())
            {
                action(context);
                context.SaveChanges();
            }
        }

        protected virtual T UsingDbContext<T>(Func<DgSquareDbContext, T> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<DgSquareDbContext>())
            {
                result = func(context);
                context.SaveChanges();
            }

            return result;
        }

        protected virtual async Task UsingDbContextAsync(Func<DgSquareDbContext, Task> action)
        {
            using (var context = LocalIocManager.Resolve<DgSquareDbContext>())
            {
                await action(context);
                await context.SaveChangesAsync(true);
            }
        }

        protected virtual async Task<T> UsingDbContextAsync<T>(Func<DgSquareDbContext, Task<T>> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<DgSquareDbContext>())
            {
                result = await func(context);
                context.SaveChanges();
            }

            return result;
        }
    }
}

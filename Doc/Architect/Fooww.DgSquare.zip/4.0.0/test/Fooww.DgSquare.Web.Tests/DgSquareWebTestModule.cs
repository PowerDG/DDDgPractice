using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Fooww.DgSquare.Web.Startup;
namespace Fooww.DgSquare.Web.Tests
{
    [DependsOn(
        typeof(DgSquareWebModule),
        typeof(AbpAspNetCoreTestBaseModule)
        )]
    public class DgSquareWebTestModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DgSquareWebTestModule).GetAssembly());
        }
    }
}
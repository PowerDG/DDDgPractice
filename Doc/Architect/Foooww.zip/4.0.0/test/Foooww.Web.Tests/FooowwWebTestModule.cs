using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Foooww.Web.Startup;
namespace Foooww.Web.Tests
{
    [DependsOn(
        typeof(FooowwWebModule),
        typeof(AbpAspNetCoreTestBaseModule)
        )]
    public class FooowwWebTestModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(FooowwWebTestModule).GetAssembly());
        }
    }
}
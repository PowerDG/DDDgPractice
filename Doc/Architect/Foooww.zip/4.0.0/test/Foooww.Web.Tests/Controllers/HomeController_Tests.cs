﻿using System.Threading.Tasks;
using Foooww.Web.Controllers;
using Shouldly;
using Xunit;

namespace Foooww.Web.Tests.Controllers
{
    public class HomeController_Tests: FooowwWebTestBase
    {
        [Fact]
        public async Task Index_Test()
        {
            //Act
            var response = await GetResponseAsStringAsync(
                GetUrl<HomeController>(nameof(HomeController.Index))
            );

            //Assert
            response.ShouldNotBeNullOrEmpty();
        }
    }
}

﻿using System;
using System.Threading.Tasks;
using Abp.TestBase;
using Foooww.EntityFrameworkCore;
using Foooww.Tests.TestDatas;

namespace Foooww.Tests
{
    public class FooowwTestBase : AbpIntegratedTestBase<FooowwTestModule>
    {
        public FooowwTestBase()
        {
            UsingDbContext(context => new TestDataBuilder(context).Build());
        }

        protected virtual void UsingDbContext(Action<FooowwDbContext> action)
        {
            using (var context = LocalIocManager.Resolve<FooowwDbContext>())
            {
                action(context);
                context.SaveChanges();
            }
        }

        protected virtual T UsingDbContext<T>(Func<FooowwDbContext, T> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<FooowwDbContext>())
            {
                result = func(context);
                context.SaveChanges();
            }

            return result;
        }

        protected virtual async Task UsingDbContextAsync(Func<FooowwDbContext, Task> action)
        {
            using (var context = LocalIocManager.Resolve<FooowwDbContext>())
            {
                await action(context);
                await context.SaveChangesAsync(true);
            }
        }

        protected virtual async Task<T> UsingDbContextAsync<T>(Func<FooowwDbContext, Task<T>> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<FooowwDbContext>())
            {
                result = await func(context);
                context.SaveChanges();
            }

            return result;
        }
    }
}

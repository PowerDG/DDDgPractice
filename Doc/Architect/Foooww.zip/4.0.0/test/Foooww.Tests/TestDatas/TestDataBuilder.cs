using Foooww.EntityFrameworkCore;

namespace Foooww.Tests.TestDatas
{
    public class TestDataBuilder
    {
        private readonly FooowwDbContext _context;

        public TestDataBuilder(FooowwDbContext context)
        {
            _context = context;
        }

        public void Build()
        {
            //create test data here...
        }
    }
}
﻿using Abp.Application.Services;

namespace Foooww
{
    /// <summary>
    /// Derive your application services from this class.
    /// </summary>
    public abstract class FooowwAppServiceBase : ApplicationService
    {
        protected FooowwAppServiceBase()
        {
            LocalizationSourceName = FooowwConsts.LocalizationSourceName;
        }
    }
}
﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace Foooww
{
    [DependsOn(
        typeof(FooowwCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class FooowwApplicationModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(FooowwApplicationModule).GetAssembly());
        }
    }
}
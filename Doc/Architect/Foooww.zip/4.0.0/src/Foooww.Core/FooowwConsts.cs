﻿namespace Foooww
{
    public class FooowwConsts
    {
        public const string LocalizationSourceName = "Foooww";

        public const string ConnectionStringName = "Default";
    }
}
﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using Foooww.Localization;

namespace Foooww
{
    public class FooowwCoreModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Auditing.IsEnabledForAnonymousUsers = true;

            FooowwLocalizationConfigurer.Configure(Configuration.Localization);
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(FooowwCoreModule).GetAssembly());
        }
    }
}
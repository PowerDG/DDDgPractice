﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Foooww.EntityFrameworkCore
{
    public class FooowwDbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...

        public FooowwDbContext(DbContextOptions<FooowwDbContext> options) 
            : base(options)
        {

        }
    }
}

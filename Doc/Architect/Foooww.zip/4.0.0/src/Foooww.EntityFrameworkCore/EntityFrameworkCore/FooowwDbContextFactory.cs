﻿using Foooww.Configuration;
using Foooww.Web;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace Foooww.EntityFrameworkCore
{
    /* This class is needed to run EF Core PMC commands. Not used anywhere else */
    public class FooowwDbContextFactory : IDesignTimeDbContextFactory<FooowwDbContext>
    {
        public FooowwDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<FooowwDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            DbContextOptionsConfigurer.Configure(
                builder,
                configuration.GetConnectionString(FooowwConsts.ConnectionStringName)
            );

            return new FooowwDbContext(builder.Options);
        }
    }
}
﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Foooww.Migrations
{
    public partial class Upgraded_To_ABP_v3_9_0 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

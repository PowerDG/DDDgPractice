using Microsoft.AspNetCore.Mvc;

namespace Foooww.Web.Controllers
{
    public class HomeController : FooowwControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
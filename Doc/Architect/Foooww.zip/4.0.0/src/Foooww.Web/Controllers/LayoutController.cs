namespace Foooww.Web.Controllers
{
    public class LayoutController : FooowwControllerBase
    {

    }
}
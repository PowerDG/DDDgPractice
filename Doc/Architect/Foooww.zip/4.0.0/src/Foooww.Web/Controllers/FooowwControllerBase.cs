using Abp.AspNetCore.Mvc.Controllers;

namespace Foooww.Web.Controllers
{
    public abstract class FooowwControllerBase: AbpController
    {
        protected FooowwControllerBase()
        {
            LocalizationSourceName = FooowwConsts.LocalizationSourceName;
        }
    }
}
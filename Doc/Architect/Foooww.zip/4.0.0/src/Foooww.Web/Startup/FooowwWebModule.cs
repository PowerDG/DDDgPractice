﻿using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Foooww.Configuration;
using Foooww.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace Foooww.Web.Startup
{
    [DependsOn(
        typeof(FooowwApplicationModule), 
        typeof(FooowwEntityFrameworkCoreModule), 
        typeof(AbpAspNetCoreModule))]
    public class FooowwWebModule : AbpModule
    {
        private readonly IConfigurationRoot _appConfiguration;

        public FooowwWebModule(IHostingEnvironment env)
        {
            _appConfiguration = AppConfigurations.Get(env.ContentRootPath, env.EnvironmentName);
        }

        public override void PreInitialize()
        {
            Configuration.DefaultNameOrConnectionString = _appConfiguration.GetConnectionString(FooowwConsts.ConnectionStringName);

            Configuration.Navigation.Providers.Add<FooowwNavigationProvider>();

            Configuration.Modules.AbpAspNetCore()
                .CreateControllersForAppServices(
                    typeof(FooowwApplicationModule).GetAssembly()
                );
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(FooowwWebModule).GetAssembly());
        }
    }
}
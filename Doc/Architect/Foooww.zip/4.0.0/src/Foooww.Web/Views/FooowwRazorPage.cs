﻿using Abp.AspNetCore.Mvc.Views;

namespace Foooww.Web.Views
{
    public abstract class FooowwRazorPage<TModel> : AbpRazorPage<TModel>
    {
        protected FooowwRazorPage()
        {
            LocalizationSourceName = FooowwConsts.LocalizationSourceName;
        }
    }
}

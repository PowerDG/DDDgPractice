﻿namespace PowerDg.EntityFrameworkCore
{
    public class MyEntityRepository_Tests : MyEntityRepository_Tests<PowerDgEntityFrameworkCoreTestModule>
    {

    }
}

﻿namespace PowerDg.MongoDB
{
    public class MyEntityRepository_Tests : MyEntityRepository_Tests<PowerDgMongoDbTestModule>
    {

    }
}

﻿using AutoMapper;

namespace PowerDg
{
    public class PowerDgApplicationAutoMapperProfile : Profile
    {
        public PowerDgApplicationAutoMapperProfile()
        {
            
        }
    }
}
﻿namespace PowerDg
{
    public static class PowerDgConsts
    {
        public const string DefaultDbTablePrefix = "PowerDg";

        public const string DefaultDbSchema = null;
    }
}

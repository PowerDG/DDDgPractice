﻿using AutoMapper;

namespace PowerDg
{
    public class PowerDgWebAutoMapperProfile : Profile
    {
        public PowerDgWebAutoMapperProfile()
        {
            //Create mappings.
        }
    }
}
﻿using Abp.Application.Services;

namespace DG.ERP
{
    /// <summary>
    /// Derive your application services from this class.
    /// </summary>
    public abstract class ERPAppServiceBase : ApplicationService
    {
        protected ERPAppServiceBase()
        {
            LocalizationSourceName = ERPConsts.LocalizationSourceName;
        }
    }
}
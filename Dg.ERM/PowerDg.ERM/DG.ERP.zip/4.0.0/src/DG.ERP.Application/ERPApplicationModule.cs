﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace DG.ERP
{
    [DependsOn(
        typeof(ERPCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class ERPApplicationModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ERPApplicationModule).GetAssembly());
        }
    }
}
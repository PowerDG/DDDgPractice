using Abp.AspNetCore.Mvc.Controllers;

namespace DG.ERP.Web.Controllers
{
    public abstract class ERPControllerBase: AbpController
    {
        protected ERPControllerBase()
        {
            LocalizationSourceName = ERPConsts.LocalizationSourceName;
        }
    }
}
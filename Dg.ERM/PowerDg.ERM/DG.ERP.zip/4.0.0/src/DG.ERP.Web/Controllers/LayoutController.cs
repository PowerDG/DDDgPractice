namespace DG.ERP.Web.Controllers
{
    public class LayoutController : ERPControllerBase
    {

    }
}
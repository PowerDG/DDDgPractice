using Microsoft.AspNetCore.Mvc;

namespace DG.ERP.Web.Controllers
{
    public class HomeController : ERPControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
﻿using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DG.ERP.Configuration;
using DG.ERP.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace DG.ERP.Web.Startup
{
    [DependsOn(
        typeof(ERPApplicationModule), 
        typeof(ERPEntityFrameworkCoreModule), 
        typeof(AbpAspNetCoreModule))]
    public class ERPWebModule : AbpModule
    {
        private readonly IConfigurationRoot _appConfiguration;

        public ERPWebModule(IHostingEnvironment env)
        {
            _appConfiguration = AppConfigurations.Get(env.ContentRootPath, env.EnvironmentName);
        }

        public override void PreInitialize()
        {
            Configuration.DefaultNameOrConnectionString = _appConfiguration.GetConnectionString(ERPConsts.ConnectionStringName);

            Configuration.Navigation.Providers.Add<ERPNavigationProvider>();

            Configuration.Modules.AbpAspNetCore()
                .CreateControllersForAppServices(
                    typeof(ERPApplicationModule).GetAssembly()
                );
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ERPWebModule).GetAssembly());
        }
    }
}
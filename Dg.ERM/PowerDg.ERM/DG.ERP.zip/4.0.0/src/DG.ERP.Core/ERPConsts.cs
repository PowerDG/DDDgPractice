﻿namespace DG.ERP
{
    public class ERPConsts
    {
        public const string LocalizationSourceName = "ERP";

        public const string ConnectionStringName = "Default";
    }
}
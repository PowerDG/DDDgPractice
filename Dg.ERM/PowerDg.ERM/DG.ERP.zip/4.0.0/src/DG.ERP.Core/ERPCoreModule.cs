﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using DG.ERP.Localization;

namespace DG.ERP
{
    public class ERPCoreModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Auditing.IsEnabledForAnonymousUsers = true;

            ERPLocalizationConfigurer.Configure(Configuration.Localization);
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ERPCoreModule).GetAssembly());
        }
    }
}
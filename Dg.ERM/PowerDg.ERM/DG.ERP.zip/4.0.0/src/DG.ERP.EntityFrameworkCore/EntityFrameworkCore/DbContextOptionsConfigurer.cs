﻿using Microsoft.EntityFrameworkCore;

namespace DG.ERP.EntityFrameworkCore
{
    public static class DbContextOptionsConfigurer
    {
        public static void Configure(
            DbContextOptionsBuilder<ERPDbContext> dbContextOptions, 
            string connectionString
            )
        {
            /* This is the single point to configure DbContextOptions for ERPDbContext */
            dbContextOptions.UseSqlServer(connectionString);
        }
    }
}

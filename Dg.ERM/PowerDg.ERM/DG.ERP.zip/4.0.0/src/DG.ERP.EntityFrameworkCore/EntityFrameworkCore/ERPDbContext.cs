﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DG.ERP.EntityFrameworkCore
{
    public class ERPDbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...

        public ERPDbContext(DbContextOptions<ERPDbContext> options) 
            : base(options)
        {

        }
    }
}

﻿using Abp.EntityFrameworkCore;
using Abp.Modules;
using Abp.Reflection.Extensions;

namespace DG.ERP.EntityFrameworkCore
{
    [DependsOn(
        typeof(ERPCoreModule), 
        typeof(AbpEntityFrameworkCoreModule))]
    public class ERPEntityFrameworkCoreModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ERPEntityFrameworkCoreModule).GetAssembly());
        }
    }
}
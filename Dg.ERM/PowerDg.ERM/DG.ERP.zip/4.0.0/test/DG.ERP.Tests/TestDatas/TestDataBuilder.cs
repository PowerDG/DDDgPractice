using DG.ERP.EntityFrameworkCore;

namespace DG.ERP.Tests.TestDatas
{
    public class TestDataBuilder
    {
        private readonly ERPDbContext _context;

        public TestDataBuilder(ERPDbContext context)
        {
            _context = context;
        }

        public void Build()
        {
            //create test data here...
        }
    }
}
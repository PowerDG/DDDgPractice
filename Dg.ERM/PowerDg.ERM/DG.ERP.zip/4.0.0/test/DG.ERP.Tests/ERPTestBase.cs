﻿using System;
using System.Threading.Tasks;
using Abp.TestBase;
using DG.ERP.EntityFrameworkCore;
using DG.ERP.Tests.TestDatas;

namespace DG.ERP.Tests
{
    public class ERPTestBase : AbpIntegratedTestBase<ERPTestModule>
    {
        public ERPTestBase()
        {
            UsingDbContext(context => new TestDataBuilder(context).Build());
        }

        protected virtual void UsingDbContext(Action<ERPDbContext> action)
        {
            using (var context = LocalIocManager.Resolve<ERPDbContext>())
            {
                action(context);
                context.SaveChanges();
            }
        }

        protected virtual T UsingDbContext<T>(Func<ERPDbContext, T> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<ERPDbContext>())
            {
                result = func(context);
                context.SaveChanges();
            }

            return result;
        }

        protected virtual async Task UsingDbContextAsync(Func<ERPDbContext, Task> action)
        {
            using (var context = LocalIocManager.Resolve<ERPDbContext>())
            {
                await action(context);
                await context.SaveChangesAsync(true);
            }
        }

        protected virtual async Task<T> UsingDbContextAsync<T>(Func<ERPDbContext, Task<T>> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<ERPDbContext>())
            {
                result = await func(context);
                context.SaveChanges();
            }

            return result;
        }
    }
}

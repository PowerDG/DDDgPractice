using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DG.ERP.Web.Startup;
namespace DG.ERP.Web.Tests
{
    [DependsOn(
        typeof(ERPWebModule),
        typeof(AbpAspNetCoreTestBaseModule)
        )]
    public class ERPWebTestModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ERPWebTestModule).GetAssembly());
        }
    }
}
﻿namespace PowerDg.ERM
{
    public class ERMConsts
    {
        public const string LocalizationSourceName = "ERM";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}

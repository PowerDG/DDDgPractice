interface GetRoleAsyncInput {
  permission: string;
}

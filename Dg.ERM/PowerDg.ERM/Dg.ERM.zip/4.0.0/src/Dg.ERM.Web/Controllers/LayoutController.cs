namespace Dg.ERM.Web.Controllers
{
    public class LayoutController : ERMControllerBase
    {

    }
}
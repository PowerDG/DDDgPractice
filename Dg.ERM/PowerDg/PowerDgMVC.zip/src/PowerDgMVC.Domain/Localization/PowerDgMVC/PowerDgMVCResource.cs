﻿using Volo.Abp.Localization;

namespace PowerDgMVC.Localization.PowerDgMVC
{
    [LocalizationResourceName("PowerDgMVC")]
    public class PowerDgMVCResource
    {

    }
}
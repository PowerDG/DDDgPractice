﻿namespace PowerDgMVC
{
    public static class PowerDgMVCConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;

        public const bool IsMultiTenancyEnabled = true;
    }
}

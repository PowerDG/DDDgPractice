﻿namespace PowerDgMVC.Settings
{
    public static class PowerDgMVCSettings
    {
        private const string Prefix = "PowerDgMVC";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}
﻿using Volo.Abp.Settings;

namespace PowerDgMVC.Settings
{
    public class PowerDgMVCSettingDefinitionProvider : SettingDefinitionProvider
    {
        public override void Define(ISettingDefinitionContext context)
        {
            //Define your own settings here. Example:
            //context.Add(new SettingDefinition(PowerDgMVCSettings.MySetting1));
        }
    }
}

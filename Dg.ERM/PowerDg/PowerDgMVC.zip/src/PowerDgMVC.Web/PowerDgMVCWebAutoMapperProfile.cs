﻿using AutoMapper;

namespace PowerDgMVC
{
    public class PowerDgMVCWebAutoMapperProfile : Profile
    {
        public PowerDgMVCWebAutoMapperProfile()
        {
            //Configure your AutoMapper mapping configuration here...
        }
    }
}

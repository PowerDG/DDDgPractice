﻿using Microsoft.AspNetCore.Mvc.Localization;
using Microsoft.AspNetCore.Mvc.Razor.Internal;
using PowerDgMVC.Localization.PowerDgMVC;
using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace PowerDgMVC.Pages
{
    public abstract class PowerDgMVCPageBase : AbpPage
    {
        [RazorInject]
        public IHtmlLocalizer<PowerDgMVCResource> L { get; set; }
    }
}

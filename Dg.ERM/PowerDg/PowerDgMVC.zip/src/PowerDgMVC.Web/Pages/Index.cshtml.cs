﻿namespace PowerDgMVC.Pages
{
    public class IndexModel : PowerDgMVCPageModelBase
    {
        public void OnGet()
        {
            
        }
    }
}
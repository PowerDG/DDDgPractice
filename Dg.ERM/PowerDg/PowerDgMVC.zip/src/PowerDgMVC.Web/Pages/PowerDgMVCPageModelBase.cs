﻿using PowerDgMVC.Localization.PowerDgMVC;
using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace PowerDgMVC.Pages
{
    public abstract class PowerDgMVCPageModelBase : AbpPageModel
    {
        protected PowerDgMVCPageModelBase()
        {
            LocalizationResourceType = typeof(PowerDgMVCResource);
        }
    }
}
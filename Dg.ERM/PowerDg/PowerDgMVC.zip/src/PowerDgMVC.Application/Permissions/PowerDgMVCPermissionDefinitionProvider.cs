﻿using PowerDgMVC.Localization.PowerDgMVC;
using Volo.Abp.Authorization.Permissions;
using Volo.Abp.Localization;

namespace PowerDgMVC.Permissions
{
    public class PowerDgMVCPermissionDefinitionProvider : PermissionDefinitionProvider
    {
        public override void Define(IPermissionDefinitionContext context)
        {
            var myGroup = context.AddGroup(PowerDgMVCPermissions.GroupName);

            //Define your own permissions here. Examaple:
            //myGroup.AddPermission(PowerDgMVCPermissions.MyPermission1, L("Permission:MyPermission1"));
        }

        private static LocalizableString L(string name)
        {
            return LocalizableString.Create<PowerDgMVCResource>(name);
        }
    }
}

﻿using AutoMapper;

namespace PowerDgMVC
{
    public class PowerDgMVCApplicationAutoMapperProfile : Profile
    {
        public PowerDgMVCApplicationAutoMapperProfile()
        {
            //Configure your AutoMapper mapping configuration here...
        }
    }
}

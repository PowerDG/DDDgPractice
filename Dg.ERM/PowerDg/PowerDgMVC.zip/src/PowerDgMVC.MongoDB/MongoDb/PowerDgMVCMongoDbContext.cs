﻿using MongoDB.Driver;
using PowerDgMVC.Users;
using Volo.Abp.Data;
using Volo.Abp.MongoDB;

namespace PowerDgMVC.MongoDb
{
    [ConnectionStringName("Default")]
    public class PowerDgMVCMongoDbContext : AbpMongoDbContext
    {
        public IMongoCollection<AppUser> Users => Collection<AppUser>();

        protected override void CreateModel(IMongoModelBuilder modelBuilder)
        {
            base.CreateModel(modelBuilder);

            modelBuilder.Entity<AppUser>(b =>
            {
                b.CollectionName = "AbpUsers"; //Sharing the same collection "AbpUsers" with the IdentityUser
            });
        }
    }
}

﻿using Volo.Abp;

namespace PowerDgMVC
{
    public abstract class PowerDgMVCApplicationTestBase : AbpIntegratedTest<PowerDgMVCApplicationTestModule>
    {
        protected override void SetAbpApplicationCreationOptions(AbpApplicationCreationOptions options)
        {
            options.UseAutofac();
        }
    }
}

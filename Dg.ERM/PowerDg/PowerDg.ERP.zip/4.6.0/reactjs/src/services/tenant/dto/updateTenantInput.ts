export default interface UpdateTenantInput {
  tenancyName: string;
  name: string;
  isActive: boolean;
  id: number;
}

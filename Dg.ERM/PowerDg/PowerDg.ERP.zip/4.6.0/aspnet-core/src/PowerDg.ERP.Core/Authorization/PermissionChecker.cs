﻿using Abp.Authorization;
using PowerDg.ERP.Authorization.Roles;
using PowerDg.ERP.Authorization.Users;

namespace PowerDg.ERP.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}

﻿namespace PowerDg.ERP
{
    public class ERPConsts
    {
        public const string LocalizationSourceName = "ERP";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using PowerDg.ERP.Authorization.Roles;
using PowerDg.ERP.Authorization.Users;
using PowerDg.ERP.MultiTenancy;

namespace PowerDg.ERP.EntityFrameworkCore
{
    public class ERPDbContext : AbpZeroDbContext<Tenant, Role, User, ERPDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public ERPDbContext(DbContextOptions<ERPDbContext> options)
            : base(options)
        {
        }
    }
}

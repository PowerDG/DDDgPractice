﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using PowerDg.ERP.MultiTenancy.Dto;

namespace PowerDg.ERP.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}


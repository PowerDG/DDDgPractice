﻿using System.Threading.Tasks;
using PowerDg.ERP.Configuration.Dto;

namespace PowerDg.ERP.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}

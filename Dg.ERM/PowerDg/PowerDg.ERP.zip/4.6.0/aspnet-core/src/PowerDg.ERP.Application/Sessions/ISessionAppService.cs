﻿using System.Threading.Tasks;
using Abp.Application.Services;
using PowerDg.ERP.Sessions.Dto;

namespace PowerDg.ERP.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}

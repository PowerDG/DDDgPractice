﻿using Volo.Abp.Localization;

namespace PowerDg.Localization
{
    [LocalizationResourceName("PowerDg")]
    public class PowerDgResource
    {
        
    }
}

﻿namespace PowerDg
{
    public static class PowerDgDomainErrorCodes
    {
        //Add your business exception error codes here...
    }
}

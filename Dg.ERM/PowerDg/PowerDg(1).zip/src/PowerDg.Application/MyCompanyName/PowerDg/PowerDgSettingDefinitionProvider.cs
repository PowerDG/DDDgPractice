﻿using Volo.Abp.Settings;

namespace PowerDg
{
    public class PowerDgSettingDefinitionProvider : SettingDefinitionProvider
    {
        public override void Define(ISettingDefinitionContext context)
        {
            /* Define module settings here.
             * Use names from PowerDgSettings class.
             */
        }
    }
}
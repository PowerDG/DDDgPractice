﻿namespace PowerDg
{
    public static class PowerDgSettings
    {
        public const string GroupName = "PowerDg";

        /* Add constants for setting names. Example:
         * public const string MySettingName = GroupName + ".MySettingName";
         */
    }
}
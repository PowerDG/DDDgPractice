﻿using Volo.Abp.DependencyInjection;

namespace PowerDg
{
    public class PowerDgTestData : ISingletonDependency
    {
    }
}

﻿namespace PowerDg
{
    public abstract class PowerDgDomainTestBase : PowerDgTestBase<PowerDgDomainTestModule>
    {

    }
}
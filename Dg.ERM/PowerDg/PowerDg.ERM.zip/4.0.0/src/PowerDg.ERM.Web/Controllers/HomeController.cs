using Microsoft.AspNetCore.Mvc;

namespace PowerDg.ERM.Web.Controllers
{
    public class HomeController : ERMControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
using Abp.AspNetCore.Mvc.Controllers;

namespace PowerDg.ERM.Web.Controllers
{
    public abstract class ERMControllerBase: AbpController
    {
        protected ERMControllerBase()
        {
            LocalizationSourceName = ERMConsts.LocalizationSourceName;
        }
    }
}
namespace PowerDg.ERM.Web.Controllers
{
    public class LayoutController : ERMControllerBase
    {

    }
}
﻿using Abp.AspNetCore.Mvc.Views;

namespace PowerDg.ERM.Web.Views
{
    public abstract class ERMRazorPage<TModel> : AbpRazorPage<TModel>
    {
        protected ERMRazorPage()
        {
            LocalizationSourceName = ERMConsts.LocalizationSourceName;
        }
    }
}

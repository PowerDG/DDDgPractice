﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using PowerDg.ERM.Localization;

namespace PowerDg.ERM
{
    public class ERMCoreModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Auditing.IsEnabledForAnonymousUsers = true;

            ERMLocalizationConfigurer.Configure(Configuration.Localization);
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ERMCoreModule).GetAssembly());
        }
    }
}
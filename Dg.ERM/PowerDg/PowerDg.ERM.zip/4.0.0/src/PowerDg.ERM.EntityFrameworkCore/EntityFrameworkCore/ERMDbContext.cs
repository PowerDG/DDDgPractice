﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace PowerDg.ERM.EntityFrameworkCore
{
    public class ERMDbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...

        public ERMDbContext(DbContextOptions<ERMDbContext> options) 
            : base(options)
        {

        }
    }
}

﻿using System.Threading.Tasks;
using PowerDg.ERM.Web.Controllers;
using Shouldly;
using Xunit;

namespace PowerDg.ERM.Web.Tests.Controllers
{
    public class HomeController_Tests: ERMWebTestBase
    {
        [Fact]
        public async Task Index_Test()
        {
            //Act
            var response = await GetResponseAsStringAsync(
                GetUrl<HomeController>(nameof(HomeController.Index))
            );

            //Assert
            response.ShouldNotBeNullOrEmpty();
        }
    }
}

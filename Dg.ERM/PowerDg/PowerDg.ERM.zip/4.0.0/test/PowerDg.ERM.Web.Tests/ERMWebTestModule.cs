using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using PowerDg.ERM.Web.Startup;
namespace PowerDg.ERM.Web.Tests
{
    [DependsOn(
        typeof(ERMWebModule),
        typeof(AbpAspNetCoreTestBaseModule)
        )]
    public class ERMWebTestModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ERMWebTestModule).GetAssembly());
        }
    }
}
namespace DgCore.MyMission.Web.Controllers
{
    public class LayoutController : MyMissionControllerBase
    {

    }
}
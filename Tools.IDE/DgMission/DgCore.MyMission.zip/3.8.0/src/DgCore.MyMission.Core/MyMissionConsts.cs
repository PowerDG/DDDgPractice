﻿namespace DgCore.MyMission
{
    public class MyMissionConsts
    {
        public const string LocalizationSourceName = "MyMission";

        public const string ConnectionStringName = "Default";
    }
}